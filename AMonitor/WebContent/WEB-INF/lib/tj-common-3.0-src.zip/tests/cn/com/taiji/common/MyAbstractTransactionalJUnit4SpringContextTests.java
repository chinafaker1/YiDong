package tests.cn.com.taiji.common;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-25 上午07:45:42
 * @since 1.0
 * @version 1.0
 */
public abstract class MyAbstractTransactionalJUnit4SpringContextTests extends
		AbstractTransactionalJUnit4SpringContextTests
{
	public void setDataSource(DataSource dataSource)
	{
		// do nothing;更改此方法以适应多数据源情况下数据源可配置
		// 参见@DataSourceConfiguration
	}

	@PostConstruct
	public void initJdbcTemplate()
	{
		if (jdbcTemplate != null) return;
		String sourceName = retrieveDataSourceName(this.getClass());
		AssertUtil.hasText(sourceName, "dataSource name must specified.");
		DataSource dataSource = (DataSource) applicationContext.getBean(sourceName);
		super.setDataSource(dataSource);
		// this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	private String retrieveDataSourceName(Class<?> clazz)
	{
		Class<DataSourceConfiguration> annotationType = DataSourceConfiguration.class;
		DataSourceConfiguration config = clazz.getAnnotation(annotationType);
		if (logger.isDebugEnabled())
			logger.debug("Retrieved @DataSourceConfiguration [" + config + "] for test class [" + clazz + "]");
		if (config != null) return config.dataSource();
		return (String) AnnotationUtils.getDefaultValue(annotationType, "dataSource");
	}
}
