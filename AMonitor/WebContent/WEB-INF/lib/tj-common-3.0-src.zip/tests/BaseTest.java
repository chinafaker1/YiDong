package tests;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.pub.CollectionTools;


/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2008-2-14 上午11:34:41
 * @since 1.0
 * @version 1.0
 */
@ContextConfiguration(locations = "classpath:tests/test.xml")
public abstract class BaseTest extends AbstractJUnit4SpringContextTests
{
	static
	{
		System.setProperty("webapp.taiji", "war");
	}

	public static void echoList(Collection<?> list)
	{
		echoList(list, 100);
	}

	public static void echoCollection(Collection<?> list)
	{
		echoList(list, 100);
	}

	public static void echoList(Collection<?> list, int echoSize)
	{
		if (CollectionTools.isEmpty(list))
		{
			System.out.println("list is empty");
			return;
		}
		System.out.println("\n==================List<?> Begin=============================");
		System.out.println("list size = " + list.size() + "\n");
		Class<?> clazz = null;
		if (list.size() < echoSize)
		{
			for (Object obj : list)
			{
				if (clazz == null) clazz = obj.getClass();
				System.out.println("obj = " + obj);
			}
		}
		else
		{
			Iterator<?> it = list.iterator();
			for (int i = 0; i < echoSize; i++)
			{
				Object obj = it.next();
				if (clazz == null) clazz = obj.getClass();
				System.out.println("obj=" + obj);
			}
		}
		System.out.println("\nfirst element class = " + clazz);
		System.out.println("===================List<?> End===================================\n");
	}

	public static void echoObjects(Object[] objs)
	{
		if (objs == null)
		{
			System.out.println("objs is null");
			return;
		}
		System.out.println("\n==================objs[] Begin=============================");
		System.out.println("list size = " + objs.length + "\n");
		Class<?> clazz = null;
		if (objs.length < 100)
		{
			for (Object obj : objs)
			{
				if (clazz == null) clazz = obj.getClass();
				System.out.println("obj = " + obj);
			}
		}
		System.out.println("\nfirst element class = " + clazz);
		System.out.println("===================objs[] End===================================\n");
	}

	public static void echoMap(Map<?, ?> map)
	{
		System.out.println("\n=====================Map<?,?> Begin=================================");
		System.out.println("map size = " + map.size() + "\n");
		Class<?> keyClass = null;
		Class<?> valueClass = null;
		int count = 1;
		for (Entry<?, ?> entry : map.entrySet())
		{
			if (keyClass == null) keyClass = entry.getKey().getClass();
			if (valueClass == null) valueClass = entry.getValue().getClass();
			System.out.println("key = " + entry.getKey() + " ; value = " + entry.getValue());
			count++;
			if (count > 100) break;
		}
		System.out.println("\nfirst key class = " + keyClass);
		System.out.println("first value class = " + valueClass);
		System.out.println("========================Map<?,?> End============================\n");
	}

	public static void echoPagin(Pagination pg)
	{
		echo(pg.toString());
		echoList(pg.getResult());
	}

	public static void echo(Object obj)
	{
		if (obj instanceof Collection<?>)
		{
			echoCollection((Collection<?>) obj);
			return;
		}
		if (obj instanceof Map<?, ?>)
		{
			echoMap((Map<?, ?>) obj);
			return;
		}
		if (obj instanceof Pagination)
		{
			echoPagin((Pagination) obj);
			return;
		}
		if (obj instanceof Object[])
		{
			echoObjects((Object[]) obj);
			return;
		}
		System.out.println(obj);
	}

	public static void echo()
	{
		System.out.println();
	}
}
