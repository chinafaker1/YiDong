package samples.cn.com.taiji.common.web;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.FileCopyTools;
import cn.com.taiji.common.web.BaseDownloadController;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-6-30 下午01:41:41<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleDownloadController extends BaseDownloadController
{
	@RequestMapping("/download/downFile.do")
	public void downloadFile(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException
	{
		String path = FileHelper.getWebappPath() + "/WEB-INF/web.xml";
		File file = new File(path);
		doDownLoad(request, response, file, "无所谓的通知.xml");
	}

	@RequestMapping("/download/downStr.do")
	public void downloadStr(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		String path = FileHelper.getWebappPath() + "/WEB-INF/web.xml";
		File file = new File(path);
		String str = FileCopyTools.copyToStr(file, "UTF-8");
		doDownLoad(request, response, str, "通知.xml");
	}

	@RequestMapping("/download/showPic.do")
	public void showPic(HttpServletResponse response) throws IOException
	{
		String path = FileHelper.getWebappPath() + "/WEB-INF/jsp/samples/download/1.jpg";
		File file = new File(path);
		doShowPic(response, file);
	}
}
