/*
 * Date: 2011-7-22
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.web.proxy;

import java.io.IOException;
import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.common.manager.net.http.HttpProxyHelper;
import cn.com.taiji.common.web.BaseController;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-7-22 下午5:05:52<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
@RequestMapping("/sample/proxy")
public class HttpProxyController extends BaseController
{
	@RequestMapping(value = "/test.do", method = RequestMethod.GET)
	public void myProxGet(HttpServletRequest request, HttpServletResponse response)
			throws URISyntaxException, IOException
	{
		String uri = "http://127.0.0.1/tj/jquery14/manage.do";
		HttpProxyHelper.proxyGet(uri, request, response);
	}

	@RequestMapping(value = "/test.do", method = RequestMethod.POST)
	public void myProxPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		logger.debug("In POST Proxy....");
		String uri = "http://127.0.0.1/tj/jquery14/manage.do";
		HttpProxyHelper.proxyPost(uri, request, response);
	}
}
