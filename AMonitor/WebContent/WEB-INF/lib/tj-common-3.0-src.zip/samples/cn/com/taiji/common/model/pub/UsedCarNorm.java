package samples.cn.com.taiji.common.model.pub;

import java.util.Calendar;

import cn.com.taiji.common.entity.StringUUIDEntity;


/**
 * @author TOM Email:tomesc@msn.com
 * 
 */
public class UsedCarNorm extends StringUUIDEntity
{
	private Calendar time; // 获得指标的日期
	private Calendar noValidTime; // 定时器设定指标不再有效的时间
	private boolean valid = true; // 指标是否有效，指标长久未用将变成无效
	private boolean used = false; // 是否使用

	private String normNo;
	private String market;
	private String licenceCode; // 车牌号
	private String engineNo; // 发动机号
	private String frameNo; // 车架号
	private String licenceCodeType;// 号牌种类:小型轿车
	private String carModel; // 厂牌型号
	private String owner;// 所有人
	private String dealer; // 经销商
	private String certificateNo;// 证书编号
	private Calendar enterDate;// 入库时间
	private String mark; // 标记
	private String originalNo;// 原始编号(导入Excel中的编号)

	public Calendar getTime()
	{
		return time;
	}

	public void setTime(Calendar time)
	{
		this.time = time;
	}

	public Calendar getNoValidTime()
	{
		return noValidTime;
	}

	public void setNoValidTime(Calendar noValidTime)
	{
		this.noValidTime = noValidTime;
	}

	public boolean isValid()
	{
		return valid;
	}

	public void setValid(boolean valid)
	{
		this.valid = valid;
	}

	public boolean isUsed()
	{
		return used;
	}

	public void setUsed(boolean used)
	{
		this.used = used;
	}

	public String getNormNo()
	{
		return normNo;
	}

	public void setNormNo(String normNo)
	{
		this.normNo = normNo;
	}

	public String getMarket()
	{
		return market;
	}

	public void setMarket(String market)
	{
		this.market = market;
	}

	public String getLicenceCode()
	{
		return licenceCode;
	}

	public void setLicenceCode(String licenceCode)
	{
		this.licenceCode = licenceCode;
	}

	public String getEngineNo()
	{
		return engineNo;
	}

	public void setEngineNo(String engineNo)
	{
		this.engineNo = engineNo;
	}

	public String getFrameNo()
	{
		return frameNo;
	}

	public void setFrameNo(String frameNo)
	{
		this.frameNo = frameNo;
	}

	public String getLicenceCodeType()
	{
		return licenceCodeType;
	}

	public void setLicenceCodeType(String licenceCodeType)
	{
		this.licenceCodeType = licenceCodeType;
	}

	public String getCarModel()
	{
		return carModel;
	}

	public void setCarModel(String carModel)
	{
		this.carModel = carModel;
	}

	public String getOwner()
	{
		return owner;
	}

	public void setOwner(String owner)
	{
		this.owner = owner;
	}

	public String getDealer()
	{
		return dealer;
	}

	public void setDealer(String dealer)
	{
		this.dealer = dealer;
	}

	public String getCertificateNo()
	{
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo)
	{
		this.certificateNo = certificateNo;
	}

	public Calendar getEnterDate()
	{
		return enterDate;
	}

	public void setEnterDate(Calendar enterDate)
	{
		this.enterDate = enterDate;
	}

	public String getMark()
	{
		return mark;
	}

	public void setMark(String mark)
	{
		this.mark = mark;
	}

	public String getOriginalNo()
	{
		return originalNo;
	}

	public void setOriginalNo(String originalNo)
	{
		this.originalNo = originalNo;
	}

	public static UsedCarNorm sampleInstance()
	{
		UsedCarNorm rs = new UsedCarNorm();
		rs.setTime(Calendar.getInstance());
		rs.setNormNo("20110000001");
		rs.setMarket("花乡市场");
		rs.setDealer("经销商");
		rs.setEngineNo("PDXX872");
		rs.setLicenceCode("DFLS");
		rs.setFrameNo("UFYDOSDFDF");
		rs.setOwner("张三");
		return rs;
	}
}
