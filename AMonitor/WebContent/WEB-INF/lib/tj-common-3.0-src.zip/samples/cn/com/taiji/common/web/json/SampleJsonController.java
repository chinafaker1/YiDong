/*
 * Date: 2011-6-30
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.web.json;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import samples.cn.com.taiji.common.entity.Sample;
import cn.com.taiji.common.manager.pub.ZipHelper;
import cn.com.taiji.common.web.BaseController;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-30 上午11:38:45<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
@RequestMapping("/sample/json")
public class SampleJsonController extends BaseController
{
	@RequestMapping("/show.do")
	public void showJson(HttpServletRequest request, @ModelAttribute("queryModel") Sample sample,
			HttpServletResponse response) throws IOException
	{
		if (isGET(request)) sample.setMsg(iso2UTF8(sample.getMsg()));
		logger.debug("sample:{}", sample);
		sample.setId(System.currentTimeMillis());
		sample.setMsg("返回消息:" + sample.getMsg());
		response.setCharacterEncoding(UTF8);
		response.setContentType("text/plain; charset=UTF-8");
		response.getWriter().write(ZipHelper.compress("SAMPLE,@," + sample.toJson()));
	}
}
