package samples.cn.com.taiji.common.web;

import java.util.Calendar;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.WebRequest;

import cn.com.taiji.common.pub.TimeTools;
import cn.com.taiji.common.web.BaseController;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-8-3 下午03:35:22<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class RestSampleController extends BaseController
{
	@RequestMapping(value = "/{userId}/{username}")
	public String restSample(WebRequest request, @PathVariable("userId") Long userId,
			@PathVariable("username") String username, Model model)
	{
		// 检查客户端的缓存是否过期，没过期，不再生成数据
		if (request.checkNotModified(getLastModified())) return null;
		logger.debug("userId={},username={}", userId, username);
		model.addAttribute("userId", userId);
		model.addAttribute("username", username);
		return "rest/restSample";
	}

	public long getLastModified()
	{
		// 假定每分钟数据会有一次变动
		Calendar time = Calendar.getInstance();
		time.set(Calendar.SECOND, 0);
		time.set(Calendar.MILLISECOND, 0);
		logger.debug("lastmodified:{}", TimeTools.toTimeStr(time));
		return time.getTimeInMillis();
	}

}
