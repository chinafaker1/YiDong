/*
 * Date: 2012-5-28
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.model;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-5-28 下午2:55:58<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class UploadResponse extends BaseModel
{
	private boolean success;
	private String reason;

	public UploadResponse(boolean success, String reason)
	{
		super();
		this.success = success;
		this.reason = reason;
	}

	public boolean isSuccess()
	{
		return success;
	}

	public void setSuccess(boolean success)
	{
		this.success = success;
	}

	public String getReason()
	{
		return reason;
	}

	public void setReason(String reason)
	{
		this.reason = reason;
	}

}
