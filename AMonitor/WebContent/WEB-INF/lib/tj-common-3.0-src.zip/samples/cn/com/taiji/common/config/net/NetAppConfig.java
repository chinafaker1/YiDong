package samples.cn.com.taiji.common.config.net;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cn.com.taiji.common.manager.net.nio.NioServer;
import cn.com.taiji.common.manager.net.nio.NioServerHandler;
import cn.com.taiji.common.manager.net.nio.NioServerImpl;
import cn.com.taiji.common.manager.net.snmp.SnmpClient;
import cn.com.taiji.common.manager.net.snmp.SnmpClientImpl;
import cn.com.taiji.common.manager.net.snmp.SnmpTrapServer;
import cn.com.taiji.common.manager.net.snmp.SnmpTrapServerHandler;
import cn.com.taiji.common.manager.net.snmp.SnmpTrapServerImpl;
import cn.com.taiji.common.manager.net.snmp.SnmpV3TrapServerImpl;
import cn.com.taiji.common.manager.net.udp.UDPServer;
import cn.com.taiji.common.manager.net.udp.UDPServerHandler;
import cn.com.taiji.common.manager.net.udp.UDPServerImpl;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-23 下午03:02:03<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Configuration
public class NetAppConfig
{
	@Value("#{netProperties.nioPort}")
	private int nioPort;
	@Autowired
	private NioServerHandler nioServerHandler;

	@Value("#{netProperties.snmpPort}")
	private int snmpPort;
	@Value("#{netProperties.snmpV3Port}")
	private int snmpV3Port;
	@Autowired
	private SnmpTrapServerHandler trapHandler;

	@Autowired
	private UDPServerHandler udpHandler;
	@Value("#{netProperties.udpBuffLen}")
	private int udpBuffLen;
	@Value("#{netProperties.udpPort}")
	private int udpPort;

	@Bean(name = "nioServer")
	public NioServer nioServer()
	{
		NioServer server = new NioServerImpl(nioPort, nioServerHandler);
		return server;
	}

	@Bean(name = "snmpTrapServer")
	public SnmpTrapServer snmpTrapServer()
	{
		SnmpTrapServerImpl server = new SnmpTrapServerImpl(snmpPort);
		server.setHandler(trapHandler);
		return server;
	}

	@Bean(name = "snmpV3TrapServer")
	public SnmpTrapServer snmpV3TrapServer()
	{
		SnmpV3TrapServerImpl server = new SnmpV3TrapServerImpl(snmpV3Port);
		server.setHandler(trapHandler);
		return server;
	}

	@Bean(name = "snmpClient", destroyMethod = "stop")
	public SnmpClient snmpClient()
	{
		return new SnmpClientImpl();
	}

	@Bean(name = "udpServer")
	public UDPServer udpServer()
	{
		return new UDPServerImpl(udpBuffLen, udpHandler, udpPort);
	}
}
