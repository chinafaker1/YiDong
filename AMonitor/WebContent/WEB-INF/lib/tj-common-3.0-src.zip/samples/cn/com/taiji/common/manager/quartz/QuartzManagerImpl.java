package samples.cn.com.taiji.common.manager.quartz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;

import samples.cn.com.taiji.common.manager.net.ws.CxfSample;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-25 上午10:47:29
 * @since 1.0
 * @version 1.0
 */
@Service("quartzManager")
public class QuartzManagerImpl extends AbstractManager implements QuartzManager
{
	@Autowired
	private CxfSample cxfSample;

	@Scheduled(cron = "0 0/30 * * * ?")
	public void runSampleJob()
	{
		logger.info("Running sample job ...");
		cxfSample.sayHi("ccc");
	}

	public void runClusterJob()
	{
		logger.info("Running cluster job.");
		cxfSample.sayHi("ccc");
	}

}
