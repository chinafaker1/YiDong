package samples.cn.com.taiji.common.web.ajax;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.pub.StringTools;

import samples.cn.com.taiji.common.model.ajax.AjaxFormModel;

@Controller
public class AjaxFormController {

	@RequestMapping("/ajaxIndex.do")
	public String ajaxIndex(Model model)
	{
		model.addAttribute("pagn", this.getAll(1));
		return "samples/ajax/ajaxPageIndex";
	}
	
	@RequestMapping("/ajaxForm.do")
	public String ajaxForm(@ModelAttribute AjaxFormModel info,
			Model model, HttpServletRequest request){
		if(StringTools.hasText(info.getId()))
			info.setId("%"+info.getId()+"%");
		model.addAttribute("pagn", this.getAll(info.getPage()));
		return "samples/ajax/ajaxPageList";
	}
	
	
	
	private Pagination getAll(int page){
		Pagination pagn = new Pagination(page,16,33);
		List<String[]> result = new ArrayList<String[]>();
		for(int i=0;i<16;i++){
			String[] temp = new String[]{page+"页，id"+i,"name"+i,"date="+i};
			result.add(temp);
		}
		pagn.setResult(result);
		return pagn;
	}
}
