package samples.cn.com.taiji.common.web.doc;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.pub.PdfContentInfo;
import cn.com.taiji.common.web.BasePdfTemplateController;

import samples.cn.com.taiji.common.model.pub.UsedCarNorm;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-7-15 下午05:35:49<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SamplePdfTemplateController extends BasePdfTemplateController
{
	public SamplePdfTemplateController()
	{
		super("file:" + FileHelper.getWebappPath() + "/template/usedCarTemplate.html");
	}

	@RequestMapping({ "/download/pdfTemplate.do", "/download/pdfTemplate.service" })
	public void downloadPdf(HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
		PdfContentInfo info = new PdfContentInfo();
		info.setAlwaysNew(true);
		info.setFonts(getFonts());
		info.setFileName("mysample.pdf");
		info.setContents(getContents(request));

		super.generatePdf(request, response, "模板示例.pdf", info);
	}

	private Map<String, Object> getContents(HttpServletRequest request)
	{
		UsedCarNorm norm = UsedCarNorm.sampleInstance();
		Map<String, Object> map = new HashMap<String, Object>();
		Calendar noValidTime = (Calendar) norm.getTime().clone();
		noValidTime.add(Calendar.MONTH, 6);
		noValidTime.add(Calendar.DAY_OF_YEAR, -1);
		map.put("norm", norm);
		map.put("noValidTime", noValidTime);
		map.put("rootUrl", getRootUrl(request));
		return map;
	}

	private List<String> getFonts()
	{
		List<String> fonts = new ArrayList<String>();
		fonts.add(FileHelper.getWebappPath() + "/template/ttf/simhei.ttf");
		fonts.add(FileHelper.getWebappPath() + "/template/ttf/simsun.ttc");
		return fonts;
	}
}
