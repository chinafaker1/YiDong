package samples.cn.com.taiji.common.manager.net.nio;

import java.io.IOException;

import cn.com.taiji.common.manager.net.nio.NioClientHandler;

import samples.cn.com.taiji.common.model.net.nio.UserRequest;
import samples.cn.com.taiji.common.model.net.nio.UserResponse;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-24 下午06:05:33<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface SampleNioClientHandler extends NioClientHandler
{
	/**
	 * 
	 * @param request
	 * @param readTimeoutMillis
	 *            小于等于0时不超时
	 * @return
	 * @throws IOException
	 */
	public UserResponse findUser(UserRequest request, int readTimeoutMillis) throws IOException;
}
