package samples.cn.com.taiji.common.web.jquery;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.WebUtils;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.pub.WebDebugUtil;
import cn.com.taiji.common.web.BaseDownloadController;

import samples.cn.com.taiji.common.entity.SampleEntity;
import samples.cn.com.taiji.common.web.SampleQueryModel;

/**
 * jQuery1.4的示例代码
 * 
 * @author TOM email:tomesc@msn.com
 */
@Controller
public class SamplePage14QueryController extends BaseDownloadController
{

	/**
	 * 进入管理页面
	 * 
	 * @param qm
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/jquery14/manage.do", method = RequestMethod.GET)
	public String manageGet(@ModelAttribute("queryModel") SampleQueryModel qm, Model model,
			HttpServletResponse response) throws IOException
	{
		logger.debug("query model in GET:{}", qm);
		response.setHeader("myheader", "ccc");
		return "samples/jquery14/manage";
	}

	/**
	 * 管理页面执行查询
	 * 
	 * @param qm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/manage.do", method = RequestMethod.POST)
	public String managePost(@ModelAttribute("queryModel") SampleQueryModel qm,
			HttpServletRequest request, Model model)
	{
		logger.debug("query model in POST:{}", qm);
		WebDebugUtil.echoRequestParams(request);
		Pagination pg = getPg(qm.getPageNo(), 290, qm.getPageSize());
		model.addAttribute("pagn", pg);
		return "samples/jquery14/queryResult";
	}

	/**
	 * 进入添加页面
	 * 
	 * @param sampleEntity
	 * @return
	 */
	@RequestMapping(value = "/jquery14/add.do", method = RequestMethod.GET)
	public String setupAdd(@ModelAttribute("pageModel") SampleEntity sampleEntity)
	{
		return "samples/jquery14/add";
	}

	/**
	 * 执行添加操作
	 * 
	 * @param sampleEntity
	 * @param model
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/jquery14/add.do", method = RequestMethod.POST)
	public String processAdd(@ModelAttribute("pageModel") SampleEntity sampleEntity, Model model,
			HttpServletResponse response)
	{
		if (sampleEntity.getIntValue() < 5)
		{
			addError(model, "添加的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "添加成功");
		model.addAttribute("vo", sampleEntity);
		return "samples/jquery14/result";
	}

	/**
	 * 进入修改页面
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/edit.do", method = RequestMethod.GET)
	public String setupEdit(@RequestParam("id") int id, Model model)
	{
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("pageModel", entity);

		return "samples/jquery14/edit";
	}

	/**
	 * 执行修改操作
	 * 
	 * @param sampleEntity
	 * @param model
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/jquery14/edit.do", method = RequestMethod.POST)
	public String processEdit(@ModelAttribute("pageModel") SampleEntity sampleEntity, Model model,
			HttpServletResponse response)
	{
		if (sampleEntity.getIntValue() < 5)
		{
			addError(model, "修改的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "修改成功");
		model.addAttribute("vo", sampleEntity);
		return "samples/jquery14/result";
	}

	/**
	 * 查看指定记录详情
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/view.do")
	public String view(@RequestParam("id") int id, Model model)
	{
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("pageModel", entity);
		return "samples/jquery14/view";
	}

	/**
	 * 删除指定记录
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/del.do")
	public String delete(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "删除的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "删除成功");
		return "samples/jquery14/result";
	}

	/**
	 * update指定记录
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/update.do")
	public String update(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "操作(update)的intValue小于5的数据，就会报错。。。");
			return "noteInfo";
		}
		addSuccess(model, "操作(update)成功");
		return "noteInfo";
	}

	/**
	 * operate指定记录
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/operate.do")
	public String operate(@RequestParam("id") int id, Model model)
	{
		try
		{
			logger.debug("进入休眠状态");
			Thread.sleep(1000 * 5);
		}
		catch (InterruptedException e)
		{
			logger.error("",e);
		}
		if (id < 5)
		{
			addError(model, "操作(operate)的intValue小于5的数据，就会报错。。。");
			return "noteInfo";
		}
		addSuccess(model, "操作(operate)成功");
		return "noteInfo";
	}

	/**
	 * 进入popupRemove弹出页
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/popupRemove.do", method = RequestMethod.GET)
	public String setupPopupRemove(@RequestParam("id") int id, Model model)
	{
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("pageModel", entity);
		return "samples/jquery14/popupRemove";
	}

	/**
	 * 执行popupRemove操作
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/jquery14/popupRemove.do", method = RequestMethod.POST)
	public String processPopupRemove(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "操作的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "操作(popupRemove)成功");
		return "samples/jquery14/result";
	}

	/**
	 * 下载操作
	 * 
	 * @param id
	 * @param response
	 * @param request
	 * @param model
	 * @throws IOException
	 */
	@RequestMapping(value = "/jquery14/download.do", method = RequestMethod.POST)
	public void processDownload(@RequestParam("id") int id, HttpServletResponse response,
			HttpServletRequest request, Model model) throws IOException
	{
		if (id < 5)
		{
			addError(model, "下载的intValue小于5的数据，就会报错。。。");
			// return "samples/jquery14/result";
		}
		File file = null;
		try
		{
			file = new File(WebUtils.getRealPath(request.getSession().getServletContext(),
					"/style/main.css"));
		}
		catch (FileNotFoundException e)
		{
			addError(model, "文件不存在。。。");
			// return "samples/jquery14/result";
		}
		super.doDownLoad(request, response, new FileInputStream(file), file.getName());
		addSuccess(model, "下载了吗？。。。");
		// return "samples/jquery14/result";
	}

	/**
	 * 辅助方法，获取分页内容
	 * 
	 * @param currentPage
	 * @param total
	 * @param pageSize
	 * @return
	 */
	private Pagination getPg(int currentPage, long total, int pageSize)
	{
		Pagination pg = new Pagination();
		pg.setCurrentPage(currentPage);
		pg.setTotalCount(total);
		pg.setPageSize(pageSize);
		pg.setPageCount(Pagination.getPageCount(pg.getTotalCount(), pg.getPageSize()));
		List<SampleEntity> rs = new ArrayList<SampleEntity>();
		int first = (pg.getCurrentPage() - 1) * pg.getPageSize() + 1;
		int last = pg.getCurrentPage() * pg.getPageSize();
		for (int i = first; i <= last; i++)
		{
			SampleEntity entity = new SampleEntity();
			entity.setBoolValue((i % 2 == 0));
			Calendar now = Calendar.getInstance();
			now.add(Calendar.HOUR_OF_DAY, i);
			entity.setCalValue(now);
			entity.setIntValue(i);
			entity.setFloatValue(Double.valueOf(i * 0.616).floatValue());
			entity.setStrValue("文本信息 " + i);
			rs.add(entity);
			if (i >= total) break;
		}
		pg.setResult(rs);
		return pg;
	}

	/**
	 * 进入选择用户页面
	 * 
	 * @param fieldId
	 * @param model
	 * @return
	 */
	@RequestMapping("/jquery14/selectUser.do")
	public String selectUser(@RequestParam("fieldId") String fieldId, Model model)
	{
		model.addAttribute("users", getUsers());
		model.addAttribute("fieldId", fieldId);
		logger.debug(fieldId);
		return "samples/jquery14/selectUser";
	}

	private List<User> getUsers()
	{
		List<User> users = new ArrayList<User>();
		for (int i = 0; i < 10; i++)
		{
			User user = new User();
			user.setId(String.valueOf(i));
			user.setName("用户" + i);
			users.add(user);
		}
		return users;
	}

	public static class User
	{
		private String name;
		private String id;

		public String getName()
		{
			return name;
		}

		public void setName(String name)
		{
			this.name = name;
		}

		public String getId()
		{
			return id;
		}

		public void setId(String id)
		{
			this.id = id;
		}
	}
}
