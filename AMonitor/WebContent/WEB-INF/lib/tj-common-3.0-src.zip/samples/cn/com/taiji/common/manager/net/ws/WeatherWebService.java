/*
 * Date: 2011-9-26
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.manager.net.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;

import samples.cn.com.taiji.common.model.net.ws.webxml.ArrayOfString;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-9-26 下午2:36:38<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@WebService
public interface WeatherWebService
{
	@WebMethod(operationName = "getSupportCity")
	public ArrayOfString getSupportCity(String byProvinceName);

	@WebMethod(operationName = "getWeatherbyCityName")
	public ArrayOfString getWeatherbyCityName(String theCityName);

	@WebMethod(operationName = "getSupportProvince")
	public ArrayOfString getSupportProvince();

	@WebMethod(operationName = "getWeatherbyCityNamePro")
	public ArrayOfString getWeatherbyCityNamePro(String theCityName, String theUserId);
}
