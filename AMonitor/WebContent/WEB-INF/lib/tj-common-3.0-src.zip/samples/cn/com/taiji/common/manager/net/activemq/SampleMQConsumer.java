package samples.cn.com.taiji.common.manager.net.activemq;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.StreamMessage;

import org.apache.activemq.command.ActiveMQBlobMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.pub.StringTools;

import tests.BaseTest;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-20 下午03:15:05
 * @since 1.0
 * @version 1.0
 */
@Service("sampleMQConsumer")
public class SampleMQConsumer extends AbstractManager
{
	private static final String PATH;
	static
	{
		PATH = "E:/tmp";
	}

	public void receive(String msg)
	{
		logger.debug(msg);
	}

	public void receive(Serializable obj) throws IOException, JMSException
	{
		logger.debug("obj:{}", obj);
		if (obj instanceof SampleMQObj)
		{
			SampleMQObj msg = (SampleMQObj) obj;
			logger.debug("" + msg.getId());
			BaseTest.echoList(msg.getList());
		}
	}

	public void receive(StreamMessage msg) throws Exception
	{
		logger.debug("stream msg:{}", msg);
		FileOutputStream out = new FileOutputStream(new File(PATH + "/receiveFile"));
		byte[] buff = new byte[18192];
		int read = -1;
		while ((read = msg.readBytes(buff)) != -1)
		{
			logger.debug("read={}", read);
			out.write(buff, 0, read);
		}
		logger.debug("after write:read={}", read);
		out.flush();
		out.close();
		msg.clearBody();
	}

	public void receive(ActiveMQBlobMessage msg) throws IOException, JMSException
	{
		logger.debug(msg.toString());
		String fileName = msg.getStringProperty("file.name");
		logger.debug("file.name={}", fileName);
		InputStream in = msg.getInputStream();
		String myName = StringTools.hasText(fileName) ? fileName : "unknown";
		FileOutputStream out = new FileOutputStream(new File("E:/tmp/" + myName));
		FileCopyUtils.copy(in, out);
	}
}
