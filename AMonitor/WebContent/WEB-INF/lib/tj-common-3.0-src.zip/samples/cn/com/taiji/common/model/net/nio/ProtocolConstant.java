package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-7 下午01:46:41<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class ProtocolConstant
{
	/**
	 * 命令结束符
	 */
	public static final String CMD_SPLIT = "<@>\r\n";

	/**
	 * 命令数据分割符
	 */
	public static final String DATA_SPLIT = ",@,";
}
