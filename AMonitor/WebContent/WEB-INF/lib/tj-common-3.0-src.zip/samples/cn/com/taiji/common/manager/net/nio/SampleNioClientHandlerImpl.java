package samples.cn.com.taiji.common.manager.net.nio;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.nio.BufferUnderflowException;
import java.nio.channels.ClosedChannelException;

import org.xsocket.MaxReadSizeExceededException;
import org.xsocket.connection.BlockingConnection;
import org.xsocket.connection.IBlockingConnection;
import org.xsocket.connection.INonBlockingConnection;

import cn.com.taiji.common.manager.net.nio.AbstractNioClientHandler;

import samples.cn.com.taiji.common.model.net.nio.AuthProtocol;
import samples.cn.com.taiji.common.model.net.nio.ProtocolConstant;
import samples.cn.com.taiji.common.model.net.nio.ProtocolParser;
import samples.cn.com.taiji.common.model.net.nio.UserRequest;
import samples.cn.com.taiji.common.model.net.nio.UserResponse;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-24 下午06:06:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class SampleNioClientHandlerImpl extends AbstractNioClientHandler implements
		SampleNioClientHandler
{
	private final String mcode;
	private final String password;

	private Object lock = new Object();

	public SampleNioClientHandlerImpl(String mcode, String password)
	{
		this.mcode = mcode;
		this.password = password;
	}

	@SuppressWarnings("resource")
	public UserResponse findUser(UserRequest request, int readTimeoutMillis) throws IOException
	{
		// 需要同步
		synchronized (lock)
		{
			if (getClient() == null) throw new IOException("You must start the NioClient first.");
			IBlockingConnection conn = new BlockingConnection(getClient().getConnection());
			conn.write(request.toProtocolString());
			if (readTimeoutMillis > 0) conn.setReadTimeoutMillis(readTimeoutMillis);
			try
			{
				String data = conn.readStringByDelimiter(ProtocolConstant.CMD_SPLIT);
				UserResponse response = ProtocolParser.parseUserResponse(data);
				logger.debug("{}\t{}", request.toString(), response.toString());
				return response;
			}
			catch (SocketTimeoutException e)
			{
				// 超时后废弃该连接,否则可能引起数据返回与请求不对应
				getClient().getConnection().close();
				throw e;
			}
		}
	}

	public boolean onData(INonBlockingConnection connection) throws IOException,
			BufferUnderflowException, ClosedChannelException, MaxReadSizeExceededException
	{
		String res = connection.readStringByDelimiter(ProtocolConstant.CMD_SPLIT);
		logger.debug("服务器返回：" + res);
		return true;
	}

	public boolean onConnect(INonBlockingConnection connection) throws IOException,
			BufferUnderflowException, MaxReadSizeExceededException
	{
		logger.debug("连接成功后，发送验证消息...");
		AuthProtocol protocol = new AuthProtocol();
		protocol.setMcode(mcode);
		protocol.setPassword(password);
		connection.write(protocol.toProtocolString());
		return true;
	}

	public boolean onDisconnect(INonBlockingConnection connection) throws IOException
	{
		return true;
	}
}
