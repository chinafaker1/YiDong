package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 下午02:01:46<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class AuthProtocol extends AbstractNioProtocol
{
	private String mcode;
	private String password;

	public AuthProtocol()
	{
		super(ProtocolType.AUTH);
	}

	public String getMcode()
	{
		return mcode;
	}

	public void setMcode(String mcode)
	{
		this.mcode = mcode;
	}

	public String getPassword()
	{
		return password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	@Override
	public String toProtocolString()
	{
		return type.toString() + ProtocolConstant.DATA_SPLIT + mcode + ProtocolConstant.DATA_SPLIT + password
				+ ProtocolConstant.CMD_SPLIT;
	}

	@Override
	public String toString()
	{
		return "AuthProtocol [mcode=" + mcode + ", password=" + password + ", type=" + type + "]";
	}

}
