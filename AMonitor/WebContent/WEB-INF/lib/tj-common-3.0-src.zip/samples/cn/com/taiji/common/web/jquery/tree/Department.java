package samples.cn.com.taiji.common.web.jquery.tree;

import java.util.ArrayList;
import java.util.List;

import cn.com.taiji.common.entity.LongIdEntity;


/**
 * @author TOM Email:tomesc@msn.com 
 *
 */
public class Department extends LongIdEntity
{
	private String name;
	private int list;
	private Department parent;
	
	private boolean hasChild = false;
	private List<Department> childs = new ArrayList<Department>();
	private Long parentid;
	
	
	
	public Long getParentid()
	{
		return parentid;
	}

	public void setParentid(Long parentid)
	{
		this.parentid = parentid;
	}

	public void addChild(Department child){
		if(childs == null)
			childs = new ArrayList<Department>();
		childs.add(child);
	}
	
	public boolean isHasChild()
	{
		return hasChild;
	}
	public void setHasChild(boolean hasChild)
	{
		this.hasChild = hasChild;
	}
	public List<Department> getChilds()
	{
		return childs;
	}
	public void setChilds(List<Department> childs)
	{
		this.childs = childs;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getList()
	{
		return list;
	}
	public void setList(int list)
	{
		this.list = list;
	}
	public Department getParent()
	{
		return parent;
	}
	public void setParent(Department parent)
	{
		this.parent = parent;
	}
	@Override
	public String toString()
	{
		return "Department [id=" + id + ", name=" + name + ", parent=" + parent + "]";
	}

}
