/* 
 * @author Sunny(sunoke@126.com)
 * Date： 2009-7-17
 */
package samples.cn.com.taiji.common.web.editor;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.file.FileTools;

import samples.cn.com.taiji.common.model.editor.FileUploadModel;

@Controller
public class SampleTinymceForm {
	@RequestMapping(value = "/editor/tinymce.do")
	public String tinymce(HttpServletRequest request, Model model)
	{
		return "samples/editor/tinymce";
	}

	
	@RequestMapping("/plugin/upload.do")
	public void insertImage(@ModelAttribute FileUploadModel uploadFile, HttpServletRequest req,
			HttpServletResponse res)
	{
		req.getContextPath();
		StringBuilder imgVisitPath = new StringBuilder();
		StringBuilder imgSaveBasePath = new StringBuilder();
		imgVisitPath.append(req.getContextPath()).append("/tmp/");
		imgSaveBasePath.append(FileHelper.getTmpPath());
		MultipartFile file = uploadFile.getUploadFile();
		try
		{
			if (file != null && !file.isEmpty())
			{
				String fileName = FileTools.generateUUIDName(file.getOriginalFilename());
				File f = FileTools.input2File(FileHelper.getTmpPath(), file.getInputStream(),
						fileName, false);
				imgVisitPath.append(f.getName());
			}
			res.setContentType("text/html");
			res.setCharacterEncoding("utf-8");

			res.getWriter().write(
					"<script>parent.callback('" + imgVisitPath.toString() + "')</script>");
		}
		catch (IOException e)
		{
		}
	}

}
