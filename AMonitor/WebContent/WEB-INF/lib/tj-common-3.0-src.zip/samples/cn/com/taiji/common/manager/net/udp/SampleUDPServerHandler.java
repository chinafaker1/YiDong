package samples.cn.com.taiji.common.manager.net.udp;

import java.io.IOException;

import org.springframework.stereotype.Service;
import org.xsocket.datagram.IEndpoint;
import org.xsocket.datagram.UserDatagram;

import cn.com.taiji.common.manager.net.AbstractNetHandler;
import cn.com.taiji.common.manager.net.udp.UDPServerHandler;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 上午09:12:29
 * @since 1.0
 * @version 1.0
 */
@Service("sampleUDPServerHandler")
public class SampleUDPServerHandler extends AbstractNetHandler implements UDPServerHandler
{

	private final String encoding;

	public SampleUDPServerHandler()
	{
		this("UTF-8");
	}

	public SampleUDPServerHandler(String encoding)
	{
		this.encoding = encoding;
	}

	public boolean onDatagram(IEndpoint localEndpoint) throws IOException
	{
		UserDatagram datagram = localEndpoint.receive();
		String str = datagram.readString(encoding);
		logger.debug("handle the udp datagram:{}", str);
		return true;
	}
}
