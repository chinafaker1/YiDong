package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 下午06:32:18<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class UserRequest extends AbstractNioProtocol
{
	private String loginname;

	public String getLoginname()
	{
		return loginname;
	}

	public void setLoginname(String loginname)
	{
		this.loginname = loginname;
	}

	public UserRequest()
	{
		super(ProtocolType.USER_REQUEST);
	}

	@Override
	public String toProtocolString()
	{
		return type.toString() + ProtocolConstant.DATA_SPLIT + loginname + ProtocolConstant.CMD_SPLIT;
	}

	@Override
	public String toString()
	{
		return "UserRequest [loginname=" + loginname + ", type=" + type + "]";
	}

}
