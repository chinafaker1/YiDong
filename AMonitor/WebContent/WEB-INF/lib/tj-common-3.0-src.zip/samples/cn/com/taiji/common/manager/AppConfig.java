package samples.cn.com.taiji.common.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import cn.com.taiji.common.pub.ProjectEnv;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-18 上午09:55:00<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Configuration
public class AppConfig
{
	@Value("#{commonProperties.envEth}")
	private String eth;
	@Value("#{systemProperties['webapp.ccc']}")
	private String webappPath;

	@Bean
	public ProjectEnv projectEnv()
	{
		ProjectEnv projectEnv = new ProjectEnv(eth);
		projectEnv.setWebappPath(webappPath);
		return projectEnv;
	}

	@Bean(name = "messageSource")
	@Autowired
	public MessageSource messageSource(ProjectEnv projectEnv)
	{
		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasenames(new String[] { "common" });
		return source;
	}
}
