package samples.cn.com.taiji.common.manager.net.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;

import samples.cn.com.taiji.common.model.net.ws.SampleMsg;
import samples.cn.com.taiji.common.model.net.ws.SampleRequest;
import samples.cn.com.taiji.common.model.net.ws.SampleResponse;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-13 上午10:38:55
 * @since 1.0
 * @version 1.0
 */
@WebService
public interface CxfSample
{
	@WebMethod
	public String sayHi(String text);

	@WebMethod
	public SampleMsg handMsg(SampleMsg msg);

	@WebMethod
	public SampleResponse echo(SampleRequest request);
}
