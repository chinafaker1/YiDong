/* 
 * @author Sunny(sunoke@126.com)
 * Date： 2009-8-21
 */
package samples.cn.com.taiji.common.web.editor;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.file.FileTools;
import cn.com.taiji.common.web.BaseController;

import samples.cn.com.taiji.common.manager.editor.ArticleManager;
import samples.cn.com.taiji.common.model.editor.ArticleModel;
import samples.cn.com.taiji.common.model.editor.AttachModel;
import samples.cn.com.taiji.common.model.editor.FileUploadModel;

@Controller
public class SampleArticleForm extends BaseController
{
	@Autowired
	private ArticleManager articleManager;

	@RequestMapping(value = "/editor/articleAdd.do", method = RequestMethod.GET)
	public String articleAddGet(HttpServletRequest request, Model model)
	{
		ArticleModel pageModel = new ArticleModel();
		model.addAttribute("pageModel", pageModel);
		return "samples/editor/articleAdd";
	}

	@RequestMapping(value = "/editor/articleAdd.do", method = RequestMethod.POST)
	public String articleAddPost(HttpServletRequest request, Model model,
			@ModelAttribute("pageModel") ArticleModel pageModel)
	{
		try
		{
			articleManager.txAdd(pageModel);
		}
		catch (ManagerException e)
		{
			logger.error("错误：", e);
		}
		catch (FileNotFoundException e)
		{
			logger.error("错误：", e);
		}

		// 以下部分是显示新添加的内容
		return articleView(model, pageModel);
	}

	@RequestMapping(value = "/editor/articleMod.do", method = RequestMethod.GET)
	public String articleModGet(HttpServletRequest request, Model model, @RequestParam("id") String id)
	{
		try
		{
			ArticleModel pageModel = articleManager.findById(id);

			// 构建初始内容和附件
			pageModel.setContent("初始内容");
			List<AttachModel> attachs = new ArrayList<AttachModel>();
			String[] attachStr = new String[] { "附件1", "附件2" };
			for (String str : attachStr)
			{
				AttachModel attach = new AttachModel();
				attach.setId("id" + str);
				attach.setFileName(str);
				attachs.add(attach);
			}
			pageModel.setAttachs(attachs);
			// 构建初始内容和附件

			model.addAttribute("pageModel", pageModel);
		}
		catch (ManagerException e)
		{
			logger.error("错误：", e);
		}
		return "samples/editor/articleMod";
	}

	@RequestMapping(value = "/editor/articleMod.do", method = RequestMethod.POST)
	public String articleModPost(HttpServletRequest request, Model model,
			@ModelAttribute("pageModel") ArticleModel pageModel)
	{
		try
		{
			articleManager.txUpdate(pageModel);
		}
		catch (ManagerException e)
		{
			logger.error("错误：", e);
		}
		catch (FileNotFoundException e)
		{
			logger.error("错误：", e);
		}
		// 以下部分是显示新添加的内容
		return articleView(model, pageModel);
	}

	// 模拟增加、修改后的信息
	public String articleView(Model model, ArticleModel pageModel)
	{
		List<AttachModel> attachs = new ArrayList<AttachModel>();
		String[] attachStr = pageModel.getAttachmentList();
		if (attachStr != null)
		{
			for (String str : attachStr)
			{
				AttachModel attach = new AttachModel();
				attach.setFileName(str.split("@@@")[0]);
				attachs.add(attach);
			}

		}
		pageModel.setAttachs(attachs);
		model.addAttribute("pageModel", pageModel);
		return "samples/editor/articleView";
	}

	@RequestMapping(value = "/file/fileUp.do", method = RequestMethod.GET)
	public String setupFileUpForm(HttpServletRequest request, Model model) throws ManagerException
	{
		FileUploadModel vo = new FileUploadModel();
		model.addAttribute("MultipartFileUpModel", vo);
		return "samples/editor/fileUp";
	}

	@RequestMapping(value = "/file/fileUp.do", method = RequestMethod.POST)
	public String processFileUpSubmit(HttpServletRequest request, Model model,
			@ModelAttribute FileUploadModel multipartFileUpModel)
	{
		// 测试设定最大文件值
		final long MAX_FILE_SIZE = 10000000;
		try
		{
			MultipartFile mFile = multipartFileUpModel.getUploadFile();
			if (mFile == null || mFile.getSize() < 1 || mFile.getSize() > MAX_FILE_SIZE)
			{
				String str = "不在系统附件大小范围内:(0-" + MAX_FILE_SIZE / 1048576 + ")M";
				model.addAttribute("reCmd", "N");
				model.addAttribute("reStr", str);
				return "samples/editor/fileUp";
			}
			String fileName = FileTools.generateUUIDName(mFile.getOriginalFilename());
			FileTools.input2File(FileHelper.getTmpPath(), mFile.getInputStream(), fileName, false);
			model.addAttribute("reCmd", "Y");
			model.addAttribute("reStr", fileName);
		}
		catch (Exception e)
		{
			model.addAttribute("reCmd", "N");
			model.addAttribute("reStr", "文件上传失败" + e.getMessage());
		}
		return "samples/editor/fileUp";
	}

}
