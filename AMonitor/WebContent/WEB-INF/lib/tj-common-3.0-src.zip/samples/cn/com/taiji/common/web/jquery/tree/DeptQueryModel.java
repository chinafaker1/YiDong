package samples.cn.com.taiji.common.web.jquery.tree;

import cn.com.taiji.common.model.PaginModel;

public class DeptQueryModel extends PaginModel
{
	private Long deptParentId;
	private String deptName;

	public Long getDeptParentId()
	{
		return deptParentId;
	}

	public void setDeptParentId(Long deptParentId)
	{
		this.deptParentId = deptParentId;
	}

	public String getDeptName()
	{
		return deptName;
	}

	public void setDeptName(String deptName)
	{
		this.deptName = deptName;
	}
}
