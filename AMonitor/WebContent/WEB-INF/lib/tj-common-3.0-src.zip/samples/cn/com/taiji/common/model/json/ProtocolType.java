/*
 * Date: 2012-6-14
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.model.json;

import cn.com.taiji.common.model.json.AbstractProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-6-14 下午1:12:58<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public enum ProtocolType
{
	RES_COMMON("通用返回", CommonResponse.class) {},
	;
	private String value;
	private Class<? extends AbstractProtocol> clazz;

	private ProtocolType(String value, Class<? extends AbstractProtocol> clazz)
	{
		this.value = value;
		this.clazz = clazz;
	}

	public String getValue()
	{
		return value;
	}

	public Class<? extends AbstractProtocol> getClazz()
	{
		return clazz;
	}
}
