package samples.cn.com.taiji.common.model.ajax;

import cn.com.taiji.common.model.BaseModel;

public class AjaxFormModel extends BaseModel
{
	private String id;
	private String name;
	private String begDate;

	private int page;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getBegDate()
	{
		return begDate;
	}

	public void setBegDate(String begDate)
	{
		this.begDate = begDate;
	}

	public int getPage()
	{
		return page;
	}

	public void setPage(int page)
	{
		this.page = page;
	}

}
