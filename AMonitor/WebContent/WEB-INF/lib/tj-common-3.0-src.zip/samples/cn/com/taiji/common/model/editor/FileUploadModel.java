package samples.cn.com.taiji.common.model.editor;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadModel
{
	private MultipartFile uploadFile;

	public MultipartFile getUploadFile()
	{
		return uploadFile;
	}

	public void setUploadFile(MultipartFile uploadFile)
	{
		this.uploadFile = uploadFile;
	}

}
