package samples.cn.com.taiji.common.model.net.ws;

import java.io.Serializable;
import java.util.Calendar;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 下午05:22:22
 * @since 1.0
 * @version 1.0
 */
public class SampleMsg extends BaseModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1914969672325237673L;
	private int id;
	private String msg;
	private Calendar time = Calendar.getInstance();

	public SampleMsg()
	{

	}

	public SampleMsg(int id, String msg)
	{
		this.id = id;
		this.msg = msg;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public Calendar getTime()
	{
		return time;
	}

	public void setTime(Calendar time)
	{
		this.time = time;
	}

}
