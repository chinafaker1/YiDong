package samples.cn.com.taiji.common.web.ajax;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.com.taiji.common.pub.TimeTools;

import samples.cn.com.taiji.common.model.ajax.SampleTreeBranchModel;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-9-4 上午09:54:05
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleAjaxController
{

	@RequestMapping("/sampleAjax.do")
	public String sampleAjax(Model model)
	{
		return "samples/ajax/ajax";
	}

	@RequestMapping("/samples/ajax/userName.do")
	public String userName(Model model,
			@RequestParam("userName") String userName)
	{
		String cmd = "Y";
		if (userName.equals("admin"))// 逻辑层代码
			cmd = "N";
//		cmd = cmd + "@@@Controller 回来的第二个信息";
		model.addAttribute("reCmd", cmd);
		return "samples/ajax/returnnote";
	}

	@RequestMapping("/samples/ajax/nowTime.do")
	public String nowTime(Model model)
	{
		String nowTime = TimeTools.toDateTimeStr(Calendar.getInstance());
		model.addAttribute("reCmd", nowTime);
		return "samples/ajax/returnnote";
	}

	@RequestMapping("/samples/ajax/tree.do")
	public String tree(Model model,@RequestParam("id")
			String id)
	{
		List <SampleTreeBranchModel>tree_branchs=new ArrayList<SampleTreeBranchModel>();
		
		//构造各树枝子节点开始
		for(int i=0;i<5;i++){
			SampleTreeBranchModel treeBranchModel=new SampleTreeBranchModel();			//分支
			treeBranchModel.setBranch_id(id+i);
			
			if(i==0||i==2||i==4){
				treeBranchModel.setHasChild(true);
				treeBranchModel.setBranch_name("测试分支节点"+id+i);
				treeBranchModel.setBranch_href("");
				tree_branchs.add(treeBranchModel);
				continue;
			}
			
			treeBranchModel.setHasChild(false);
			treeBranchModel.setBranch_name("测试叶子节点"+id+i);
			treeBranchModel.setBranch_href("#");
			tree_branchs.add(treeBranchModel);
		}
		//构造各树枝子节点结束
		model.addAttribute("tree_branchs",tree_branchs);
//		for (SampleTreeBranchModel sampleTreeBranchModel : tree_branchs) {
//			System.out.println(sampleTreeBranchModel.toString());
//			
//		}
		
		return "samples/ajax/treeBranchs";
	}

}
