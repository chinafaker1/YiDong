package samples.cn.com.taiji.common.manager.editor;

import java.io.FileNotFoundException;

import cn.com.taiji.common.manager.ManagerException;

import samples.cn.com.taiji.common.model.editor.ArticleModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-18 下午04:24:34<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface ArticleManager
{
	public void txAdd(ArticleModel pageModel) throws ManagerException, FileNotFoundException;

	public ArticleModel findById(String id) throws ManagerException;

	public void txUpdate(ArticleModel pageModel) throws ManagerException, FileNotFoundException;

}