package samples.cn.com.taiji.common.manager.net;

import java.io.File;
import java.io.IOException;

import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.net.ExecResultHandler;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-18 上午09:53:38
 * @since 1.0
 * @version 1.0
 */
public class EchoExecRsHandler implements ExecResultHandler
{
	public void handle(File file)
	{
		try
		{
			byte[] bytes = FileCopyUtils.copyToByteArray(file);
			String rs = new String(bytes);
			System.out.println("---------------result--------------" + rs.length());
			System.out.println(rs);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

}
