package samples.cn.com.taiji.common.model.net.ws;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 下午05:24:29
 * @since 1.0
 * @version 1.0
 */
public class SampleResponse extends BaseModel
{
	private String strMsg;
	private ArrayList<SampleMsg> listMsg;
	private HashMap<String, ArrayList<SampleMsg>> mapMsg;
	private int intMsg;

	public int getIntMsg()
	{
		return intMsg;
	}

	public void setIntMsg(int intMsg)
	{
		this.intMsg = intMsg;
	}

	public ArrayList<SampleMsg> getListMsg()
	{
		return listMsg;
	}

	public void setListMsg(ArrayList<SampleMsg> listMsg)
	{
		this.listMsg = listMsg;
	}

	public HashMap<String, ArrayList<SampleMsg>> getMapMsg()
	{
		return mapMsg;
	}

	public void setMapMsg(HashMap<String, ArrayList<SampleMsg>> mapMsg)
	{
		this.mapMsg = mapMsg;
	}

	public String getStrMsg()
	{
		return strMsg;
	}

	public void setStrMsg(String strMsg)
	{
		this.strMsg = strMsg;
	}

	public static SampleResponse getInstance(SampleRequest request)
	{
		System.out.println("============================");
		System.out.println("remoteRequest = " + request);
		System.out.println("intMsg = " + request.getIntMsg());
		System.out.println("strMsg = " + request.getStrMsg());
		List<SampleMsg> listMsg = request.getListMsg();
		for (SampleMsg msg : listMsg)
			System.out.println("sampleMsg = " + msg);
		HashMap<String, ArrayList<SampleMsg>> mapMsg = request.getMapMsg();
		Set<Entry<String, ArrayList<SampleMsg>>>set=mapMsg.entrySet();
		for (Entry<String, ArrayList<SampleMsg>> entry : set)
		{
			System.out.println("map key = " + entry.getKey());
			System.out.println("map value = " + mapMsg.get(entry.getKey()));
		}
		System.out.println("============================");
		SampleResponse response = new SampleResponse();
		response.setIntMsg(request.getIntMsg() + 1);
		response.setStrMsg(request.getStrMsg() + "response");
		response.setListMsg(request.getListMsg());
		response.setMapMsg(request.getMapMsg());
		return response;
	}

}
