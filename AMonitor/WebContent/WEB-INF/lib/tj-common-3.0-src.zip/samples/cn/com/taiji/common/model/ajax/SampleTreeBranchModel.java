package samples.cn.com.taiji.common.model.ajax;

import cn.com.taiji.common.model.BaseModel;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-9-9 上午09:42:55
 * @since 1.0
 * @version 1.0
 */
public class SampleTreeBranchModel extends BaseModel
{
	boolean hasChild = false; // 是否有子节点
	String branch_id = ""; // 分支id
	String branch_name = ""; // 分支名称
	String branch_href = ""; // 分支链接

	public boolean isHasChild()
	{
		return hasChild;
	}

	public void setHasChild(boolean hasChild)
	{
		this.hasChild = hasChild;
	}

	public String getBranch_id()
	{
		return branch_id;
	}

	public void setBranch_id(String branch_id)
	{
		this.branch_id = branch_id;
	}

	public String getBranch_name()
	{
		return branch_name;
	}

	public void setBranch_name(String branch_name)
	{
		this.branch_name = branch_name;
	}

	public String getBranch_href()
	{
		return branch_href;
	}

	public void setBranch_href(String branch_href)
	{
		this.branch_href = branch_href;
	}
}
