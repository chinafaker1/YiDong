package samples.cn.com.taiji.common.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.taiji.common.web.BaseController;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-6-23 下午07:25:57
 * @since 1.0
 * @version 1.0
 */
@Controller("myWelcomeController")
public class WelcomeController extends BaseController
{
	@RequestMapping("/myIndex.do")
	public String showIndex()
	{
		return "index";
	}
}
