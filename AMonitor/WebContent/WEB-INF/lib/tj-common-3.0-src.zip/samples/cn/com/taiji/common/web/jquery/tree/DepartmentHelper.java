package samples.cn.com.taiji.common.web.jquery.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.dao.Pagination;


/**
 * @author TOM Email:tomesc@msn.com
 * 
 */
public class DepartmentHelper
{

	public List<Department> getByParent(Long id)
	{
		if (id == null)
		{
			Department de = map.get(Long.valueOf(1));
			return Arrays.asList(de);
		}
		Department parent = map.get(id);
		if (parent == null)
		{
			return new ArrayList<Department>();
		}
		return parent.getChilds();
	}

	public void update(Department department) throws ManagerException
	{
		Department old = map.get(department.getId());
		old.setName(department.getName());
		old.setList(department.getList());
	}

	public Long add(Department department) throws ManagerException
	{
		if (department.getParentid() == null)
		{
			throw new ManagerException("错误");
		}
		Department parent = map.get(department.getParentid());
		long id = parent.getId() * 10 + parent.getChilds().size() + 1;
		department.setId(id);
		department.setParent(parent);
		parent.addChild(department);
		map.put(id, department);
		return id;
	}

	public void deleteById(long id) throws ManagerException
	{
		map.remove(id);
	}

	public Department findById(long id)
	{
		return map.get(id);
	}

	public Pagination pagnQuery(DeptQueryModel queryModel)
	{
		Pagination pagn = new Pagination();
		if (queryModel.getDeptParentId() != null)
		{
			List<Department> list = map.get(queryModel.getDeptParentId()).getChilds();
			if (list.size() == 0) return pagn;
			pagn.setCurrentPage(1);
			pagn.setPageCount(1);
			pagn.setPageSize(list.size());
			pagn.setResult(list);
			pagn.setTotalCount(list.size());
			return pagn;
		}
		Collection<Department> c = map.values();
		List<Department> list = new ArrayList<Department>();
		list.addAll(c);
		pagn.setCurrentPage(1);
		pagn.setPageCount((list.size() / 16) + 1);
		pagn.setPageSize(16);
		pagn.setTotalCount(list.size());
		pagn.setResult(list);
		return pagn;
	}

	private static Map<Long, Department> map = new HashMap<Long, Department>();

	private static void createDept(int level, Department parent, int totalDeep)
	{
		if (level >= totalDeep) return;
		Random r = new Random();
		int next = r.nextInt(6);
		if (next == 0) return;
		for (int i = 1; i <= next; i++)
		{
			Department d1 = new Department();
			d1.setId(parent.getId() * 10 + i);
			d1.setName("部门" + d1.getId());
			d1.setParent(parent);
			map.put(d1.getId(), d1);
			parent.addChild(d1);
			parent.setHasChild(true);
			createDept(level + 1, d1, totalDeep);
		}
	}

	static
	{
		Department d = new Department();
		d.setName("顶级部门");
		d.setId(1);
		d.setHasChild(true);
		map.put(d.getId(), d);
		createDept(2, d, 6);
	}

}
