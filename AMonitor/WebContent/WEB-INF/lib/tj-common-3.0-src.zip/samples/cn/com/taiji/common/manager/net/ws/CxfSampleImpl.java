package samples.cn.com.taiji.common.manager.net.ws;

import java.util.Calendar;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.springframework.stereotype.Service;

import samples.cn.com.taiji.common.model.net.ws.SampleMsg;
import samples.cn.com.taiji.common.model.net.ws.SampleRequest;
import samples.cn.com.taiji.common.model.net.ws.SampleResponse;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-13 上午10:53:36
 * @since 1.0
 * @version 1.0
 */
@WebService(targetNamespace = "http://taiji.com.cn/", serviceName = "CxfSample", portName = "CxfSamplePort")
@Service("cxfSampleImpl")
public class CxfSampleImpl implements CxfSample
{
	@WebMethod
	public String sayHi(String text)
	{
		System.out.println("sayHi called");
		return "hello" + text;
	}

	@WebMethod(exclude = true)
	public SampleResponse echo(SampleRequest request)
	{
		return SampleResponse.getInstance(request);
	}

	@WebMethod
	public SampleMsg handMsg(SampleMsg msg)
	{
		if (msg == null) return null;
		msg.setId(msg.getId() + 1);
		msg.setMsg("response:" + msg.getMsg());
		if (msg.getTime() != null)
		{
			Calendar time = msg.getTime();
			time.add(Calendar.MONTH, 1);
			msg.setTime(time);
		}
		System.out.println("after handle=" + msg);
		return msg;
	}

}
