package samples.cn.com.taiji.common.manager.quartz;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-5-15 下午01:17:14<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface QuartzManager
{
	public void runSampleJob();
	
	public void runClusterJob();
}
