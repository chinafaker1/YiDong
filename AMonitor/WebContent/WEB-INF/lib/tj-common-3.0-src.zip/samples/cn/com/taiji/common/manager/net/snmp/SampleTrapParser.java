package samples.cn.com.taiji.common.manager.net.snmp;

import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;
import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.net.snmp.AbstractTrapParser;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午10:41:15
 * @since 1.0
 * @version 1.0
 */
@Service("sampleTrapParser")
public class SampleTrapParser extends AbstractTrapParser
{
	public Object parse(VariableBinding binding)
	{
		Variable variable = binding.getVariable();
		if (variable instanceof OctetString)
		{
			try
			{
				String alertStr = decodeOctetString((OctetString) variable, UTF8);
				logger.info("Parse SampleTrap success!!");
				return alertStr;
			}
			catch (Exception e)
			{
				logger.error(e.getMessage(), e);
			}
		}
		else
		{
			logger.info("binding=" + binding);
			logger.error("Not a OcteString,can not parse:" + variable);
		}
		return null;
	}

}
