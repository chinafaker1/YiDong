package samples.cn.com.taiji.common.manager.editor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.engine.jdbc.NonContextualLobCreator;
import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.file.FileTools;

import samples.cn.com.taiji.common.model.editor.ArticleModel;
import samples.cn.com.taiji.common.model.editor.AttachModel;

@Service("articleManager")
public class ArticleManagerImpl extends AbstractManager implements ArticleManager
{
	public void txAdd(ArticleModel pageModel) throws ManagerException, FileNotFoundException
	{
		// 保存文章
		pageModel.setId("1");
		// 保存图片
		this.txAddMorePic(pageModel);
		// 保存附件
		this.txAddMoreAttach(pageModel, pageModel.getAttachmentList(), false);
	}

	public ArticleModel findById(String id) throws ManagerException
	{
		// ArticleModel pageModel=articleDao.findById(id);
		// 模拟找到此文章
		ArticleModel pageModel = new ArticleModel();

		// 根据文章编号找到所有的内部附件 在临时文件夹里形成文件 如果文件已经存在 不在生成
		try
		{
			// List<AttachModel> attachs = attachDao.listByInfo(id, true);
			// 模拟此文章得内部图片附件
			List<AttachModel> attachs = new ArrayList<AttachModel>();
			for (AttachModel attach : attachs)
			{
				File file = new File(FileHelper.getTmpPath() + "/" + attach.getUuidName());
				if (file.exists()) continue;
				FileTools.blob2File(attach.getFileContent(), attach.getFileName());
			}
		}
		catch (Exception e)
		{
			throw new ManagerException("生成附件失败 ：" + e.getMessage());
		}

		// 根据文章的编号找到属于此文章的所有外部附件
		// List<AttachModel> attachsFile = attachDao.listByInfo(id, false);
		// 模拟找到文章的外部附件开始
		List<AttachModel> attachs = new ArrayList<AttachModel>();
		String[] attachStr = pageModel.getAttachmentList();
		if (attachStr == null || attachStr.length < 1) return pageModel;

		for (String str : attachStr)
		{
			logger.debug("附件名称：{}", str);
			AttachModel attach = new AttachModel();
			attach.setFileName(str);
			attachs.add(attach);
		}
		// 模拟找到文章的外部附件结束

		pageModel.setAttachs(attachs);
		return pageModel;
	}

	public void txUpdate(ArticleModel pageModel) throws ManagerException, FileNotFoundException
	{
		// 更新文章内容

		// 删除废弃的附件
		String[] attachmentStr = pageModel.getAttachmentListNow();
		if (attachmentStr != null && attachmentStr.length > 0)
		{
			for (String attachment : attachmentStr)
			{
				String[] attach = attachment.split("@@@");
				logger.debug("此部分删除已有附件，附件id：{}", attach[2]);
			}
		}
		// 保存图片
		this.txAddMorePic(pageModel);
		// 保存附件
		this.txAddMoreAttach(pageModel, pageModel.getAttachmentList(), false);
	}

	// 批量保存文章内的图片 checkFlag true 检测重名 表示是内部图片 InnerAttach设为true
	private void txAddMorePic(ArticleModel pageModel) throws ManagerException, FileNotFoundException
	{
		pageModel.setPicRootUrl("/tmp/");
		List<String> nameList = ArticleModel.getPicNameList(pageModel);// 包含的图片文件
		int l = nameList.size();
		if (l > 0)
		{
			String attachmentList[] = new String[l];
			for (int i = 0; i < l; i++)
			{
				attachmentList[i] = nameList.get(i);
			}
			this.txAddMoreAttach(pageModel, attachmentList, true);
		}

	}

	// 批量保存附件 checkFlag true 检测重名 表示是内部图片 InnerAttach设为true
	private void txAddMoreAttach(ArticleModel info, String attachmentList[], boolean checkFlag)
			throws ManagerException, FileNotFoundException
	{
		if (attachmentList == null || attachmentList.length < 1) return;

		String filePath = FileHelper.getTmpPath() + "/";
		String fileName = "";
		String trueName = "";
		if (info == null) throw new ManagerException("附件所属文章不存在");
		StringBuilder str = new StringBuilder();
		try
		{
			for (String attachment : attachmentList)
			{

				String attachmentName[] = attachment.split("@@@");
				fileName = attachmentName[0];
				trueName = filePath + attachmentName[2];
				if (checkFlag)
				{ // 需要检测是否已经存在图片
					logger.debug("根据文件名检测图片是否是已有图片，已有图片不再新入库：{}", fileName);
					// AttachModel tmp = attachDao.findByName(fileName);
					// if (tmp != null) continue;
				}
				InputStream in = new FileInputStream(new File(trueName));
				Blob blob = NonContextualLobCreator.INSTANCE.createBlob(in, in.available());
				if (blob == null || blob.length() < 1)
				{
					str.append(fileName).append(",");
					continue;
				}
				AttachModel po = new AttachModel();
				po.setFileContent(blob);
				po.setFileName(fileName);
				po.setArticle(info);
				po.setInnerAttach(checkFlag);
				// 新增附件
				logger.debug("新增附件---文件名:{}是内部文件：{}大小:{}", new Object[] { fileName, checkFlag, blob.length() });
				// attachDao.save(po);
			}
		}
		catch (Exception e)
		{
			logger.error("", e);
			throw new ManagerException("附件保存出错，附件名称：" + fileName);
		}
		if (StringTools.hasText(str))
			throw new FileNotFoundException("部分附件内容为空，未能保存。附件名称：" + (str + ",").split(",,")[0]);
	}

}
