package samples.cn.com.taiji.common.memcached;

import net.spy.memcached.ConnectionFactoryBuilder.Protocol;
import net.spy.memcached.DefaultHashAlgorithm;
import net.spy.memcached.FailureMode;
import net.spy.memcached.MemcachedClient;
import net.spy.memcached.spring.MemcachedClientFactoryBean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-3-16 下午01:42:16<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Configuration
public class MemcachedConfig extends AbstractManager
{
	@Value("#{jdbcProperties.cacheServers}")
	private String servers;
	@Value("#{jdbcProperties.useBinaryFactory}")
	private boolean useBinaryFactory;

	// 参数配置参考如下
	// 1.Servers
	// A string containing whitespace or comma separated host or IP addresses and port numbers of
	// the form "host:port host2:port" or "host:port, host2:port".
	// 2.Daemon
	// Set the daemon state of the IO thread (defaults to true).
	// 3.FailureMode
	// Set the failure mode {Cancel | Redistribute | Retry} (defaults to Redistribute).
	// 4.HashAlg
	// Set the hash algorithm (see net.spy.memcached.HashAlgorithm for the values).
	// 5. InitialObservers
	// Set the initial connection observers (will observe initial connection).
	// 6.LocatorType
	// Set the locator type {ARRAY_MOD | CONSISTENT} (defaults to ARRAY_MOD).
	// 7. MaxReconnectDelay
	// Set the maximum reconnect delay.
	// 8. OpFact
	// Set the operation factory.
	// 9. OpQueueFactory
	// Set the operation queue factory.
	// 10. OpTimeout
	// Set the default operation timeout in milliseconds.
	// 11. Protocol
	// Convenience method to specify the protocol to use {BINARY | TEXT} (defaults to TEXT).
	// 12. ReadBufferSize
	// Set the read buffer size.
	// 13. ReadOpQueueFactory
	// Set the read queue factory.
	// 14. ShouldOptimize
	// Set to false if the default operation optimization is not desirable (defaults to true).
	// 15. Transcoder
	// Set the default transcoder (defaults to net.spy.memcached.transcoders.SerializingTranscoder).
	// 16. UseNagleAlgorithm
	// Set to true if you'd like to enable the Nagle algorithm.
	// 17. WriteOpQueueFactory
	// Set the write queue factory.
	// 18. AuthDescriptor
	// Set the auth descriptor to enable authentication on new connections
	@Bean(name = "memcachedClient", destroyMethod = "shutdown")
	public MemcachedClient memcachedClientFactory() throws Exception
	{
		System.out.println("init memcached client.");
		MemcachedClientFactoryBean fac = new MemcachedClientFactoryBean();
		fac.setServers(servers);
		fac.setProtocol(useBinaryFactory ? Protocol.BINARY : Protocol.TEXT);
		fac.setFailureMode(FailureMode.Redistribute);
		fac.setOpTimeout(5000);
		fac.setHashAlg(DefaultHashAlgorithm.KETAMA_HASH);
		fac.afterPropertiesSet();
		MemcachedClient client = (MemcachedClient) fac.getObject();
		System.out.println("client:" + client);
		return client;
	}
}
