/*
 * Date: 2012-5-28
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.model;

import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-5-28 下午2:48:30<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class SampleUploadModel extends BaseModel
{
	private String fileName;
	private MultipartFile file;
	private ProductType type;

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public MultipartFile getFile()
	{
		return file;
	}

	public void setFile(MultipartFile file)
	{
		this.file = file;
	}

	public ProductType getType()
	{
		return type;
	}

	public void setType(ProductType type)
	{
		this.type = type;
	}

	public enum ProductType
	{
		RADAR, STAR;
	}
}
