package samples.cn.com.taiji.common.model.net.nio;

import cn.com.taiji.common.model.net.nio.NioProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 上午11:30:35<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractNioProtocol extends NioProtocol
{
	protected ProtocolType type;

	protected AbstractNioProtocol(ProtocolType type)
	{
		this.type = type;
	}

	public ProtocolType getType()
	{
		return type;
	}

	public void setType(ProtocolType type)
	{
		this.type = type;
	}
}
