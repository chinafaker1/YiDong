package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 下午01:53:45<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class ProtocolParser
{
	public static AuthProtocol parseAuth(String data)
	{
		String[] strs = data.split(ProtocolConstant.DATA_SPLIT);
		if (strs.length < 3) throw new IllegalArgumentException("data can not convert to Auth.");
		AuthProtocol rs = new AuthProtocol();
		rs.setMcode(strs[1]);
		rs.setPassword(strs[2]);
		return rs;
	}

	public static UserRequest parseUserRequest(String data)
	{
		String[] strs = data.split(ProtocolConstant.DATA_SPLIT);
		if (strs.length < 2)
			throw new IllegalArgumentException("data can not convert to UserRequest.");
		UserRequest rs = new UserRequest();
		rs.setLoginname(strs[1]);
		return rs;
	}

	public static UserResponse parseUserResponse(String data)
	{
		String[] strs = data.split(ProtocolConstant.DATA_SPLIT);
		if (strs.length < 6)
			throw new IllegalArgumentException("data can not convert to UserResponse.");
		UserResponse rs = new UserResponse();
		rs.setExist(Boolean.valueOf(strs[1]));
		rs.setLoginname(strs[2]);
		rs.setName(strs[3]);
		rs.setEmail(strs[4]);
		rs.setTel(strs[5]);
		return rs;
	}

	public static ProtocolType getType(String data)
	{
		if (data == null || data.length() == 0)
			throw new IllegalArgumentException("str must has text.");
		String[] strs = data.split(ProtocolConstant.DATA_SPLIT);
		ProtocolType type = ProtocolType.valueOf(ProtocolType.class, strs[0]);
		return type;
	}
}
