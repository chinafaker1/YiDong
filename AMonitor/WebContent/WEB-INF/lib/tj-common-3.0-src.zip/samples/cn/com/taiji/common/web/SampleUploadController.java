/*
 * Date: 2012-5-28
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.web;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import samples.cn.com.taiji.common.model.SampleUploadModel;
import samples.cn.com.taiji.common.model.UploadResponse;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.web.BaseController;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-5-28 下午2:46:55<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleUploadController extends BaseController
{
	@RequestMapping(value = "/upload/upload.do", method = RequestMethod.POST)
	public void upload(@ModelAttribute SampleUploadModel uploadModel, HttpServletResponse response) throws IOException
	{
		File file = new File(FileHelper.getTmpPath() + "/" + uploadModel.getType().name() + "_"
				+ uploadModel.getFileName());
		uploadModel.getFile().transferTo(file);
		response.getWriter().println(new UploadResponse(true, "上传成功.").toJson());
	}
}
