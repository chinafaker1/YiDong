/*
 * Date: 2012-6-14
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.model.json;

import cn.com.taiji.common.model.json.AbstractProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-6-14 下午1:33:09<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link ProtocolType}
 */
public final class CommonResponse extends AbstractProtocol
{
	private boolean success;
	private String reason;

	public CommonResponse()
	{
		super(ProtocolType.RES_COMMON.name());
	}

	public CommonResponse(boolean success, String reason)
	{
		super(ProtocolType.RES_COMMON.name());
		this.success = success;
		this.reason = reason;
	}

	public boolean isSuccess()
	{
		return success;
	}

	public void setSuccess(boolean success)
	{
		this.success = success;
	}

	public String getReason()
	{
		return reason;
	}

	public void setReason(String reason)
	{
		this.reason = reason;
	}

	public static CommonResponse newInstance(String jsonStr)
	{
		return newInstance(CommonResponse.class, jsonStr);
	}
}
