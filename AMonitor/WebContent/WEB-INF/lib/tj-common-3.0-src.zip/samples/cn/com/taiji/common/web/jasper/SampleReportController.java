package samples.cn.com.taiji.common.web.jasper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.com.taiji.common.model.SelectModel;
import cn.com.taiji.common.web.BaseController;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-6-20 下午04:06:24
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleReportController extends BaseController
{
	@RequestMapping({ "/sampleReport.pdf", "/sampleReport.xls", "/sampleReport.csv",
			"/sampleReport.rtf", "/sampleReport.doc" })
	public ModelAndView handleMulti(HttpServletRequest request)
	{
		String uri = request.getRequestURI();
		String format = uri.substring(uri.lastIndexOf(".") + 1);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("format", format.toLowerCase());
		// 组织数据用于生成pdf、excel视图,也可以直接用datasource
		List<SelectModel> list = new ArrayList<SelectModel>();
		for (int i = 0; i < 10; i++)
		{
			list.add(new SelectModel("name中" + i, "value文" + i));
		}
		model.put("rptData", list);
		// model.put("rptData", dataSource);
		return new ModelAndView("sampleReport", model);
	}
}
