package samples.cn.com.taiji.common.manager.net.nio;

import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.channels.ClosedChannelException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;
import org.xsocket.MaxReadSizeExceededException;
import org.xsocket.connection.INonBlockingConnection;

import cn.com.taiji.common.manager.AbstractThreadManager;
import cn.com.taiji.common.manager.net.nio.NioServerHandler;

import samples.cn.com.taiji.common.model.net.nio.AuthProtocol;
import samples.cn.com.taiji.common.model.net.nio.ProtocolConstant;
import samples.cn.com.taiji.common.model.net.nio.ProtocolParser;
import samples.cn.com.taiji.common.model.net.nio.ProtocolType;
import samples.cn.com.taiji.common.model.net.nio.UserRequest;
import samples.cn.com.taiji.common.model.net.nio.UserResponse;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-19 下午02:14:07
 * @since 1.0
 * @version 1.0
 */
@Service("sampleNioServerHandler")
public class SampleNioServerHandler extends AbstractThreadManager<InterruptedException> implements
		NioServerHandler
{
	private Map<INonBlockingConnection, ClientInfo> connections = new ConcurrentHashMap<INonBlockingConnection, ClientInfo>();

	public SampleNioServerHandler()
	{
		super("nio connection check");
	}

	@Override
	protected void afterStopThread()
	{
		for (Map.Entry<INonBlockingConnection, ClientInfo> entry : connections.entrySet())
		{
			try
			{
				entry.getKey().close();
			}
			catch (IOException e)
			{
				logger.error("", e);
			}
		}
		logger.info("停止检测后：删除数据库中的所有连接.");
	}

	@Override
	protected void beforeStartThread()
	{
		logger.info("开始检测前：删除数据库中的所有连接.");
	}

	@Override
	protected void runTask() throws InterruptedException
	{
		Thread.sleep(30000);
		for (Map.Entry<INonBlockingConnection, ClientInfo> entry : connections.entrySet())
		{
			INonBlockingConnection connection = entry.getKey();
			ClientInfo info = entry.getValue();
			try
			{
				// 关闭未通过验证的连接
				if (!info.isAuthed())
				{
					connection.close();
					continue;
				}
				logger.info("更新数据库中的连接:{}\tclientId:{}", connection.isOpen(), info.getClientId());
			}
			catch (IOException e)
			{
				logger.error("", e);
			}
		}
	}

	public boolean onData(INonBlockingConnection connection) throws IOException,
			BufferUnderflowException, ClosedChannelException, MaxReadSizeExceededException
	{
		String data = connection.readStringByDelimiter(ProtocolConstant.CMD_SPLIT);
		logger.debug("remote encoding:{}", connection.getEncoding());
		ProtocolType type = ProtocolParser.getType(data);
		switch (type)
		{
		case AUTH:
			handleAuth(connection, data);
			break;
		case STATUS:
			handleStatus(connection, data);
			break;
		case USER_REQUEST:
			handleUserRequest(connection, data);
			break;
		default:
			logger.error("未知协议:{}", data);
			break;
		}
		return true;
	}

	private void handleUserRequest(INonBlockingConnection connection, String data)
			throws IOException
	{
		UserRequest request = ProtocolParser.parseUserRequest(data);
		logger.debug("begin handle user request:{}", request.getLoginname());
		UserResponse response = new UserResponse();
		response.setLoginname(request.getLoginname());
		response.setEmail("peream@gmail.com");
		response.setExist(true);
		response.setName("陈培安");
		response.setTel("13691517931");
		// try
		// {
		// Thread.sleep(10000);
		// }
		// catch (InterruptedException e)
		// {
		// e.printStackTrace();
		// }
		connection.write(response.toProtocolString());
	}

	private void handleStatus(INonBlockingConnection connection, String data)
	{
		logger.info("收到客户端 {} 的连接检测数据.", connection.getRemoteAddress().getHostName());
	}

	private void handleAuth(INonBlockingConnection connection, String data) throws IOException
	{
		ClientInfo client = connections.get(connection);
		if (client == null)
		{
			logger.warn("connection is not in the pool,close it.");
			connection.close();
			return;
		}
		AuthProtocol protocol = ProtocolParser.parseAuth(data);
		logger.info("处理客户端的验证请求:{}", protocol);
		client.setAuthed(true);
		client.setAppCode(protocol.getMcode());
		logger.info("将客户端连接加入到数据库中...");
	}

	public boolean onConnect(INonBlockingConnection connection) throws IOException,
			BufferUnderflowException, MaxReadSizeExceededException
	{
		logger.debug("comming a connection from {}", connection.getRemoteAddress().getHostName());
		connections.put(connection, new ClientInfo());
		return true;
	}

	public boolean onDisconnect(INonBlockingConnection connection) throws IOException
	{
		logger.debug("connection size:{}\tcontains:{}", connections.size(),
				connections.containsKey(connection));
		ClientInfo client = connections.remove(connection);
		logger.info("Remove client from db:{}", client.toString());
		connection.close();
		return true;
	}
}
