package samples.cn.com.taiji.common.web.myenum;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.common.web.BaseController;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-9-24 下午11:23:27
 * @since 1.0
 * @version 1.0
 */
@Controller
public class MyEnumForm extends BaseController
{
	@RequestMapping(value = "/enum/enumForm.do", method = RequestMethod.GET)
	public String setupForm(Model model)
	{
		model.addAttribute("queryModel", new MyEnumModel());
		model.addAttribute("colors", MyColor.values());
		return "samples/enum/enumForm";
	}

	@RequestMapping(value = "/enum/enumForm.do", method = RequestMethod.POST)
	public String processSubmit(MyEnumModel form, Model model)
	{
		logger.info(form.toString());
		return "samples/enum/enumForm";
	}

	public enum MyColor
	{
		RED("红色"), GREEN("绿色"), YELLOW("黄色");
		
		private String value;

		private MyColor(String value)
		{
			this.value = value;
		}

		public String getValue()
		{
			return value;
		}
	}
}
