package samples.cn.com.taiji.common.manager.net.activemq;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-20 下午04:58:13
 * @since 1.0
 * @version 1.0
 */
public class SampleMQObj extends BaseModel implements Serializable
{
	private static final long serialVersionUID = -6891087169281283451L;

	private int id;
	private String msg;
	private Calendar time = Calendar.getInstance();
	private List<SampleMQObj> list = new ArrayList<SampleMQObj>();

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public Calendar getTime()
	{
		return time;
	}

	public void setTime(Calendar time)
	{
		this.time = time;
	}

	public List<SampleMQObj> getList()
	{
		return list;
	}

	public void setList(List<SampleMQObj> list)
	{
		this.list = list;
	}

}
