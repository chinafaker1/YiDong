package samples.cn.com.taiji.common.model.net.ws;

import java.util.ArrayList;
import java.util.HashMap;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 下午05:21:43
 * @since 1.0
 * @version 1.0
 */
public class SampleRequest extends BaseModel
{
	private String strMsg;
	private ArrayList<SampleMsg> listMsg;
	private HashMap<String, ArrayList<SampleMsg>> mapMsg;
	private int intMsg;

	public int getIntMsg()
	{
		return intMsg;
	}

	public void setIntMsg(int intMsg)
	{
		this.intMsg = intMsg;
	}

	public ArrayList<SampleMsg> getListMsg()
	{
		return listMsg;
	}

	public void setListMsg(ArrayList<SampleMsg> listMsg)
	{
		this.listMsg = listMsg;
	}

	public HashMap<String, ArrayList<SampleMsg>> getMapMsg()
	{
		return mapMsg;
	}

	public void setMapMsg(HashMap<String, ArrayList<SampleMsg>> mapMsg)
	{
		this.mapMsg = mapMsg;
	}

	public String getStrMsg()
	{
		return strMsg;
	}

	public void setStrMsg(String strMsg)
	{
		this.strMsg = strMsg;
	}

}
