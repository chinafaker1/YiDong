package samples.cn.com.taiji.common.web.jquery.tree;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.web.BaseController;


/**
 * jQuery树形目录的示例代码
 * @author TOM Email:tomesc@msn.com 
 *
 */
@Controller
public class SampleJqueryTreeController extends BaseController
{
	private DepartmentHelper manager = new DepartmentHelper();
	
	@RequestMapping(value = "/jquery/tree/manage.do", method = RequestMethod.GET)
	public String manage(@ModelAttribute("queryModel") DeptQueryModel queryModel, Model model)
	{
		model.addAttribute("depts", this.manager.getByParent(null));
		logger.debug(this.manager.getByParent(null).toString());
		return "samples/jquery/tree/manage";
	}

	@RequestMapping(value = "/jquery/tree/manage.do", method = RequestMethod.POST)
	public String doQueryResult(@ModelAttribute("queryModel") DeptQueryModel queryModel, Model model)
	{
		model.addAttribute("pagn", manager.pagnQuery(queryModel));
		return "samples/jquery/tree/queryResult";
	}

	@RequestMapping(value = "/jquery/tree/add.do", method = RequestMethod.GET)
	public String add(@RequestParam(value="id",required=false) Long id,
			Model model)
	{
		if(id != null){
			model.addAttribute("parentDept", this.manager.findById(id));
		}
		model.addAttribute("dept", new Department());
		return "samples/jquery/tree/add";
	}

	@RequestMapping(value = "/jquery/tree/add.do", method = RequestMethod.POST)
	public String doAdd(@ModelAttribute Department dept, Model model)
	{
		try
		{
			Long id = manager.add(dept);
			super.addSuccess(model, "添加部门成功");
			model.addAttribute("dept", this.manager.findById(id));
		} catch (ManagerException e)
		{
			super.addError(model, "添加部门失败" + e.getMessage());
		}
		return "samples/jquery/tree/result";
	}

	@RequestMapping(value = "/jquery/tree/modify.do", method = RequestMethod.GET)
	public String edit(@RequestParam("id") long id, HttpServletRequest request, Model model)
	{
		model.addAttribute("dept", manager.findById(id));
		return "samples/jquery/tree/modify";
	}

	@RequestMapping(value = "/jquery/tree/modify.do", method = RequestMethod.POST)
	public String doEdit(@ModelAttribute Department dept,  Model model)
	{
		try
		{
			manager.update(dept);
			model.addAttribute("dept", this.manager.findById(dept.getId()));
			super.addSuccess(model, "修改部门成功");
		} catch (ManagerException e)
		{
			super.addError(model, e.getMessage());
		}
		return "samples/jquery/tree/result";
	}


	@RequestMapping(value = "/jquery/tree/delete.do")
	public String del(@RequestParam("id") long id,  Model model)
	{
		try
		{
			manager.deleteById(id);
			super.addSuccess(model, "删除部门成功");
			model.addAttribute("id", id);
		} catch (ManagerException e)
		{
			super.addError(model, "【删除部门失败】" + e.getMessage());
		}
		return "samples/jquery/tree/result";
	}
	
	@RequestMapping(value="/jquery/tree/getByParent.do")
	public String getByParent(@RequestParam("id") Long id,Model model){
		model.addAttribute("depts", this.manager.getByParent(id));
		return "samples/jquery/tree/treeItem";
	}
}
