package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 下午06:45:20<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class UserResponse extends AbstractNioProtocol
{
	private boolean exist;
	private String loginname = "";
	private String name = "";
	private String email = "";
	private String tel = "";

	public UserResponse()
	{
		super(ProtocolType.USER_RESPONSE);
	}

	public boolean isExist()
	{
		return exist;
	}

	public void setExist(boolean exist)
	{
		this.exist = exist;
	}

	public String getLoginname()
	{
		return loginname;
	}

	public void setLoginname(String loginname)
	{
		this.loginname = loginname;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getTel()
	{
		return tel;
	}

	public void setTel(String tel)
	{
		this.tel = tel;
	}

	@Override
	public String toProtocolString()
	{
		return type.toString() + ProtocolConstant.DATA_SPLIT + Boolean.valueOf(exist).toString()
				+ ProtocolConstant.DATA_SPLIT + loginname + ProtocolConstant.DATA_SPLIT + name
				+ ProtocolConstant.DATA_SPLIT + email + ProtocolConstant.DATA_SPLIT + tel
				+ ProtocolConstant.CMD_SPLIT;
	}

	@Override
	public String toString()
	{
		return "UserResponse [exist=" + exist + ", loginname=" + loginname + ", name=" + name
				+ ", email=" + email + ", tel=" + tel + ", type=" + type + "]";
	}

}
