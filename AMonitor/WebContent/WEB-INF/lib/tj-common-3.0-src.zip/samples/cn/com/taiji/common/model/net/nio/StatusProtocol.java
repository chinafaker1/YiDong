package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 下午03:31:43<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class StatusProtocol extends AbstractNioProtocol
{
	public StatusProtocol()
	{
		super(ProtocolType.STATUS);
	}

	@Override
	public String toProtocolString()
	{
		return type.toString() + ProtocolConstant.CMD_SPLIT;
	}

}
