package samples.cn.com.taiji.common.model.editor;

import java.sql.Blob;

public class AttachModel
{
	private String id;
	private ArticleModel article;// 所属文章
	private String fileName;// 附件名字
	private String uuidName;// 附件的uuid名字，存放在tmp目录下
	private boolean innerAttach;// 是否是文本内容的附件
	private Blob fileContent;// 文件二进制内容

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public ArticleModel getArticle()
	{
		return article;
	}

	public void setArticle(ArticleModel article)
	{
		this.article = article;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getUuidName()
	{
		return uuidName;
	}

	public void setUuidName(String uuidName)
	{
		this.uuidName = uuidName;
	}

	public boolean isInnerAttach()
	{
		return innerAttach;
	}

	public void setInnerAttach(boolean innerAttach)
	{
		this.innerAttach = innerAttach;
	}

	public Blob getFileContent()
	{
		return fileContent;
	}

	public void setFileContent(Blob fileContent)
	{
		this.fileContent = fileContent;
	}

}
