/*
 * Date: 2013-2-5
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.manager.net.activemq;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-2-5 上午9:45:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Service("sampleTopicConsumer2")
public class SampleTopicConsumer2 extends AbstractManager
{
	private AtomicInteger count = new AtomicInteger(0);

	public void handleTopic(String msg)
	{
		int theCount = count.addAndGet(1);
		System.out.println("Topic2 receive msg: " + msg + "\tcount=" + theCount);
	}
}
