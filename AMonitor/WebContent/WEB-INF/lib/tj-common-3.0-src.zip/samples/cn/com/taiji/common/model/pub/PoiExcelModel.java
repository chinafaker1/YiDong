/*
 * Date: 2011-12-27
 * author: Peream  (peream@gmail.com)
 *
 */
package samples.cn.com.taiji.common.model.pub;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-27 下午3:28:25<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class PoiExcelModel extends BaseModel
{
	private String name;
	private String code;
	private double value;
	private Calendar time;

	public final String getName()
	{
		return name;
	}

	public final void setName(String name)
	{
		this.name = name;
	}

	public final String getCode()
	{
		return code;
	}

	public final void setCode(String code)
	{
		this.code = code;
	}

	public final double getValue()
	{
		return value;
	}

	public final void setValue(double value)
	{
		this.value = value;
	}

	public final Calendar getTime()
	{
		return time;
	}

	public final void setTime(Calendar time)
	{
		this.time = time;
	}

	public static PoiExcelModel newInstance(int i)
	{
		PoiExcelModel rs = new PoiExcelModel();
		rs.name = "陈培安" + i;
		rs.code = "35220219810112427" + i;
		rs.value = 1492.89 + i;
		rs.time = Calendar.getInstance();
		return rs;
	}

	public static List<PoiExcelModel> newInstances(int length)
	{
		List<PoiExcelModel> rs = new ArrayList<PoiExcelModel>();
		for (int i = 0; i < length; i++)
		{
			rs.add(newInstance(i));
		}
		return rs;
	}
}
