package samples.cn.com.taiji.common.manager.net.snmp;

import org.snmp4j.PDU;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import cn.com.taiji.common.manager.net.AbstractNetHandler;
import cn.com.taiji.common.manager.net.snmp.SnmpTrapServerHandler;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午10:49:21
 * @since 1.0
 * @version 1.0
 */
@Service("snmpTrapServerHandler")
public class SampleTrapServerHandler extends AbstractNetHandler implements SnmpTrapServerHandler
{
	@Async
	public void handle(final PDU trap)
	{
		System.out.println("trap type=" + trap.getClass().getName());
		System.out.println("requestId=" + trap.getRequestID());
		System.out.println("==============================\n");
		try
		{
			for (int i = 0; i < trap.size(); i++)
			{
				System.out.println("------------------------------:" + i);
				VariableBinding binding = trap.get(i);
				System.out.println("binding=" + binding);
				OID oid = binding.getOid();
				System.out.println("oid=" + oid);
				Variable varibale = binding.getVariable();
				System.out.println("varibale=" + varibale + "\tvariable type="
						+ varibale.getClass().getName());
				System.out.println("------------------------------\n");
			}
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
	}

}
