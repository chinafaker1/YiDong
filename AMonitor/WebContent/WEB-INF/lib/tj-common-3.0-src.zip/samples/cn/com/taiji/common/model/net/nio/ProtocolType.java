package samples.cn.com.taiji.common.model.net.nio;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-14 上午11:12:42<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public enum ProtocolType
{
	AUTH("验证客户端身份") {},
	STATUS("连接状态检测") {},
	USER_REQUEST("用户信息请求") {},
	USER_RESPONSE("用户信息返回") {};
	private String value;

	private ProtocolType(String value)
	{
		this.value = value;
	}

	public String getValue()
	{
		return value;
	}

}
