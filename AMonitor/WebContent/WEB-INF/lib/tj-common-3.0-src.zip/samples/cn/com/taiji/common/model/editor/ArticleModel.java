package samples.cn.com.taiji.common.model.editor;

import java.util.ArrayList;
import java.util.List;

import cn.com.taiji.common.pub.StringTools;


public class ArticleModel
{
	private String id;// 文章的id
	private String content;// 文章内容
	private String picRootUrl;// 图片的url
	private String[] attachmentListNow;// 原有附件列表
	private String[] attachmentList;// 新增附件列表
	private List<AttachModel> attachs = new ArrayList<AttachModel>();

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

	public String getPicRootUrl()
	{
		return picRootUrl;
	}

	public void setPicRootUrl(String picRootUrl)
	{
		this.picRootUrl = picRootUrl;
	}

	public String[] getAttachmentListNow()
	{
		return attachmentListNow;
	}

	public void setAttachmentListNow(String[] attachmentListNow)
	{
		this.attachmentListNow = attachmentListNow;
	}

	public String[] getAttachmentList()
	{
		return attachmentList;
	}

	public void setAttachmentList(String[] attachmentList)
	{
		this.attachmentList = attachmentList;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public List<AttachModel> getAttachs()
	{
		return attachs;
	}

	public void setAttachs(List<AttachModel> attachs)
	{
		this.attachs = attachs;
	}

	// 分析插入图片代码 <IMG src="/mhweb/tmp/1234515667307.jpg" border=0> 如果是单引号会出错
	// 附件列表 @@@分隔 fileName@@@fileType@@@trueName
	public static List<String> getPicNameList(ArticleModel model)
	{
		List<String> nameList = new ArrayList<String>();
		if (model == null) return nameList;
		String content = model.getContent();
		String regex = model.getPicRootUrl();
		// System.out.println("content:"+content+"\nregex:"+regex);
		if (!(StringTools.hasText(content) && StringTools.hasText(regex))) return nameList;

		String contents[] = content.split(regex);
		if (contents == null || contents.length < 2) return nameList;

		// 图片个数
		int l = contents.length;

		String picTmp = "";
		for (int i = 1; i < l; i++)
		{
			String contentTmp = contents[i];
			String names[] = contentTmp.split("\"");
			picTmp = names[0] + "@@@pic@@@" + names[0];
			nameList.add(picTmp);
		}
		return nameList;
	}

}
