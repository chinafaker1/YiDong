package samples.cn.com.taiji.common.web.doc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.web.BaseDocTemplateController;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-7-15 下午05:35:49<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleDocTemplateController extends BaseDocTemplateController
{
	public SampleDocTemplateController()
	{
		super("classpath:samples/cn/com/taiji/common/web/doc/docTemplate.mht");
	}

	@RequestMapping({ "/download/docTemplate.do", "/download/docTemplate.service" })
	public void downloadDoc(HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		String fileName = "模板示例.doc";
		Map<String, String> texts = new HashMap<String, String>();
		texts.put("${username}", "陈培安-ccc");
		texts.put("${sex}", "性别");
		Map<String, InputStream> images = new HashMap<String, InputStream>();
		String path = FileHelper.getWebappPath() + "/images/test/1.jpg";
		images.put("${image1}", new FileInputStream(new File(path)));

		super.generateDoc(request, response, texts, fileName, images);
	}

}
