package samples.cn.com.taiji.common.web.form;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.com.taiji.common.manager.ManagerException;

import samples.cn.com.taiji.common.model.form.SampleFormModel;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-9-4 上午09:54:05
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleFormForm
{

	@RequestMapping(value = "/form/form.do", method = RequestMethod.GET)
	public String setupForm(HttpServletRequest request, Model model)
			throws ManagerException
	{
		SampleFormModel formModel=new SampleFormModel();
		model.addAttribute("formModel", formModel);
		return "samples/form/form";
	}
	@RequestMapping(value = "/form/form.do", method = RequestMethod.POST)
	public String processSubmit(HttpServletRequest request, Model model,SampleFormModel formModel)
			throws ManagerException
	{
		StringBuilder idsStr=new StringBuilder(formModel.getIdsStr());
		if (formModel.getIds() != null) {
			for (String id : formModel.getIds())
				idsStr.append(id);
		}
		formModel.setIdsStr(idsStr.toString());
		model.addAttribute("formModel", formModel);
		return "samples/form/form";
	}
}
