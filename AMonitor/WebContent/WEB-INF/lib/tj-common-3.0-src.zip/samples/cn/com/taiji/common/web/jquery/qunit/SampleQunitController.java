package samples.cn.com.taiji.common.web.jquery.qunit;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.web.BaseController;

import samples.cn.com.taiji.common.entity.SampleEntity;
import samples.cn.com.taiji.common.web.SampleQueryModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-10-16 下午04:24:59<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@Controller
public class SampleQunitController extends BaseController
{
	@RequestMapping(value="/qunit/qunitTest.do",method=RequestMethod.GET)
	public String doQuery(@ModelAttribute("queryModel") SampleQueryModel qm, Model model)
	{
		Pagination pg = getPg(qm.getPageNo(), 290,qm.getPageSize());
		model.addAttribute("pagn", pg);
		logger.debug(qm.toString());
		return "samples/qunit/qunitTest";
	}
	
//	@RequestMapping("/sample/qunit/myPage.do")
//	public String myQuery(@ModelAttribute("queryModel") SampleQueryModel qm, Model model)
//	{
//		return "samples/page/myPage";
//	}
		
	@RequestMapping(value="/qunit/qunitTest.do",method=RequestMethod.POST)
	public String doQueryResult(@ModelAttribute("queryModel") SampleQueryModel qm, Model model)
	{
		Pagination pg = getPg(qm.getPageNo(), 290, qm.getPageSize());
		model.addAttribute("pagn", pg);
		return "samples/qunit/queryResult";
	}
	
	@RequestMapping(value="/qunit/add.do",method=RequestMethod.GET)
	public String add(){
		return "samples/qunit/add";
	}
	
	@RequestMapping(value="/qunit/add.do",method=RequestMethod.POST)
	public String doAdd(@ModelAttribute SampleEntity sampleEntity,Model model,
			HttpServletResponse response){
		if (sampleEntity.getIntValue() < 5)
		{
			addError(model, "添加的intValue小于5的数据，就会报错。。。");
			return "samples/qunit/result";
		}
		addSuccess(model, "添加成功");
		model.addAttribute("entity", sampleEntity);
		return "samples/qunit/result";
	}
	
	@RequestMapping(value="/qunit/edit.do",method=RequestMethod.GET)
	public String edit(@RequestParam("id") int id,Model model){
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("sampleEntity", entity);

		return "samples/qunit/edit";
	}
	
	@RequestMapping(value="/qunit/edit.do",method=RequestMethod.POST)
	public String doEdit(@ModelAttribute SampleEntity sampleEntity,Model model,
			HttpServletResponse response){
		if (sampleEntity.getIntValue() < 5)
		{
			addError(model, "修改的intValue小于5的数据，就会报错。。。");
			return "samples/qunit/result";
		}
		addSuccess(model, "修改成功");
		model.addAttribute("entity", sampleEntity);
		return "samples/qunit/result";
	}
	
	@RequestMapping(value="/qunit/view.do")
	public String view(@RequestParam("id") int id,Model model){
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("entity", entity);
		return "samples/qunit/view";
	}
	
	@RequestMapping(value="/qunit/del.do")
	public String del(@RequestParam("id") int id,Model model,HttpServletResponse response){
		if (id < 5)
		{
			addError(model, "del的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "del成功");
		return "samples/qunit/result";
	}
	
	@RequestMapping(value = "/qunit/update.do")
	public String update(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "操作(update)的intValue小于5的数据，就会报错。。。");
			return "noteInfo";
		}
		addSuccess(model, "操作(update)成功");
		return "noteInfo";
	}
	
	@RequestMapping(value = "/qunit/operate.do")
	public String operate(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "操作(operate)的intValue小于5的数据，就会报错。。。");
			return "noteInfo";
		}
		addSuccess(model, "操作(operate)成功");
		return "noteInfo";
	}

	@RequestMapping(value = "/qunit/popupRemove.do", method = RequestMethod.GET)
	public String setupPopupRemove(@RequestParam("id") int id, Model model)
	{
		SampleEntity entity = new SampleEntity();
		entity.setBoolValue(true);
		Calendar now = Calendar.getInstance();
		entity.setCalValue(now);
		entity.setIntValue(id);
		entity.setFloatValue(Double.valueOf(9999 * 0.616).floatValue());
		entity.setStrValue("文本信息 " + 9999);
		model.addAttribute("sampleEntity", entity);
		return "samples/qunit/popupRemove";
	}

	@RequestMapping(value = "/qunit/popupRemove.do", method = RequestMethod.POST)
	public String processPopupRemove(@RequestParam("id") int id, Model model)
	{
		if (id < 5)
		{
			addError(model, "popupRemove的intValue小于5的数据，就会报错。。。");
			return "samples/jquery14/result";
		}
		addSuccess(model, "popupRemove成功");
		return "samples/qunit/result";
	}

	private Pagination getPg(int currentPage, long total, int pageSize)
	{
		Pagination pg = new Pagination();
		pg.setCurrentPage(currentPage);
		pg.setTotalCount(total);
		pg.setPageSize(pageSize);
		pg.setPageCount(Pagination.getPageCount(pg.getTotalCount(), pg.getPageSize()));
		List<SampleEntity> rs = new ArrayList<SampleEntity>();
		int first = (pg.getCurrentPage() - 1) * pg.getPageSize() + 1;
		int last = pg.getCurrentPage() * pg.getPageSize();
		for (int i = first; i <= last; i++)
		{
			SampleEntity entity = new SampleEntity();
			entity.setBoolValue((i % 2 == 0));
			Calendar now = Calendar.getInstance();
			now.add(Calendar.HOUR_OF_DAY, i);
			entity.setCalValue(now);
			entity.setIntValue(i);
			entity.setFloatValue(Double.valueOf(i * 0.616).floatValue());
			entity.setStrValue("文本信息 " + i);
			rs.add(entity);
			if (i >= total) break;
		}
		pg.setResult(rs);
		return pg;
	}
}
