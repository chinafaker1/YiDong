@javax.xml.bind.annotation.XmlSchema(namespace = "http://WebXml.com.cn/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package samples.cn.com.taiji.common.model.net.ws.webxml;
