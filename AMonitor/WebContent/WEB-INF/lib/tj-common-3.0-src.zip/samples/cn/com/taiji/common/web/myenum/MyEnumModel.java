package samples.cn.com.taiji.common.web.myenum;

import cn.com.taiji.common.model.BaseModel;
import samples.cn.com.taiji.common.web.myenum.MyEnumForm.MyColor;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-9-24 下午11:27:25
 * @since 1.0
 * @version 1.0
 */
public class MyEnumModel extends BaseModel
{
	private MyColor color;

	public MyColor getColor()
	{
		return color;
	}

	public void setColor(MyColor color)
	{
		this.color = color;
	}

}
