package samples.cn.com.taiji.common.manager.net.nio;

import java.util.UUID;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-7 下午01:24:14<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class ClientInfo extends BaseModel
{
	private String clientId;// 客户端ID
	private String appCode;// 应用的代号
	private boolean authed;// 是否通过验证

	public ClientInfo()
	{
		getClientId();
	}

	public String getClientId()
	{
		if (!StringTools.hasText(clientId))
			clientId = UUID.randomUUID().toString().replace("-", "");
		return clientId;
	}

	public void setClientId(String clientId)
	{
		this.clientId = clientId;
	}

	public String getAppCode()
	{
		return appCode;
	}

	public void setAppCode(String appCode)
	{
		this.appCode = appCode;
	}

	public boolean isAuthed()
	{
		return authed;
	}

	public void setAuthed(boolean authed)
	{
		this.authed = authed;
	}

}
