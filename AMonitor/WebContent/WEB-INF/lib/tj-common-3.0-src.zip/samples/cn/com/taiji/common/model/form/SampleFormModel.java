package samples.cn.com.taiji.common.model.form;

import cn.com.taiji.common.model.BaseModel;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-9-9 上午09:42:55
 * @since 1.0
 * @version 1.0
 */
public class SampleFormModel extends BaseModel
{
	String ids[]; // 表单域
	String idsStr; // 表单域

	public String[] getIds()
	{
		return ids;
	}

	public void setIds(String[] ids)
	{
		this.ids = ids;
	}

	public String getIdsStr()
	{
		return idsStr;
	}

	public void setIdsStr(String idsStr)
	{
		this.idsStr = idsStr;
	}

}
