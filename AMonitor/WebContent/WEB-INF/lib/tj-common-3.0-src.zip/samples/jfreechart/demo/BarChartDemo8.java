package samples.jfreechart.demo;

import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BarChartDemo8 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8305634487674555991L;

	public BarChartDemo8(String paramString)
	{
		super(paramString);
		CategoryDataset localCategoryDataset = createDataset();
		JFreeChart localJFreeChart = createChart(localCategoryDataset);
		ChartPanel localChartPanel = new ChartPanel(localJFreeChart);
		localChartPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localChartPanel);
	}

	private static CategoryDataset createDataset()
	{
		String str1 = "First";
		String str2 = "Second";
		String str3 = "Third";
		String str4 = "Category 1";
		String str5 = "Category 2";
		String str6 = "Category 3";
		String str7 = "Category 4";
		String str8 = "Category 5";
		DefaultCategoryDataset localDefaultCategoryDataset = new DefaultCategoryDataset();
		localDefaultCategoryDataset.addValue(1D, str1, str4);
		localDefaultCategoryDataset.addValue(4.0D, str1, str5);
		localDefaultCategoryDataset.addValue(3.0D, str1, str6);
		localDefaultCategoryDataset.addValue(5.0D, str1, str7);
		localDefaultCategoryDataset.addValue(5.0D, str1, str8);
		localDefaultCategoryDataset.addValue(5.0D, str2, str4);
		localDefaultCategoryDataset.addValue(7.0D, str2, str5);
		localDefaultCategoryDataset.addValue(6.0D, str2, str6);
		localDefaultCategoryDataset.addValue(8.0D, str2, str7);
		localDefaultCategoryDataset.addValue(4.0D, str2, str8);
		localDefaultCategoryDataset.addValue(4.0D, str3, str4);
		localDefaultCategoryDataset.addValue(3.0D, str3, str5);
		localDefaultCategoryDataset.addValue(2.0D, str3, str6);
		localDefaultCategoryDataset.addValue(3.0D, str3, str7);
		localDefaultCategoryDataset.addValue(6.0D, str3, str8);
		return localDefaultCategoryDataset;
	}

	private static JFreeChart createChart(CategoryDataset paramCategoryDataset)
	{
		JFreeChart localJFreeChart = ChartFactory.createBarChart("Bar Chart Demo 8", "Category",
				"Value", paramCategoryDataset, PlotOrientation.VERTICAL, false, true, false);
		CategoryPlot localCategoryPlot = (CategoryPlot) localJFreeChart.getPlot();
		NumberAxis localNumberAxis = (NumberAxis) localCategoryPlot.getRangeAxis();
		localNumberAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		localNumberAxis.setUpperMargin(0.14999999999999999D);
		CategoryItemRenderer localCategoryItemRenderer = localCategoryPlot.getRenderer();
		localCategoryItemRenderer
				.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		localCategoryItemRenderer.setSeriesItemLabelsVisible(0, Boolean.TRUE);
		CategoryAxis localCategoryAxis = localCategoryPlot.getDomainAxis();
		localCategoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
		return localJFreeChart;
	}

	public static JPanel createDemoPanel()
	{
		JFreeChart localJFreeChart = createChart(createDataset());
		return new ChartPanel(localJFreeChart);
	}

	public static void main(String[] paramArrayOfString)
	{
		BarChartDemo8 localBarChartDemo8 = new BarChartDemo8("JFreeChart: BarChartDemo8.java");
		localBarChartDemo8.pack();
		RefineryUtilities.centerFrameOnScreen(localBarChartDemo8);
		localBarChartDemo8.setVisible(true);
	}
}