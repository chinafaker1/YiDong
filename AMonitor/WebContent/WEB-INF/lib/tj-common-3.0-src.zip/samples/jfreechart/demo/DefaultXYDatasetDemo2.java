package samples.jfreechart.demo;

import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class DefaultXYDatasetDemo2 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -869465807537042375L;

	public DefaultXYDatasetDemo2(String paramString)
	{
		super(paramString);
		JPanel localJPanel = createDemoPanel();
		localJPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localJPanel);
	}

	private static JFreeChart createChart(XYDataset paramXYDataset)
	{
		return ChartFactory.createScatterPlot("DefaultXYDatasetDemo2", "X", "Y", paramXYDataset,
				PlotOrientation.VERTICAL, true, false, false);
	}

	private static XYDataset createDataset()
	{
		DefaultXYDataset localDefaultXYDataset = new DefaultXYDataset();
		double[] arrayOfDouble1 = new double[1000];
		double[] arrayOfDouble2 = new double[1000];
		for (int i = 0; i < 1000; ++i)
		{
			arrayOfDouble1[i] = (Math.random() + 1D);
			arrayOfDouble2[i] = (Math.random() + 1D);
		}
		double[][] arrayOfD = { arrayOfDouble1, arrayOfDouble2 };
		localDefaultXYDataset.addSeries("Series 1", arrayOfD);
		return localDefaultXYDataset;
	}

	public static JPanel createDemoPanel()
	{
		return new ChartPanel(createChart(createDataset()));
	}

	public static void main(String[] paramArrayOfString)
	{
		DefaultXYDatasetDemo2 localDefaultXYDatasetDemo2 = new DefaultXYDatasetDemo2(
				"JFreeChart: DefaultXYDatasetDemo2.java");
		localDefaultXYDatasetDemo2.pack();
		RefineryUtilities.centerFrameOnScreen(localDefaultXYDatasetDemo2);
		localDefaultXYDatasetDemo2.setVisible(true);
	}
}