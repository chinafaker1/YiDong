package samples.jfreechart.demo;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.dial.ArcDialFrame;
import org.jfree.chart.plot.dial.DialBackground;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialPointer;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.ui.GradientPaintTransformType;
import org.jfree.ui.StandardGradientPaintTransformer;

public class DialDemo4 extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7891671090825565919L;

	public static JPanel createDemoPanel()
	{
		return new DemoPanel();
	}

	public DialDemo4(String paramString)
	{
		super(paramString);
		setDefaultCloseOperation(3);
		setContentPane(createDemoPanel());
	}

	public static void main(String[] paramArrayOfString)
	{
		DialDemo4 localDialDemo4 = new DialDemo4("JFreeChart: DialDemo4.java");
		localDialDemo4.pack();
		localDialDemo4.setVisible(true);
	}

	static class DemoPanel extends JPanel implements ChangeListener
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 3524945173452715257L;
		JSlider slider;
		DefaultValueDataset dataset = new DefaultValueDataset(50.0D);

		public DemoPanel()
		{
			super(new BorderLayout());
			DialPlot localDialPlot = new DialPlot();
			localDialPlot.setView(0.78000000000000003D, 0.37D, 0.22D, 0.26000000000000001D);
			localDialPlot.setDataset(this.dataset);
			ArcDialFrame localArcDialFrame = new ArcDialFrame(-10.0D, 20.0D);
			localArcDialFrame.setInnerRadius(0.69999999999999996D);
			localArcDialFrame.setOuterRadius(0.90000000000000002D);
			localArcDialFrame.setForegroundPaint(Color.darkGray);
			localArcDialFrame.setStroke(new BasicStroke(3.0F));
			localDialPlot.setDialFrame(localArcDialFrame);
			GradientPaint localGradientPaint = new GradientPaint(new Point(), new Color(255, 255,
					255), new Point(), new Color(240, 240, 240));
			DialBackground localDialBackground = new DialBackground(localGradientPaint);
			localDialBackground.setGradientPaintTransformer(new StandardGradientPaintTransformer(
					GradientPaintTransformType.VERTICAL));
			localDialPlot.addLayer(localDialBackground);
			StandardDialScale localStandardDialScale = new StandardDialScale(0D, 100.0D, -8.0D,
					16.0D, 10.0D, 4);
			localStandardDialScale.setTickRadius(0.81999999999999995D);
			localStandardDialScale.setTickLabelOffset(-0.040000000000000001D);
			localStandardDialScale.setMajorTickIncrement(25.0D);
			localStandardDialScale.setTickLabelFont(new Font("Dialog", 0, 14));
			localDialPlot.addScale(0, localStandardDialScale);
			DialPointer.Pin localPin = new DialPointer.Pin();
			localPin.setRadius(0.83999999999999997D);
			localDialPlot.addLayer(localPin);
			JFreeChart localJFreeChart = new JFreeChart(localDialPlot);
			localJFreeChart.setTitle("Dial Demo 4");
			ChartPanel localChartPanel = new ChartPanel(localJFreeChart);
			localChartPanel.setPreferredSize(new Dimension(400, 250));
			this.slider = new JSlider(0, 100);
			this.slider.setMajorTickSpacing(10);
			this.slider.setPaintLabels(true);
			this.slider.addChangeListener(this);
			add(localChartPanel);
			add(this.slider, "South");
		}

		public void stateChanged(ChangeEvent paramChangeEvent)
		{
			this.dataset.setValue(Integer.valueOf(this.slider.getValue()));
		}
	}
}