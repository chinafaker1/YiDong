package samples.jfreechart.demo;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class HideSeriesDemo3 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3477166707483916999L;

	public HideSeriesDemo3(String paramString)
	{
		super(paramString);
		setContentPane(new MyDemoPanel());
	}

	public static JPanel createDemoPanel()
	{
		return new MyDemoPanel();
	}

	public static void main(String[] paramArrayOfString)
	{
		HideSeriesDemo3 localHideSeriesDemo3 = new HideSeriesDemo3("JFreeChart: HideSeriesDemo3.java");
		localHideSeriesDemo3.pack();
		RefineryUtilities.centerFrameOnScreen(localHideSeriesDemo3);
		localHideSeriesDemo3.setVisible(true);
	}

	static class MyDemoPanel extends DemoPanel implements ActionListener
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = -4527328389328544572L;
		private XYItemRenderer renderer;

		public MyDemoPanel()
		{
			super(new BorderLayout());
			XYZDataset localXYZDataset = createSampleDataset();
			JFreeChart localJFreeChart = createChart(localXYZDataset);
			addChart(localJFreeChart);
			ChartPanel localChartPanel = new ChartPanel(localJFreeChart);
			JPanel localJPanel = new JPanel();
			JCheckBox localJCheckBox1 = new JCheckBox("Series 1");
			localJCheckBox1.setActionCommand("S1");
			localJCheckBox1.addActionListener(this);
			localJCheckBox1.setSelected(true);
			JCheckBox localJCheckBox2 = new JCheckBox("Series 2");
			localJCheckBox2.setActionCommand("S2");
			localJCheckBox2.addActionListener(this);
			localJCheckBox2.setSelected(true);
			JCheckBox localJCheckBox3 = new JCheckBox("Series 3");
			localJCheckBox3.setActionCommand("S3");
			localJCheckBox3.addActionListener(this);
			localJCheckBox3.setSelected(true);
			localJPanel.add(localJCheckBox1);
			localJPanel.add(localJCheckBox2);
			localJPanel.add(localJCheckBox3);
			add(localChartPanel);
			add(localJPanel, "South");
			localChartPanel.setPreferredSize(new Dimension(500, 270));
		}

		private XYZDataset createSampleDataset()
		{
			DefaultXYZDataset localDefaultXYZDataset = new DefaultXYZDataset();
			double[] arrayOfDouble1 = { 2.1000000000000001D, 2.2999999999999998D, 2.2999999999999998D };
			double[] arrayOfDouble2 = { 14.1D, 11.1D, 10.0D };
			double[] arrayOfDouble3 = { 2.3999999999999999D, 2.7000000000000002D, 2.7000000000000002D };
			double[][] arrayOfD = { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
			localDefaultXYZDataset.addSeries("Series 1", arrayOfD);
			arrayOfDouble1 = new double[] { 2.2000000000000002D, 2.2000000000000002D, 1.8D };
			arrayOfDouble2 = new double[] { 14.1D, 11.1D, 10.0D };
			arrayOfDouble3 = new double[] { 2.2000000000000002D, 2.2000000000000002D, 2.2000000000000002D };
			arrayOfD = new double[][] { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
			localDefaultXYZDataset.addSeries("Series 2", arrayOfD);
			arrayOfDouble1 = new double[] { 1.8D, 1.8999999999999999D, 2.2999999999999998D, 3.7999999999999998D };
			arrayOfDouble2 = new double[] { 5.4000000000000004D, 4.0999999999999996D, 4.0999999999999996D, 25.0D };
			arrayOfDouble3 = new double[] { 2.1000000000000001D, 2.2000000000000002D, 1.6000000000000001D, 4.0D };
			arrayOfD = new double[][] { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
			localDefaultXYZDataset.addSeries("Series 3", arrayOfD);
			return localDefaultXYZDataset;
		}

		private JFreeChart createChart(XYZDataset paramXYZDataset)
		{
			JFreeChart localJFreeChart = ChartFactory.createBubbleChart("Hide Series Demo 3", "X", "Y",
					paramXYZDataset, PlotOrientation.VERTICAL, true, true, false);
			XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
			this.renderer = localXYPlot.getRenderer(0);
			return localJFreeChart;
		}

		public void actionPerformed(ActionEvent paramActionEvent)
		{
			int i = -1;
			if (paramActionEvent.getActionCommand().equals("S1")) i = 0;
			else if (paramActionEvent.getActionCommand().equals("S2")) i = 1;
			else if (paramActionEvent.getActionCommand().equals("S3")) i = 2;
			if (i >= 0)
			{
				this.renderer.getItemVisible(i, 0);
				this.renderer.setSeriesVisible(i, Boolean.FALSE);
			}
		}
	}
}