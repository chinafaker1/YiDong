package samples.jfreechart.demo;

import java.awt.Dimension;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.function.Function2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class Function2DDemo1 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5612616751112827218L;

	public Function2DDemo1(String paramString)
	{
		super(paramString);
		JPanel localJPanel = createDemoPanel();
		localJPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localJPanel);
	}

	private static JFreeChart createChart(XYDataset paramXYDataset)
	{
		JFreeChart localJFreeChart = ChartFactory.createXYLineChart("Function2DDemo1 ", "X", "Y",
				paramXYDataset, PlotOrientation.VERTICAL, true, true, false);
		XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
		localXYPlot.getDomainAxis().setLowerMargin(0D);
		localXYPlot.getDomainAxis().setUpperMargin(0D);
		return localJFreeChart;
	}

	public static XYDataset createDataset()
	{
		XYDataset localXYDataset = DatasetUtilities.sampleFunction2D(new X2(), -4.0D, 4.0D, 40,
				"f(x)");
		return localXYDataset;
	}

	public static JPanel createDemoPanel()
	{
		JFreeChart localJFreeChart = createChart(createDataset());
		return new ChartPanel(localJFreeChart);
	}

	public static void main(String[] paramArrayOfString)
	{
		Function2DDemo1 localFunction2DDemo1 = new Function2DDemo1(
				"JFreeChart: Function2DDemo1.java");
		localFunction2DDemo1.pack();
		RefineryUtilities.centerFrameOnScreen(localFunction2DDemo1);
		localFunction2DDemo1.setVisible(true);
	}

	static class X2 implements Function2D
	{
		public double getValue(double paramDouble)
		{
			return (paramDouble * paramDouble + 2.0D);
		}
	}
}