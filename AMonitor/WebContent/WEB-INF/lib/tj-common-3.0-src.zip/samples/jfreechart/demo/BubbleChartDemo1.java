package samples.jfreechart.demo;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.DefaultXYZDataset;
import org.jfree.data.xy.XYZDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class BubbleChartDemo1 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4815817071620448516L;

	public BubbleChartDemo1(String paramString)
	{
		super(paramString);
		JPanel localJPanel = createDemoPanel();
		localJPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localJPanel);
	}

	private static JFreeChart createChart(XYZDataset paramXYZDataset)
	{
		JFreeChart localJFreeChart = ChartFactory.createBubbleChart("Bubble Chart Demo 1", "X",
				"Y", paramXYZDataset, PlotOrientation.HORIZONTAL, true, true, false);
		XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
		localXYPlot.setForegroundAlpha(0.64999997615814209F);
		XYItemRenderer localXYItemRenderer = localXYPlot.getRenderer();
		localXYItemRenderer.setSeriesPaint(0, Color.blue);
		NumberAxis localNumberAxis1 = (NumberAxis) localXYPlot.getDomainAxis();
		localNumberAxis1.setLowerMargin(0.14999999999999999D);
		localNumberAxis1.setUpperMargin(0.14999999999999999D);
		NumberAxis localNumberAxis2 = (NumberAxis) localXYPlot.getRangeAxis();
		localNumberAxis2.setLowerMargin(0.14999999999999999D);
		localNumberAxis2.setUpperMargin(0.14999999999999999D);
		return localJFreeChart;
	}

	public static XYZDataset createDataset()
	{
		DefaultXYZDataset localDefaultXYZDataset = new DefaultXYZDataset();
		double[] arrayOfDouble1 = { 2.1000000000000001D, 2.2999999999999998D, 2.2999999999999998D,
				2.2000000000000002D, 2.2000000000000002D, 1.8D, 1.8D, 1.8999999999999999D,
				2.2999999999999998D, 3.7999999999999998D };
		double[] arrayOfDouble2 = { 14.1D, 11.1D, 10.0D, 8.8000000000000007D, 8.6999999999999993D,
				8.4000000000000004D, 5.4000000000000004D, 4.0999999999999996D, 4.0999999999999996D,
				25.0D };
		double[] arrayOfDouble3 = { 2.3999999999999999D, 2.7000000000000002D, 2.7000000000000002D,
				2.2000000000000002D, 2.2000000000000002D, 2.2000000000000002D, 2.1000000000000001D,
				2.2000000000000002D, 1.6000000000000001D, 4.0D };
		double[][] arrayOfD = { arrayOfDouble1, arrayOfDouble2, arrayOfDouble3 };
		localDefaultXYZDataset.addSeries("Series 1", arrayOfD);
		return localDefaultXYZDataset;
	}

	public static JPanel createDemoPanel()
	{
		JFreeChart localJFreeChart = createChart(createDataset());
		ChartPanel localChartPanel = new ChartPanel(localJFreeChart);
		localChartPanel.setDomainZoomable(true);
		localChartPanel.setRangeZoomable(true);
		return localChartPanel;
	}

	public static void main(String[] paramArrayOfString)
	{
		BubbleChartDemo1 localBubbleChartDemo1 = new BubbleChartDemo1(
				"JFreeChart: BubbleChartDemo1.java");
		localBubbleChartDemo1.pack();
		RefineryUtilities.centerFrameOnScreen(localBubbleChartDemo1);
		localBubbleChartDemo1.setVisible(true);
	}
}