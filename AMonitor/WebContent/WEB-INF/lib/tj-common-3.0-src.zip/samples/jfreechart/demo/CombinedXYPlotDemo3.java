package samples.jfreechart.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;

import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CombinedRangeXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.time.Day;
import org.jfree.data.time.MovingAverage;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class CombinedXYPlotDemo3 extends ApplicationFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4492629847658156730L;

	public CombinedXYPlotDemo3(String paramString)
	{
		super(paramString);
		JFreeChart localJFreeChart = createCombinedChart();
		ChartPanel localChartPanel = new ChartPanel(localJFreeChart, true, true, true, false, true);
		localChartPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localChartPanel);
	}

	private static JFreeChart createCombinedChart()
	{
		TimeSeriesCollection localTimeSeriesCollection1 = new TimeSeriesCollection();
		TimeSeries localTimeSeries1 = createEURTimeSeries();
		localTimeSeriesCollection1.addSeries(localTimeSeries1);
		TimeSeriesCollection localTimeSeriesCollection2 = new TimeSeriesCollection();
		TimeSeries localTimeSeries2 = MovingAverage.createMovingAverage(localTimeSeries1,
				"EUR/GBP (30 Day MA)", 30, 30);
		localTimeSeriesCollection2.addSeries(localTimeSeries1);
		localTimeSeriesCollection2.addSeries(localTimeSeries2);
		TimeSeriesCollection localTimeSeriesCollection3 = new TimeSeriesCollection();
		localTimeSeriesCollection3.addSeries(localTimeSeries1);
		JFreeChart localJFreeChart = null;
		NumberAxis localNumberAxis = new NumberAxis("Value");
		localNumberAxis.setAutoRangeIncludesZero(false);
		CombinedRangeXYPlot localCombinedRangeXYPlot = new CombinedRangeXYPlot(localNumberAxis);
		XYPlot localXYPlot1 = new XYPlot(localTimeSeriesCollection1, new DateAxis("Date 1"), null,
				new StandardXYItemRenderer());
		localCombinedRangeXYPlot.add(localXYPlot1, 1);
		XYPlot localXYPlot2 = new XYPlot(localTimeSeriesCollection2, new DateAxis("Date 2"), null,
				new StandardXYItemRenderer());
		localCombinedRangeXYPlot.add(localXYPlot2, 1);
		XYPlot localXYPlot3 = new XYPlot(localTimeSeriesCollection3, new DateAxis("Date 3"), null,
				new XYBarRenderer(0.20000000000000001D));
		localCombinedRangeXYPlot.add(localXYPlot3, 1);
		localJFreeChart = new JFreeChart("Demo Chart", JFreeChart.DEFAULT_TITLE_FONT,
				localCombinedRangeXYPlot, true);
		TextTitle localTextTitle = new TextTitle("This is a subtitle", new Font("SansSerif", 1, 12));
		localJFreeChart.addSubtitle(localTextTitle);
		localJFreeChart.setBackgroundPaint(new GradientPaint(0F, 0F, Color.white, 0F, 1000.0F,
				Color.blue));
		ChartUtilities.applyCurrentTheme(localJFreeChart);
		return localJFreeChart;
	}

	public static TimeSeries createEURTimeSeries()
	{
		TimeSeries localTimeSeries = new TimeSeries("EUR/GBP");
		try
		{
			localTimeSeries.add(new Day(2, 1, 2001), new Double(1.5788D));
			localTimeSeries.add(new Day(3, 1, 2001), new Double(1.5912999999999999D));
			localTimeSeries.add(new Day(4, 1, 2001), new Double(1.5807D));
			localTimeSeries.add(new Day(5, 1, 2001), new Double(1.5710999999999999D));
			localTimeSeries.add(new Day(8, 1, 2001), new Double(1.5778000000000001D));
			localTimeSeries.add(new Day(9, 1, 2001), new Double(1.5851D));
			localTimeSeries.add(new Day(10, 1, 2001), new Double(1.5846D));
			localTimeSeries.add(new Day(11, 1, 2001), new Double(1.5727D));
			localTimeSeries.add(new Day(12, 1, 2001), new Double(1.5585D));
			localTimeSeries.add(new Day(15, 1, 2001), new Double(1.5693999999999999D));
			localTimeSeries.add(new Day(16, 1, 2001), new Double(1.5629D));
			localTimeSeries.add(new Day(17, 1, 2001), new Double(1.5831D));
			localTimeSeries.add(new Day(18, 1, 2001), new Double(1.5624D));
			localTimeSeries.add(new Day(19, 1, 2001), new Double(1.5693999999999999D));
			localTimeSeries.add(new Day(22, 1, 2001), new Double(1.5615000000000001D));
			localTimeSeries.add(new Day(23, 1, 2001), new Double(1.5656000000000001D));
			localTimeSeries.add(new Day(24, 1, 2001), new Double(1.5794999999999999D));
			localTimeSeries.add(new Day(25, 1, 2001), new Double(1.5851999999999999D));
			localTimeSeries.add(new Day(26, 1, 2001), new Double(1.5797000000000001D));
			localTimeSeries.add(new Day(29, 1, 2001), new Double(1.5862000000000001D));
			localTimeSeries.add(new Day(30, 1, 2001), new Double(1.5803D));
			localTimeSeries.add(new Day(31, 1, 2001), new Double(1.5713999999999999D));
			localTimeSeries.add(new Day(1, 2, 2001), new Double(1.5717000000000001D));
			localTimeSeries.add(new Day(2, 2, 2001), new Double(1.5734999999999999D));
			localTimeSeries.add(new Day(5, 2, 2001), new Double(1.5690999999999999D));
			localTimeSeries.add(new Day(6, 2, 2001), new Double(1.5676000000000001D));
			localTimeSeries.add(new Day(7, 2, 2001), new Double(1.5677000000000001D));
			localTimeSeries.add(new Day(8, 2, 2001), new Double(1.5737000000000001D));
			localTimeSeries.add(new Day(9, 2, 2001), new Double(1.5653999999999999D));
			localTimeSeries.add(new Day(12, 2, 2001), new Double(1.5621D));
			localTimeSeries.add(new Day(13, 2, 2001), new Double(1.5761000000000001D));
			localTimeSeries.add(new Day(14, 2, 2001), new Double(1.5898000000000001D));
			localTimeSeries.add(new Day(15, 2, 2001), new Double(1.6045D));
			localTimeSeries.add(new Day(16, 2, 2001), new Double(1.5851999999999999D));
			localTimeSeries.add(new Day(19, 2, 2001), new Double(1.5704D));
			localTimeSeries.add(new Day(20, 2, 2001), new Double(1.5891999999999999D));
			localTimeSeries.add(new Day(21, 2, 2001), new Double(1.5844D));
			localTimeSeries.add(new Day(22, 2, 2001), new Double(1.5933999999999999D));
			localTimeSeries.add(new Day(23, 2, 2001), new Double(1.5951D));
			localTimeSeries.add(new Day(26, 2, 2001), new Double(1.5848D));
			localTimeSeries.add(new Day(27, 2, 2001), new Double(1.5706D));
			localTimeSeries.add(new Day(28, 2, 2001), new Double(1.5680000000000001D));
			localTimeSeries.add(new Day(1, 3, 2001), new Double(1.5645D));
			localTimeSeries.add(new Day(2, 3, 2001), new Double(1.5753999999999999D));
			localTimeSeries.add(new Day(5, 3, 2001), new Double(1.5808D));
			localTimeSeries.add(new Day(6, 3, 2001), new Double(1.5766D));
			localTimeSeries.add(new Day(7, 3, 2001), new Double(1.5755999999999999D));
			localTimeSeries.add(new Day(8, 3, 2001), new Double(1.5760000000000001D));
			localTimeSeries.add(new Day(9, 3, 2001), new Double(1.5748D));
			localTimeSeries.add(new Day(12, 3, 2001), new Double(1.5779000000000001D));
			localTimeSeries.add(new Day(13, 3, 2001), new Double(1.5837000000000001D));
			localTimeSeries.add(new Day(14, 3, 2001), new Double(1.5886D));
			localTimeSeries.add(new Day(15, 3, 2001), new Double(1.5931D));
			localTimeSeries.add(new Day(16, 3, 2001), new Double(1.5945D));
			localTimeSeries.add(new Day(19, 3, 2001), new Double(1.5880000000000001D));
			localTimeSeries.add(new Day(20, 3, 2001), new Double(1.5817000000000001D));
			localTimeSeries.add(new Day(21, 3, 2001), new Double(1.5927D));
			localTimeSeries.add(new Day(22, 3, 2001), new Double(1.6065D));
			localTimeSeries.add(new Day(23, 3, 2001), new Double(1.6006D));
			localTimeSeries.add(new Day(26, 3, 2001), new Double(1.6007D));
			localTimeSeries.add(new Day(27, 3, 2001), new Double(1.5989D));
			localTimeSeries.add(new Day(28, 3, 2001), new Double(1.6134999999999999D));
			localTimeSeries.add(new Day(29, 3, 2001), new Double(1.6282000000000001D));
			localTimeSeries.add(new Day(30, 3, 2001), new Double(1.609D));
			localTimeSeries.add(new Day(2, 4, 2001), new Double(1.6107D));
			localTimeSeries.add(new Day(3, 4, 2001), new Double(1.6093D));
			localTimeSeries.add(new Day(4, 4, 2001), new Double(1.5880000000000001D));
			localTimeSeries.add(new Day(5, 4, 2001), new Double(1.5931D));
			localTimeSeries.add(new Day(6, 4, 2001), new Double(1.5968D));
			localTimeSeries.add(new Day(9, 4, 2001), new Double(1.6072D));
			localTimeSeries.add(new Day(10, 4, 2001), new Double(1.6167D));
			localTimeSeries.add(new Day(11, 4, 2001), new Double(1.6214D));
			localTimeSeries.add(new Day(12, 4, 2001), new Double(1.6120000000000001D));
			localTimeSeries.add(new Day(17, 4, 2001), new Double(1.6229D));
			localTimeSeries.add(new Day(18, 4, 2001), new Double(1.6297999999999999D));
			localTimeSeries.add(new Day(19, 4, 2001), new Double(1.6158999999999999D));
			localTimeSeries.add(new Day(20, 4, 2001), new Double(1.5995999999999999D));
			localTimeSeries.add(new Day(23, 4, 2001), new Double(1.6042000000000001D));
			localTimeSeries.add(new Day(24, 4, 2001), new Double(1.6061000000000001D));
			localTimeSeries.add(new Day(25, 4, 2001), new Double(1.6045D));
			localTimeSeries.add(new Day(26, 4, 2001), new Double(1.597D));
			localTimeSeries.add(new Day(27, 4, 2001), new Double(1.6094999999999999D));
			localTimeSeries.add(new Day(30, 4, 2001), new Double(1.6141000000000001D));
			localTimeSeries.add(new Day(1, 5, 2001), new Double(1.6075999999999999D));
			localTimeSeries.add(new Day(2, 5, 2001), new Double(1.6076999999999999D));
			localTimeSeries.add(new Day(3, 5, 2001), new Double(1.6034999999999999D));
			localTimeSeries.add(new Day(4, 5, 2001), new Double(1.6060000000000001D));
			localTimeSeries.add(new Day(8, 5, 2001), new Double(1.6177999999999999D));
			localTimeSeries.add(new Day(9, 5, 2001), new Double(1.6083000000000001D));
			localTimeSeries.add(new Day(10, 5, 2001), new Double(1.6107D));
			localTimeSeries.add(new Day(11, 5, 2001), new Double(1.6209D));
			localTimeSeries.add(new Day(14, 5, 2001), new Double(1.6228D));
			localTimeSeries.add(new Day(15, 5, 2001), new Double(1.6184000000000001D));
			localTimeSeries.add(new Day(16, 5, 2001), new Double(1.6167D));
			localTimeSeries.add(new Day(17, 5, 2001), new Double(1.6223000000000001D));
			localTimeSeries.add(new Day(18, 5, 2001), new Double(1.6305000000000001D));
			localTimeSeries.add(new Day(21, 5, 2001), new Double(1.6419999999999999D));
			localTimeSeries.add(new Day(22, 5, 2001), new Double(1.6484000000000001D));
			localTimeSeries.add(new Day(23, 5, 2001), new Double(1.6547000000000001D));
			localTimeSeries.add(new Day(24, 5, 2001), new Double(1.6444000000000001D));
			localTimeSeries.add(new Day(25, 5, 2001), new Double(1.6577D));
			localTimeSeries.add(new Day(29, 5, 2001), new Double(1.6606000000000001D));
			localTimeSeries.add(new Day(30, 5, 2001), new Double(1.6604000000000001D));
			localTimeSeries.add(new Day(31, 5, 2001), new Double(1.6772D));
			localTimeSeries.add(new Day(1, 6, 2001), new Double(1.6717D));
			localTimeSeries.add(new Day(4, 6, 2001), new Double(1.6685000000000001D));
			localTimeSeries.add(new Day(5, 6, 2001), new Double(1.6620999999999999D));
			localTimeSeries.add(new Day(6, 6, 2001), new Double(1.6459999999999999D));
			localTimeSeries.add(new Day(7, 6, 2001), new Double(1.6333D));
			localTimeSeries.add(new Day(8, 6, 2001), new Double(1.6265000000000001D));
			localTimeSeries.add(new Day(11, 6, 2001), new Double(1.6311D));
			localTimeSeries.add(new Day(12, 6, 2001), new Double(1.6237999999999999D));
			localTimeSeries.add(new Day(13, 6, 2001), new Double(1.6299999999999999D));
			localTimeSeries.add(new Day(14, 6, 2001), new Double(1.6289D));
			localTimeSeries.add(new Day(15, 6, 2001), new Double(1.6275999999999999D));
			localTimeSeries.add(new Day(18, 6, 2001), new Double(1.6298999999999999D));
			localTimeSeries.add(new Day(19, 6, 2001), new Double(1.6353D));
			localTimeSeries.add(new Day(20, 6, 2001), new Double(1.6377999999999999D));
			localTimeSeries.add(new Day(21, 6, 2001), new Double(1.6567000000000001D));
			localTimeSeries.add(new Day(22, 6, 2001), new Double(1.6523000000000001D));
			localTimeSeries.add(new Day(25, 6, 2001), new Double(1.6417999999999999D));
			localTimeSeries.add(new Day(26, 6, 2001), new Double(1.6429D));
			localTimeSeries.add(new Day(27, 6, 2001), new Double(1.6438999999999999D));
			localTimeSeries.add(new Day(28, 6, 2001), new Double(1.6605000000000001D));
			localTimeSeries.add(new Day(29, 6, 2001), new Double(1.6598999999999999D));
			localTimeSeries.add(new Day(2, 7, 2001), new Double(1.6727000000000001D));
			localTimeSeries.add(new Day(3, 7, 2001), new Double(1.6619999999999999D));
			localTimeSeries.add(new Day(4, 7, 2001), new Double(1.6628000000000001D));
			localTimeSeries.add(new Day(5, 7, 2001), new Double(1.673D));
			localTimeSeries.add(new Day(6, 7, 2001), new Double(1.6649D));
			localTimeSeries.add(new Day(9, 7, 2001), new Double(1.6603000000000001D));
			localTimeSeries.add(new Day(10, 7, 2001), new Double(1.6489D));
			localTimeSeries.add(new Day(11, 7, 2001), new Double(1.6420999999999999D));
			localTimeSeries.add(new Day(12, 7, 2001), new Double(1.6497999999999999D));
			localTimeSeries.add(new Day(13, 7, 2001), new Double(1.6447000000000001D));
			localTimeSeries.add(new Day(16, 7, 2001), new Double(1.6373D));
			localTimeSeries.add(new Day(17, 7, 2001), new Double(1.6443000000000001D));
			localTimeSeries.add(new Day(18, 7, 2001), new Double(1.6246D));
			localTimeSeries.add(new Day(19, 7, 2001), new Double(1.6294999999999999D));
			localTimeSeries.add(new Day(20, 7, 2001), new Double(1.6362000000000001D));
			localTimeSeries.add(new Day(23, 7, 2001), new Double(1.6348D));
			localTimeSeries.add(new Day(24, 7, 2001), new Double(1.6242000000000001D));
			localTimeSeries.add(new Day(25, 7, 2001), new Double(1.6241000000000001D));
			localTimeSeries.add(new Day(26, 7, 2001), new Double(1.6281000000000001D));
			localTimeSeries.add(new Day(27, 7, 2001), new Double(1.6295999999999999D));
			localTimeSeries.add(new Day(30, 7, 2001), new Double(1.6278999999999999D));
			localTimeSeries.add(new Day(31, 7, 2001), new Double(1.6299999999999999D));
			localTimeSeries.add(new Day(1, 8, 2001), new Double(1.629D));
			localTimeSeries.add(new Day(2, 8, 2001), new Double(1.6236999999999999D));
			localTimeSeries.add(new Day(3, 8, 2001), new Double(1.6137999999999999D));
			localTimeSeries.add(new Day(6, 8, 2001), new Double(1.6121000000000001D));
			localTimeSeries.add(new Day(7, 8, 2001), new Double(1.617D));
			localTimeSeries.add(new Day(8, 8, 2001), new Double(1.6134999999999999D));
			localTimeSeries.add(new Day(9, 8, 2001), new Double(1.5995999999999999D));
			localTimeSeries.add(new Day(10, 8, 2001), new Double(1.5931D));
			localTimeSeries.add(new Day(13, 8, 2001), new Double(1.5828D));
			localTimeSeries.add(new Day(14, 8, 2001), new Double(1.5824D));
			localTimeSeries.add(new Day(15, 8, 2001), new Double(1.5783D));
			localTimeSeries.add(new Day(16, 8, 2001), new Double(1.581D));
			localTimeSeries.add(new Day(17, 8, 2001), new Double(1.5761000000000001D));
			localTimeSeries.add(new Day(20, 8, 2001), new Double(1.5831D));
			localTimeSeries.add(new Day(21, 8, 2001), new Double(1.587D));
			localTimeSeries.add(new Day(22, 8, 2001), new Double(1.5808D));
			localTimeSeries.add(new Day(23, 8, 2001), new Double(1.5845D));
			localTimeSeries.add(new Day(24, 8, 2001), new Double(1.5844D));
			localTimeSeries.add(new Day(28, 8, 2001), new Double(1.5924D));
			localTimeSeries.add(new Day(29, 8, 2001), new Double(1.595D));
			localTimeSeries.add(new Day(30, 8, 2001), new Double(1.5941000000000001D));
			localTimeSeries.add(new Day(31, 8, 2001), new Double(1.5968D));
			localTimeSeries.add(new Day(3, 9, 2001), new Double(1.6020000000000001D));
			localTimeSeries.add(new Day(4, 9, 2001), new Double(1.6235999999999999D));
			localTimeSeries.add(new Day(5, 9, 2001), new Double(1.6352D));
			localTimeSeries.add(new Day(6, 9, 2001), new Double(1.6302000000000001D));
			localTimeSeries.add(new Day(7, 9, 2001), new Double(1.6180000000000001D));
			localTimeSeries.add(new Day(10, 9, 2001), new Double(1.6217999999999999D));
			localTimeSeries.add(new Day(11, 9, 2001), new Double(1.6182000000000001D));
			localTimeSeries.add(new Day(12, 9, 2001), new Double(1.6156999999999999D));
			localTimeSeries.add(new Day(13, 9, 2001), new Double(1.6171D));
			localTimeSeries.add(new Day(14, 9, 2001), new Double(1.5960000000000001D));
			localTimeSeries.add(new Day(17, 9, 2001), new Double(1.5952D));
			localTimeSeries.add(new Day(18, 9, 2001), new Double(1.5863D));
			localTimeSeries.add(new Day(19, 9, 2001), new Double(1.579D));
			localTimeSeries.add(new Day(20, 9, 2001), new Double(1.5810999999999999D));
			localTimeSeries.add(new Day(21, 9, 2001), new Double(1.5916999999999999D));
			localTimeSeries.add(new Day(24, 9, 2001), new Double(1.6005D));
			localTimeSeries.add(new Day(25, 9, 2001), new Double(1.5914999999999999D));
			localTimeSeries.add(new Day(26, 9, 2001), new Double(1.6012D));
			localTimeSeries.add(new Day(27, 9, 2001), new Double(1.6032D));
			localTimeSeries.add(new Day(28, 9, 2001), new Double(1.6133D));
			localTimeSeries.add(new Day(1, 10, 2001), new Double(1.6147D));
			localTimeSeries.add(new Day(2, 10, 2001), new Double(1.6002000000000001D));
			localTimeSeries.add(new Day(3, 10, 2001), new Double(1.6041000000000001D));
			localTimeSeries.add(new Day(4, 10, 2001), new Double(1.6172D));
			localTimeSeries.add(new Day(5, 10, 2001), new Double(1.6121000000000001D));
			localTimeSeries.add(new Day(8, 10, 2001), new Double(1.6044D));
			localTimeSeries.add(new Day(9, 10, 2001), new Double(1.5973999999999999D));
			localTimeSeries.add(new Day(10, 10, 2001), new Double(1.5914999999999999D));
			localTimeSeries.add(new Day(11, 10, 2001), new Double(1.6022000000000001D));
			localTimeSeries.add(new Day(12, 10, 2001), new Double(1.6013999999999999D));
			localTimeSeries.add(new Day(15, 10, 2001), new Double(1.5942000000000001D));
			localTimeSeries.add(new Day(16, 10, 2001), new Double(1.5925D));
			localTimeSeries.add(new Day(17, 10, 2001), new Double(1.6007D));
			localTimeSeries.add(new Day(18, 10, 2001), new Double(1.6000000000000001D));
			localTimeSeries.add(new Day(19, 10, 2001), new Double(1.603D));
			localTimeSeries.add(new Day(22, 10, 2001), new Double(1.6013999999999999D));
			localTimeSeries.add(new Day(23, 10, 2001), new Double(1.5994999999999999D));
			localTimeSeries.add(new Day(24, 10, 2001), new Double(1.5951D));
			localTimeSeries.add(new Day(25, 10, 2001), new Double(1.5952999999999999D));
			localTimeSeries.add(new Day(26, 10, 2001), new Double(1.6056999999999999D));
			localTimeSeries.add(new Day(29, 10, 2001), new Double(1.6051D));
			localTimeSeries.add(new Day(30, 10, 2001), new Double(1.6027D));
			localTimeSeries.add(new Day(31, 10, 2001), new Double(1.6144000000000001D));
			localTimeSeries.add(new Day(1, 11, 2001), new Double(1.6138999999999999D));
			localTimeSeries.add(new Day(2, 11, 2001), new Double(1.6189D));
			localTimeSeries.add(new Day(5, 11, 2001), new Double(1.6248D));
			localTimeSeries.add(new Day(6, 11, 2001), new Double(1.6267D));
			localTimeSeries.add(new Day(7, 11, 2001), new Double(1.6281000000000001D));
			localTimeSeries.add(new Day(8, 11, 2001), new Double(1.631D));
			localTimeSeries.add(new Day(9, 11, 2001), new Double(1.6313D));
			localTimeSeries.add(new Day(12, 11, 2001), new Double(1.6272D));
			localTimeSeries.add(new Day(13, 11, 2001), new Double(1.6361000000000001D));
			localTimeSeries.add(new Day(14, 11, 2001), new Double(1.6323000000000001D));
			localTimeSeries.add(new Day(15, 11, 2001), new Double(1.6252D));
			localTimeSeries.add(new Day(16, 11, 2001), new Double(1.6141000000000001D));
			localTimeSeries.add(new Day(19, 11, 2001), new Double(1.6086D));
			localTimeSeries.add(new Day(20, 11, 2001), new Double(1.6054999999999999D));
			localTimeSeries.add(new Day(21, 11, 2001), new Double(1.6132D));
			localTimeSeries.add(new Day(22, 11, 2001), new Double(1.6073999999999999D));
			localTimeSeries.add(new Day(23, 11, 2001), new Double(1.6065D));
			localTimeSeries.add(new Day(26, 11, 2001), new Double(1.6061000000000001D));
			localTimeSeries.add(new Day(27, 11, 2001), new Double(1.6039000000000001D));
			localTimeSeries.add(new Day(28, 11, 2001), new Double(1.6069D));
			localTimeSeries.add(new Day(29, 11, 2001), new Double(1.6044D));
			localTimeSeries.add(new Day(30, 11, 2001), new Double(1.5928D));
		}
		catch (Exception localException)
		{
			System.err.println(localException.getMessage());
		}
		return localTimeSeries;
	}

	public static JPanel createDemoPanel()
	{
		JFreeChart localJFreeChart = createCombinedChart();
		return new ChartPanel(localJFreeChart);
	}

	public static void main(String[] paramArrayOfString)
	{
		CombinedXYPlotDemo3 localCombinedXYPlotDemo3 = new CombinedXYPlotDemo3(
				"JFreeChart: CombinedXYPlotDemo3.java");
		localCombinedXYPlotDemo3.pack();
		RefineryUtilities.centerFrameOnScreen(localCombinedXYPlotDemo3);
		localCombinedXYPlotDemo3.setVisible(true);
	}
}