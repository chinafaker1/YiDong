package samples.jfreechart.demo;

import java.awt.LayoutManager;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.JFreeChart;

public class DemoPanel extends JPanel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8065465883144555750L;
	List<JFreeChart> charts = new ArrayList<JFreeChart>();

	public DemoPanel(LayoutManager paramLayoutManager)
	{
		super(paramLayoutManager);
	}

	public void addChart(JFreeChart paramJFreeChart)
	{
		this.charts.add(paramJFreeChart);
	}

	public JFreeChart[] getCharts()
	{
		int i = this.charts.size();
		JFreeChart[] arrayOfJFreeChart = new JFreeChart[i];
		for (int j = 0; j < i; ++j)
			arrayOfJFreeChart[j] = ((JFreeChart) this.charts.get(j));
		return arrayOfJFreeChart;
	}
}