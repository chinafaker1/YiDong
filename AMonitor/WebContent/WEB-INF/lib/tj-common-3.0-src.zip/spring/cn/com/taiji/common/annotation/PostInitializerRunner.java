package spring.cn.com.taiji.common.annotation;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.pub.AnnotationTools;

/**
 * User: AlphaCSP
 * 
 * @since: Aug 7, 2008
 * @see {@link PostInitialize}
 */
public class PostInitializerRunner extends AbstractManager implements ApplicationListener<ContextRefreshedEvent>
{
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event)
	{
		logger.info("Scanning for Post Initializers...");
		long startTime = System.currentTimeMillis();
		ApplicationContext applicationContext = event.getApplicationContext();
		Map<String, Object> beans = applicationContext.getBeansOfType(Object.class);
		List<PostInitializingMethod> postInitializingMethods = new LinkedList<PostInitializingMethod>();
		for (String beanName : beans.keySet())
		{
			Object bean = beans.get(beanName);
			Class<?> beanClass = bean.getClass();
			Method[] methods = beanClass.getMethods();
			for (Method method : methods)
			{
				if (AnnotationTools.getAnnotation(method, PostInitialize.class) == null) continue;
				if (method.getParameterTypes().length == 0)
				{
					int order = method.getAnnotation(PostInitialize.class).order();
					postInitializingMethods.add(new PostInitializingMethod(method, bean, order, beanName));
				}
				else
				{
					logger.warn("Post Initializer method can't have any arguments. {} in bean {} won't be invoked",
							method.toGenericString(), beanName);
				}
			}
		}
		Collections.sort(postInitializingMethods);
		long endTime = System.currentTimeMillis();
		logger.info("Application Context scan completed, took {} ms, {} post initializers found. Invoking now.",
				(endTime - startTime), postInitializingMethods.size());
		for (PostInitializingMethod postInitializingMethod : postInitializingMethods)
		{
			Method method = postInitializingMethod.getMethod();
			try
			{
				method.invoke(postInitializingMethod.getBeanInstance());
			}
			catch (Throwable e)
			{
				throw new BeanCreationException("Post Initialization of bean " + postInitializingMethod.getBeanName()
						+ " failed.", e);
			}
		}
	}

	private class PostInitializingMethod implements Comparable<PostInitializingMethod>
	{
		private Method method;
		private Object beanInstance;
		private int order;
		private String beanName;

		private PostInitializingMethod(Method method, Object beanInstance, int order, String beanName)
		{
			this.method = method;
			this.beanInstance = beanInstance;
			this.order = order;
			this.beanName = beanName;
		}

		public Method getMethod()
		{
			return method;
		}

		public Object getBeanInstance()
		{
			return beanInstance;
		}

		public String getBeanName()
		{
			return beanName;
		}

		@Override
		public int compareTo(PostInitializingMethod anotherPostInitializingMethod)
		{
			int thisVal = this.order;
			int anotherVal = anotherPostInitializingMethod.order;
			return (thisVal < anotherVal ? -1 : (thisVal == anotherVal ? 0 : 1));
		}

		@Override
		public boolean equals(Object o)
		{
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;

			PostInitializingMethod that = (PostInitializingMethod) o;

			return order == that.order && !(beanName != null ? !beanName.equals(that.beanName) : that.beanName != null)
					&& !(method != null ? !method.equals(that.method) : that.method != null);

		}

		@Override
		public int hashCode()
		{
			int result;
			result = (method != null ? method.hashCode() : 0);
			result = 31 * result + (beanInstance != null ? beanInstance.hashCode() : 0);
			result = 31 * result + order;
			result = 31 * result + (beanName != null ? beanName.hashCode() : 0);
			return result;
		}
	}
}
