package spring.cn.com.taiji.common.annotation;

import java.lang.annotation.Documented;
import static java.lang.annotation.ElementType.METHOD;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;

import javax.annotation.PostConstruct;

/**
 * 解决 {@link PostConstruct}注解的方法无法运行事务的问题<BR/>
 * User: AlphaCSP
 * 
 * @since: Aug 7, 2008
 * @see {@link PostInitializerRunner}
 */
@Documented
@Retention(RUNTIME)
@Target(METHOD)
public @interface PostInitialize
{

	int order() default 0;
}
