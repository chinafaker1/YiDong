package cn.com.taiji.common.manager.net.vfs;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.vfs2.FileObject;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2015年8月15日 上午8:36:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class VfsFileNameComparator implements Comparator<FileObject>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7208033359976133622L;
	private boolean desc;

	public VfsFileNameComparator()
	{
		this.desc = false;
	}

	public VfsFileNameComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(FileObject o1, FileObject o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null || o1.getName().getBaseName() == null) return desc ? 1 : -1;
		if (o2 == null || o2.getName().getBaseName() == null) return desc ? -1 : 1;
		return compareName(o1.getName().getBaseName(), o2.getName().getBaseName());
	}

	private int compareName(String name1, String name2)
	{
		if (desc) return name2.compareToIgnoreCase(name1);
		return name1.compareToIgnoreCase(name2);
	}

}
