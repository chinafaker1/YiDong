/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

import java.io.ByteArrayInputStream;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 上午11:38:30<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link FileProtocolRequest} {@link FileProtocolSystemError}
 */
public final class FileProtocolResponse extends AbstractFileProtocol
{
	public static final int MIN_ERROR_CODE = 700;
	public static final int MIN_CODE = 0;
	public static final int MAX_CODE = 999;
	private int statusCode = 200;// 500以前和http code的意义相同，700~999是自定义错误号，950~999框架通用错误码预留,应用程序不要使用

	private String errorMsg;// 出现自定义错误时，设置此值，会将错误发送至http请求者

	public FileProtocolResponse()
	{
		this.binFile = new ByteArrayInputStream(new byte[0]);
	}

	public FileProtocolResponse(int statusCode, String errorMsg)
	{
		this.statusCode = statusCode;
		this.errorMsg = errorMsg;
		this.binFile = new ByteArrayInputStream(new byte[0]);
	}

	public int getStatusCode()
	{
		return statusCode;
	}

	public String getErrorMsg()
	{
		return errorMsg;
	}

	public void setStatusCode(int statusCode)
	{
		this.statusCode = statusCode;
	}

	public void setErrorMsg(String errorMsg)
	{
		this.errorMsg = errorMsg;
	}

}
