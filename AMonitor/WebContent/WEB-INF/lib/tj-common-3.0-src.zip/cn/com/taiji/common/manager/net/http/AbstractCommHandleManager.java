/*
 * Date: 2015年4月3日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;
import java.io.InputStream;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.file.AbstractFileProtocol;
import cn.com.taiji.common.model.file.FileProtocolRequest;
import cn.com.taiji.common.model.file.FileProtocolResponse;
import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月3日 下午4:33:44<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractCommHandleManager extends AbstractManager
{
	/**
	 * 检查协议
	 * 
	 * @param protocol
	 * @throws IOException
	 */
	protected void checkProtocol(JsonProtocol protocol) throws IOException
	{
		logger.debug("JSON comm handle:{}", protocol);
		if (!hasText(protocol.getJsonStr())) throw new IOException("请求的json字符串不能为空:" + protocol.getType());
	}

	protected void checkFileProtocol(FileProtocolRequest request)
	{
		checkAbstractFileProtocol(request);
	}

	protected void checkFileProtocol(FileProtocolResponse response)
	{
		int sc = response.getStatusCode();
		if (sc > FileProtocolResponse.MAX_CODE || sc < FileProtocolResponse.MIN_CODE)
			throw new IllegalArgumentException(toLogString("响应代码应该介于:{}~{}", FileProtocolResponse.MIN_CODE,
					FileProtocolResponse.MAX_CODE));
		if (sc >= FileProtocolResponse.MIN_ERROR_CODE && !hasText(response.getErrorMsg()))
			throw new IllegalArgumentException(toLogString("响应代码大于等于{}时需要指定错误原因", FileProtocolResponse.MIN_ERROR_CODE));
		// 先检查错误代码再检查响应文件是否存在,非自定义错误代码时才检查
		if (sc < FileProtocolResponse.MIN_ERROR_CODE) checkAbstractFileProtocol(response);
	}

	private void checkAbstractFileProtocol(AbstractFileProtocol protocol)
	{
		if (!hasText(protocol.getFilename())) throw new IllegalArgumentException("文件名不能为空");
		InputStream file = protocol.getBinFile();
		if (file == null) throw new IllegalArgumentException("请求或者响应的文件二进制流不能为空");
	}
}
