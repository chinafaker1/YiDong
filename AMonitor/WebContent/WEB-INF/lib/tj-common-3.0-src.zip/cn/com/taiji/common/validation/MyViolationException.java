/*
 * Date: 2013-3-22
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.validation;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.validation.ValidationException;

import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.json.JsonTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-3-22 下午11:13:54<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class MyViolationException extends ValidationException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4343434077482104409L;
	private Map<String, String> violations = new HashMap<String, String>();

	public MyViolationException()
	{

	}

	public MyViolationException(String property, String message)
	{
		violations.put(property, message);
	}

	public boolean hasViolation()
	{
		return !violations.isEmpty();
	}

	public void addViolation(String property, String message, Object... args)
	{
		violations.put(property, StringTools.toLogString(message, args));
	}

	public String toJson()
	{
		try
		{
			return JsonTools.toJsonStr(violations);
		}
		catch (IOException e)
		{
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public String toString()
	{
		return toJson();
	}
}
