package cn.com.taiji.common.pub.handler;

import java.io.InputStream;

import cn.com.taiji.common.pub.ScriptTool;


/**
 * 处理执行脚本后的输出
 * @see {@link ScriptTool}
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-1 上午09:48:59
 * @since 1.0
 * @version 1.0
 */
public interface ScriptInputHandler
{
	/**
	 * 处理执行脚本后的输出
	 * @param input
	 */
	public void handle(final InputStream input);
}
