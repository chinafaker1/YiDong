package cn.com.taiji.common.pub;

/**
 * @author Peream	mail:peream@gmail.com
 *
 * 2007-7-26 下午01:43:22
 * @since 1.0
 * @Version 1.0
 */
public class PubException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5735562079455529393L;

	public PubException()
	{
		super();
	}

	public PubException(String message)
	{
		super(message);
	}

	public PubException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
