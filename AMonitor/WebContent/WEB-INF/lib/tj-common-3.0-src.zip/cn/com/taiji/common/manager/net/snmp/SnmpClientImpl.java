package cn.com.taiji.common.manager.net.snmp;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.ScopedPDU;
import org.snmp4j.Snmp;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.net.ClientFactory;
import cn.com.taiji.common.model.net.snmp.AlertTrap;
import cn.com.taiji.common.model.net.snmp.BaseSnmpTarget;
import cn.com.taiji.common.model.net.snmp.SnmpV3Target;
import cn.com.taiji.common.model.net.snmp.SwitchIp;
import cn.com.taiji.common.model.net.snmp.V1Trap;
import cn.com.taiji.common.model.net.snmp.V2Trap;
import cn.com.taiji.common.model.net.snmp.V3Trap;


/**
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:37:31
 * @since 1.0
 * @version 1.0
 */
public class SnmpClientImpl extends AbstractManager implements SnmpClient
{
	// oid strs以下为IP表
	private String oidIpStr = "1.3.6.1.2.1.4.22.1.3";

	private String oidMacStr = "1.3.6.1.2.1.4.22.1.2";

	private String oidIfNumStr = "1.3.6.1.2.1.4.22.1.1";

	// 以下为网关－接口 列表
	private String oidGwStr = "1.3.6.1.2.1.4.20.1.1";

	private String oidGwIfStr = "1.3.6.1.2.1.4.20.1.2";

	// 以下为alcatel私有的查询oid
	private String oidAlcatelStr = "1.3.6.1.4.1.6486.800.1.2.1.23.1.1.2.1.1";

	private SnmpClientHandler handler;

	private Object lock = new Object();

	public void trapV1(V1Trap trap, BaseSnmpTarget target) throws IOException
	{
		if (SnmpConstants.version1 != target.getVersion())
			throw new IllegalArgumentException("target version must be SnmpConstants.version1");
		Snmp snmp = ClientFactory.getSnmpClient(target);
		try
		{
			PDUv1 pdu = trap.getV1Trap();
			snmp.trap(pdu, target.getCommunityTarget());
		}
		catch (IOException e)
		{
			ClientFactory.removeSnmpClient(target);
			throw e;
		}
	}

	public void trapV2(V2Trap trap, BaseSnmpTarget target) throws IOException
	{
		if (SnmpConstants.version2c != target.getVersion())
			throw new IllegalArgumentException("target version must be SnmpConstants.version2c");
		Snmp snmp = ClientFactory.getSnmpClient(target);
		try
		{
			PDU pdu = trap.getV2cTrap();
			snmp.send(pdu, target.getCommunityTarget());
		}
		catch (IOException e)
		{
			ClientFactory.removeSnmpClient(target);
			throw e;
		}
	}

	public void trapV3(V3Trap trap, SnmpV3Target target, int securityLevel) throws IOException
	{
		if (SnmpConstants.version3 != target.getVersion())
			throw new IllegalArgumentException("target version must be SnmpConstants.version3");
		Snmp snmp = ClientFactory.getSnmpV3Client(target);
		try
		{
			ScopedPDU pdu = trap.getV3Trap();
			snmp.send(pdu, target.getUserTarget(securityLevel));
		}
		catch (IOException e)
		{
			ClientFactory.removeSnmpV3Client(target);
			throw e;
		}
	}

	public void trapAlert(AlertTrap alertTrap, BaseSnmpTarget target) throws IOException
	{
		if (SnmpConstants.version1 == target.getVersion())
		{
			trapV1(alertTrap, target);
		}
		else if (SnmpConstants.version2c == target.getVersion())
		{
			trapV2(alertTrap, target);
		}
		else
			throw new RuntimeException("use trapV3Alert instead.");
	}

	public void trapV3Alert(AlertTrap alertTrap, SnmpV3Target target, int securityLevel)
			throws IOException
	{
		trapV3(alertTrap, target, securityLevel);
	}

	public void searchHost(BaseSnmpTarget target) throws IOException
	{
		OID oidIpFinished = new OID(oidIpStr);
		OID oidIp = new OID(oidIpStr);
		OID oidMac = new OID(oidMacStr);
		OID oidIfNum = new OID(oidIfNumStr);
		PDU request = new PDU();
		try
		{
			synchronized (lock)
			{
				Map<String, String> gwIfMap = getGwIf(target);
				echoMap(gwIfMap);
				Snmp snmp = ClientFactory.getSnmpClient(target);
				for (int count = 0; count < 65535; count++)
				{
					request.clear();
					request.setType(PDU.GETNEXT);
					request.add(new VariableBinding(oidIp));
					request.add(new VariableBinding(oidMac));
					request.add(new VariableBinding(oidIfNum));
					ResponseEvent event = snmp.send(request, target.getCommunityTarget());
					PDU response = event.getResponse();
					if (response == null) throw new IOException("扫描交换机错误，原因：请求超时");
					oidIp = response.get(0).getOid();
					if (!(oidIp.startsWith(oidIpFinished)))
					{
						logger.debug("count = {}", count);
						break;
					}
					oidMac = response.get(1).getOid();
					oidIfNum = response.get(2).getOid();
					SwitchIp switchIp = new SwitchIp();
					String ip = response.get(0).getVariable().toString();
					String mac = response.get(1).getVariable().toString();
					String ifNum = response.get(2).getVariable().toString();
					switchIp.setIp(ip);
					switchIp.setMac(mac);
					switchIp.setIfNum(ifNum);
					if (handler == null) handler = new EchoSnmpClientHandler();
					handler.handleSwitchIp(gwIfMap, switchIp);
				}
			}
		}
		catch (IOException e)
		{
			ClientFactory.removeSnmpClient(target);
			throw e;
		}
	}

	public void searchAlcatelSwitch(BaseSnmpTarget target) throws IOException
	{
		OID oidIpFinished = new OID(oidAlcatelStr);
		OID oidIp = new OID(oidAlcatelStr);
		PDU request = new PDU();
		try
		{
			synchronized (lock)
			{
				Map<String, String> gwIfMap = getGwIf(target);
				echoMap(gwIfMap);
				Snmp snmp = ClientFactory.getSnmpClient(target);
				for (int count = 0; count < 65535; count++)
				{
					request.clear();
					request.setType(PDU.GETNEXT);
					request.add(new VariableBinding(oidIp));
					ResponseEvent event = snmp.send(request, target.getCommunityTarget());
					PDU response = event.getResponse();
					if (response == null)
					{
						logger.info("Request {} timed out.", request);
						break;
					}
					oidIp = response.get(0).getOid();
					if (!(oidIp.startsWith(oidIpFinished)))
					{
						if (logger.isDebugEnabled()) logger.debug("count = " + count);
						break;
					}
					String oidStr = oidIp.toString();// ip,ifNum is in the
					// oid str
					String[] strs = oidStr.split("\\.");
					String ifNum = strs[17];// 倒数第5位为ifNum
					String ip = new StringBuilder(strs[18]).append(".").append(strs[19])
							.append(".").append(strs[20]).append(".").append(strs[21]).toString();// 后4位为IP
					SwitchIp switchIp = new SwitchIp();
					String mac = response.get(0).getVariable().toString();
					switchIp.setIp(ip);
					switchIp.setMac(mac);
					switchIp.setIfNum(ifNum);
					if (handler == null) handler = new EchoSnmpClientHandler();
					handler.handleSwitchIp(gwIfMap, switchIp);
				}
			}
		}
		catch (IOException e)
		{
			ClientFactory.removeSnmpClient(target);
			throw e;
		}
	}

	public void stop()
	{
		ClientFactory.stopSnmpClients();
		ClientFactory.stopSnmpV3Clients();
	}

	protected Map<String, String> getGwIf(BaseSnmpTarget target) throws IOException
	{
		OID oidGwFinished = new OID(oidGwStr);
		OID oidGw = new OID(oidGwStr);// 网关IP列表
		OID oidGwIf = new OID(oidGwIfStr);// 接口号
		Map<String, String> map = new HashMap<String, String>();
		PDU request = new PDU();
		Snmp snmp = ClientFactory.getSnmpClient(target);
		for (int count = 0; count < 65535; count++)
		{
			request.clear();
			request.setType(PDU.GETNEXT);
			request.add(new VariableBinding(oidGw));
			request.add(new VariableBinding(oidGwIf));
			ResponseEvent event = snmp.send(request, target.getCommunityTarget());
			PDU response = event.getResponse();
			if (response == null)
			{
				logger.info("Request {} timed out.", request);
				break;
			}
			oidGw = response.get(0).getOid();
			if (!(oidGw.startsWith(oidGwFinished))) break;
			oidGwIf = response.get(1).getOid();
			String gwIf = response.get(1).getVariable().toString();
			String gwIp = response.get(0).getVariable().toString();
			map.put(gwIf, gwIp);
		}
		return map;
	}

	private void echoMap(Map<String, String> map)
	{
		if (!logger.isDebugEnabled()) return;
		Set<String> keys = map.keySet();
		System.out.println("------------------GwIfMap------------------");
		System.out.println("vlan size = " + map.size());
		for (String key : keys)
		{
			System.out.println("ifNumber=" + key + ";ifIp=" + map.get(key));
		}
		System.out.println("------------------GwIfMap------------------\n");
	}

	public void setHandler(SnmpClientHandler handler)
	{
		this.handler = handler;
	}

	public void setOidAlcatelStr(String oidAlcatelStr)
	{
		this.oidAlcatelStr = oidAlcatelStr;
	}

}
