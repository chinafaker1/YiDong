package cn.com.taiji.common.manager.net.snmp;

import java.util.Map;

import org.springframework.scheduling.annotation.Async;

import cn.com.taiji.common.manager.net.AbstractNetHandler;
import cn.com.taiji.common.model.net.snmp.SwitchHost;
import cn.com.taiji.common.model.net.snmp.SwitchIp;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:33:18
 * @since 1.0
 * @version 1.0
 */
public class EchoSnmpClientHandler extends AbstractNetHandler implements SnmpClientHandler
{
	@Async
	public void handleSwitchIp(final Map<String, String> gwIfMap, final SwitchIp switchIp)
	{
		deal(gwIfMap, switchIp);
	}

	private void deal(final Map<String, String> gwIfMap, final SwitchIp switchIp)
	{
		try
		{
			String ip = switchIp.getIp();
			if (ignoreIp(ip)) return;
			String gateway = gwIfMap.get(switchIp.getIfNum());
			String mac = getMac(switchIp.getMac());
			SwitchHost host = new SwitchHost();
			host.setIp(ip);
			host.setMac(mac);
			host.setGateway(gateway);
			host.setOnline(true);
			System.out.println(host);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
	}

	protected static boolean ignoreIp(String ip)
	{
		int index = ip.lastIndexOf(".");
		int tag = Integer.parseInt(ip.substring(index + 1));
		if (tag == 0 || tag == 255) return true;
		return false;
	}

	protected static String getMac(String mac)
	{
		// String result = mac.replace(":", "");
		// result = result.replace("-", "");
		// return result;
		return mac;
	}

}
