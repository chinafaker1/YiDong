/*
 * Date: 2013-8-7
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub;

import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-8-7 下午12:37:29<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class DateTimeTools extends DateTimeUtils
{
	public static String toTimeStr(Object instant)
	{
		return new DateTime(instant).toString("yyyy-MM-dd HH:mm:ss");
	}
}
