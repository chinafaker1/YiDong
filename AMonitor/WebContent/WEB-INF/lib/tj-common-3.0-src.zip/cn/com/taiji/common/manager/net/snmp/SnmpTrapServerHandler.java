package cn.com.taiji.common.manager.net.snmp;

import org.snmp4j.PDU;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午08:41:56
 * @since 1.0
 * @version 1.0
 */
public interface SnmpTrapServerHandler
{
	/**
	 * 处理接收到的PDU
	 * 
	 * @param trap
	 *            trap信息
	 */
	public void handle(PDU trap);
}
