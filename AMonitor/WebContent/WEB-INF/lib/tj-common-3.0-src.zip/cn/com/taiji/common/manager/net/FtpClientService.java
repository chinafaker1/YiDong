package cn.com.taiji.common.manager.net;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.net.ftp.FTPCmd;
import org.apache.commons.net.ftp.FTPFile;

import cn.com.taiji.common.manager.net.helper.FtpFileNameComparator;
import cn.com.taiji.common.manager.net.helper.FtpFileSizeComparator;
import cn.com.taiji.common.manager.net.helper.FtpFileTimeComparator;
import cn.com.taiji.common.model.net.FtpStorePara;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-29 下午05:14:12
 * @since 1.0
 * @version 1.0
 */
public interface FtpClientService extends ClientService
{
	/**
	 * 执行ftp命令
	 * 
	 * @param cmd
	 *            命令
	 * @param params
	 *            参数
	 * @return 命令是否成功执行
	 * @throws IOException
	 */
	public boolean doCommand(FTPCmd cmd, String params) throws IOException;

	/**
	 * cd到远程的指定目录
	 * 
	 * @param remotePath
	 *            远程目录
	 * @return 是否成功改变目录
	 * @throws IOException
	 */
	public boolean cd(String remotePath) throws IOException;

	/**
	 * 列出指定远程目录下的所有文件名
	 * 
	 * @param pathname
	 * @return
	 * @throws IOException
	 */
	public String[] listNames(String pathname) throws IOException;

	/**
	 * 列出指定远程目录下的所有文件
	 * 
	 * @param pathname
	 *            远程文件目录
	 * @return 文件列表
	 * @throws IOException
	 */
	public List<FTPFile> listFiles(String pathname) throws IOException;

	/**
	 * 列出指定远程目录下的所有文件，用指定的比较器排序
	 * 
	 * @param path
	 *            远程文件目录
	 * @param comparator
	 *            比较器
	 * @return 文件列表
	 * @throws IOException
	 * @see {@link FtpFileNameComparator}
	 * @see {@link FtpFileSizeComparator}
	 * @see {@link FtpFileTimeComparator}
	 */
	public List<FTPFile> listFiles(String path, Comparator<FTPFile> comparator) throws IOException;

	/**
	 * 列出指定远程目录下名字符合正则表达式的文件
	 * 
	 * @param path
	 *            远程文件目录
	 * @param namePattern
	 *            名字正则
	 * @return 文件列表
	 * @throws IOException
	 */
	public List<FTPFile> listFiles(String path, Pattern namePattern) throws IOException;

	/**
	 * 列出指定远程目录下名字符合正则表达式的文件
	 * 
	 * @param path
	 *            远程文件目录
	 * @param namePattern
	 *            名字正则
	 * @param comparator
	 *            比较器
	 * @return 文件列表
	 * @throws IOException
	 * @see {@link FtpFileNameComparator}
	 * @see {@link FtpFileSizeComparator}
	 * @see {@link FtpFileTimeComparator}
	 */
	public List<FTPFile> listFiles(String path, Pattern namePattern, Comparator<FTPFile> comparator) throws IOException;

	/**
	 * 新开一个连接将文件上传至ftp服务器(不自动创建文件夹)
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式上传，默认为bin模式
	 * @return 是否上传成功
	 * @throws IOException
	 */
	public boolean storeFile(String remote, String local, boolean binaryTransfer) throws IOException;

	/**
	 * 新开一个连接将文件上传至ftp服务器(bin方式上传)
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param mkdirs
	 *            是否自动创建文件夹
	 * @param local
	 *            本地文件路径
	 * @return 是否上传成功
	 * @throws IOException
	 */
	public boolean storeFile(String remote, boolean mkdirs, String local) throws IOException;

	/**
	 * 新开一个连接将文件上传至ftp服务器
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param mkdirs
	 *            是否自动创建远程文件夹
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式上传，默认为bin模式
	 * @return 是否上传成功
	 * @throws IOException
	 */
	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer) throws IOException;

	/**
	 * 新开一个连接将文件上传至ftp服务器
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param mkdirs
	 *            是否自动创建远程文件夹
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式上传，默认为bin模式
	 * @param useSuffix
	 *            上传时是否生成以后缀结尾的临时文件
	 * @return
	 * @throws IOException
	 */
	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer, boolean useSuffix)
			throws IOException;

	/**
	 * 新开一个连接将文件上出至ftp服务器
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param mkdirs
	 *            是否自动创建远程文件夹
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式上传，默认为bin模式
	 * @param suffix
	 *            临时文件后缀
	 * @param useSuffix
	 *            上传时是否生成以后缀结尾的临时文件
	 * @return
	 * @throws IOException
	 */
	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer, String suffix,
			boolean useSuffix) throws IOException;

	/**
	 * 文件上传,参数见para注释
	 * 
	 * @param para
	 * @return
	 * @throws IOException
	 */
	public boolean storeFile(FtpStorePara para) throws IOException;

	/**
	 * 断点续传文件，服务器不存在原上传文件或者续传失败都会用重新上传.
	 * 
	 * @see {@link #storeFile(String, boolean, String, boolean, String, boolean)}
	 *      如果是重新上传，上传采用bin方式并且会自动创建缺失的文件夹
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param useSuffix
	 *            是否启用后缀，启用后缀时断点续传找的是以remote+suffix文件为断点续传文件
	 * @param suffix
	 *            后缀名
	 * @return
	 */
	public boolean resumeStore(String remote, String local, boolean useSuffix, String suffix) throws IOException;

	/**
	 * 新开一个连接将文件上传至ftp服务器(bin方式上传，不自动创建文件夹)
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @return 是否上传成功
	 * @throws IOException
	 */
	public boolean storeFile(String remote, String local) throws IOException;

	/**
	 * 新开一个连接从ftp服务器上下载文件
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式下载，默认为bin模式
	 * @param suffix
	 *            临时文件使用的后缀
	 * @return 是否下载成功
	 * @throws IOException
	 */
	public boolean downFile(String remote, String local, boolean binaryTransfer, String suffix) throws IOException;

	/**
	 * 新开一个连接从ftp服务器上下载文件
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param binaryTransfer
	 *            是否用bin文件方式下载，默认为bin模式
	 * @return 是否下载成功
	 * @throws IOException
	 */
	public boolean downFile(String remote, String local, boolean binaryTransfer) throws IOException;

	/**
	 * 新开一个连接从ftp服务器上下载文件
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @return 是否下载成功
	 * @throws IOException
	 */
	public boolean downFile(String remote, String local) throws IOException;

	/**
	 * 删除ftp服务器上的文件
	 * 
	 * @param pathname
	 *            文件的目录
	 * @return 是否删除成功，不存在返回false
	 * @throws IOException
	 *             由于连接的错误之类抛出IOException
	 */
	public boolean deleteFile(String pathname) throws IOException;

	/**
	 * 判断远程服务器上是否有指定文件
	 * 
	 * @param pathname
	 * @return
	 * @throws IOException
	 */
	public boolean hasFile(String pathname) throws IOException;

	/**
	 * 重命名远程服务器上的文件
	 * 
	 * @param from
	 *            原文件名
	 * @param to
	 *            修改后的文件名
	 * @return
	 * @throws IOException
	 */
	public boolean rename(String from, String to) throws IOException;

	/**
	 * 创建文件夹
	 * 
	 * @param path
	 * @return
	 * @throws IOException
	 */
	public boolean mkdir(String path) throws IOException;

	/**
	 * 创建文件夹,创建文件夹时自动创建相关父文件夹(如果没有)
	 * 
	 * @param path
	 * @return
	 * @throws IOException
	 * @Deprecated 与mkdir的功能相同
	 * @see {@link #mkdir(String)}
	 */
	public boolean mkdirs(String path) throws IOException;

	/**
	 * 查看当前工作目录
	 * 
	 * @return
	 * @throws IOException
	 */
	public String printWorkingDirectory() throws IOException;

	/**
	 * 删除文件夹，空文件夹才能删除
	 * 
	 * @param path
	 * @return
	 * @throws IOException
	 */
	public boolean rmdir(String path) throws IOException;

	public abstract long getLiveCheckInterval();

}
