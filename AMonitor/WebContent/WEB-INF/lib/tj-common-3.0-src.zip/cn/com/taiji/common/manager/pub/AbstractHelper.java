/*
 * Date: 2013-6-13
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-6-13 下午4:39:17<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractHelper extends AbstractManager
{
	public static final int BUFFER = 1024;
}
