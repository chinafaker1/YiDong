/*
 * Date: 2015年4月30日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub.xml;

import java.util.List;

import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.CommonAbstract;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.core.ClassLoaderReference;
import com.thoughtworks.xstream.core.util.CompositeClassLoader;
import com.thoughtworks.xstream.io.xml.Dom4JDriver;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月30日 下午4:01:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class XMLTools extends CommonAbstract
{
	protected static ClassLoaderReference clr = new ClassLoaderReference(new CompositeClassLoader());
	protected static XStreamCalendarConverter xStreamCalendarConverter = new XStreamCalendarConverter();

	protected static XStream newXStream()
	{
		XStream xstream = new XStream(null, new Dom4JDriver(), clr, null);
		xstream.autodetectAnnotations(true);
		xstream.registerConverter(xStreamCalendarConverter);// 时间使用自定义的转换方法
		return xstream;
	}

	/**
	 * 将对象转换成XML
	 * 
	 * @param obj
	 *            对象的类和属性上使用{@link XStreamAlias}进行标注
	 * @return xml字符串
	 */
	public static String toXML(Object obj)
	{
		return newXStream().toXML(obj);
	}

	/**
	 * 将XML转换成对象
	 * 
	 * @param xml
	 *            xml字符串
	 * @param clazz
	 *            对象的class
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T fromXML(String xml, Class<T> clazz)
	{
		XStream xstream = newXStream();
		xstream.processAnnotations(clazz);
		return (T) xstream.fromXML(xml);
	}

	/**
	 * 将List转换成XML
	 * 
	 * @param list
	 *            元素对象的类和属性上使用{@link XStreamAlias}进行标注
	 * @param rootEleName
	 *            根元素的名称
	 * @return
	 */
	public static String list2XML(List<?> list, String rootEleName)
	{
		AssertUtil.notNull(list);
		XStream xstream = newXStream();
		if (hasText(rootEleName)) xstream.alias(rootEleName, List.class);
		return xstream.toXML(list);
	}

	/**
	 * 将XML字符串转换成List对象
	 * 
	 * @param xml
	 *            xml字符串
	 * @param clazz
	 *            对象的类型
	 * @param rootEleName
	 *            根元素的名称
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <E> List<E> xml2List(String xml, Class<E> clazz, String rootEleName)
	{
		XStream xstream = newXStream();
		if (hasText(rootEleName)) xstream.alias(rootEleName, List.class);
		xstream.processAnnotations(clazz);
		return (List<E>) xstream.fromXML(xml);
	}
}
