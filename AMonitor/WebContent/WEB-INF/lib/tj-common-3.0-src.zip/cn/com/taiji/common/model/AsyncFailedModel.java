package cn.com.taiji.common.model;

import java.util.Calendar;

public class AsyncFailedModel extends AbstractAsyncModel
{
	private String msg;
	private Calendar time;

	public AsyncFailedModel()
	{
		super(AsyncProcessType.FAILED);
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public Calendar getTime()
	{
		return time;
	}

	public void setTime(Calendar time)
	{
		this.time = time;
	}
}
