/*
 * Date: 2015年8月14日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.vfs;

import java.util.regex.Pattern;

import org.apache.commons.vfs2.FileSelectInfo;
import org.apache.commons.vfs2.FileSelector;
import org.apache.commons.vfs2.FileType;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年8月14日 下午1:14:02<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class NamePatternSelector extends AbstractManager implements FileSelector
{
	private final Pattern pattern;

	public NamePatternSelector(Pattern pattern)
	{
		this.pattern = pattern;
	}

	@Override
	public boolean includeFile(FileSelectInfo fileInfo) throws Exception
	{
		// 自身是文件夹时不包含
		if (fileInfo.getDepth() == 0 && fileInfo.getFile().getType() != FileType.FILE) return false;
		if (pattern == null) return true;
		String name = fileInfo.getFile().getName().getBaseName();
		return pattern.matcher(name).matches();
	}

	@Override
	public boolean traverseDescendents(FileSelectInfo fileInfo) throws Exception
	{
		return fileInfo.getDepth() == 0;// 只检查第一层
	}

}
