/*
 * Date: 2011-6-15
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.pub;

import org.springframework.core.io.DefaultResourceLoader;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-15 下午03:43:26<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractContentInfo extends BaseModel
{
	/**
	 * @see {@link DefaultResourceLoader}
	 */
	protected String templateUrl;// 模板文件路径
	protected String templateEncoding;// 模板的编码方式
	/**
	 * @see {@link FileHelper#getTmpPath()}
	 */
	protected String savePath;// 如果为空，存在tmp目录下
	protected String fileName;// 如果为空，自动用UUID生成一个文件名
	protected boolean alwaysNew = true;// 是否覆盖已存在的文件

	public String getTemplateUrl()
	{
		return templateUrl;
	}

	public void setTemplateUrl(String templateUrl)
	{
		this.templateUrl = templateUrl;
	}

	public String getTemplateEncoding()
	{
		return templateEncoding;
	}

	public void setTemplateEncoding(String templateEncoding)
	{
		this.templateEncoding = templateEncoding;
	}

	public String getSavePath()
	{
		return savePath;
	}

	public void setSavePath(String savePath)
	{
		this.savePath = savePath;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public boolean isAlwaysNew()
	{
		return alwaysNew;
	}

	public void setAlwaysNew(boolean alwaysNew)
	{
		this.alwaysNew = alwaysNew;
	}

}
