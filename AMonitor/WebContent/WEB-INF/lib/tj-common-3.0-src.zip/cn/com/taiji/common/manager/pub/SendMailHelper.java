package cn.com.taiji.common.manager.pub;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import cn.com.taiji.common.model.pub.SmtpMailModel;
import cn.com.taiji.common.pub.CollectionTools;
import cn.com.taiji.common.pub.EncodeTool;
import cn.com.taiji.common.pub.ObjectTools;
import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-11 上午11:46:31
 * @since 1.0
 * @version 1.0
 */
public abstract class SendMailHelper
{
	protected static Logger logger = LoggerFactory.getLogger(SendMailHelper.class);

	public static void sendMail(SmtpMailModel model) throws MessagingException,
			UnsupportedEncodingException
	{
		Properties props = new Properties();
		// props.put("mail.debug", "true");
		props.put("mail.smtp.auth", model.isStmpAuth() ? "true" : "false");
		JavaMailSenderImpl sender = new JavaMailSenderImpl();
		sender.setHost(model.getMailServer());
		sender.setPort(model.getPort());
		sender.setProtocol("smtp");
		sender.setUsername(model.getUser());
		sender.setPassword(model.getPass());
		sender.setJavaMailProperties(props);

		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, model.getEncoding());
		helper.setSentDate(new Date());
		helper.setSubject(model.getSubject());
		String personal = StringTools.hasText(model.getPersonal()) ? model.getPersonal() : model
				.getFrom();
		helper.setFrom(model.getFrom(), personal);
		helper.setTo(model.getTo());
		if (!ObjectTools.isEmpty(model.getCc())) helper.setCc(model.getCc());
		helper.setText(model.getText(), model.isHtml());
		if (!CollectionTools.isEmpty(model.getAttachs()))
		{
			for (File file : model.getAttachs())
			{
				if (!file.exists())
				{
					logger.warn("The attach is not exist,ingore:{}", file.getAbsolutePath());
					continue;
				}
				String fileName = file.getName();
				fileName = "=?UTF-8?B?" + EncodeTool.encodeBase64UTF8(fileName) + "?=";
				helper.addAttachment(fileName, file);
			}
		}
		sender.send(message);
	}
}
