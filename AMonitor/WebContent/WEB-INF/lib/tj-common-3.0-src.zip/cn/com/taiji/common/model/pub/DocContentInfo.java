package cn.com.taiji.common.model.pub;

import java.io.InputStream;
import java.util.Map;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-9-10 下午02:49:05<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class DocContentInfo extends AbstractContentInfo
{
	/**
	 * 模板中的文本键值对，键为模板中的占位符
	 */
	private Map<String, String> texts;
	/**
	 * 模板中的图片键值对，键为模板中的占位符
	 */
	private Map<String, InputStream> images;

	public DocContentInfo()
	{
		templateUrl = "defaultTemplate.mht";// 模板文件路径
		templateEncoding = "GBK";
	}

	public Map<String, String> getTexts()
	{
		return texts;
	}

	public void setTexts(Map<String, String> texts)
	{
		this.texts = texts;
	}

	public Map<String, InputStream> getImages()
	{
		return images;
	}

	public void setImages(Map<String, InputStream> images)
	{
		this.images = images;
	}

}
