/*
 * Date: 2014年4月1日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年4月1日 下午5:26:24<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link HttpClientHelper#httpRequest(HttpUriRequest, boolean, int, HttpResponseHandler, int, HttpClientInterceptor)}
 */
public interface HttpClientInterceptor
{
	/**
	 * 发送http请求前做些操作，比如增加header等
	 * 
	 * @param clientBuilder
	 * @param request
	 */
	public void process(final HttpClientBuilder clientBuilder, final HttpUriRequest request);
}
