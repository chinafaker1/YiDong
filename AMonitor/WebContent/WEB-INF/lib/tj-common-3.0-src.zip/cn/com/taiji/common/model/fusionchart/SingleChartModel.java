package cn.com.taiji.common.model.fusionchart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SingleChartModel extends AbstractChartModel
{
	private List<ChartData> data;

	public List<ChartData> getData()
	{
		return data;
	}

	public void setData(List<ChartData> data)
	{
		this.data = data;
	}

	public static SingleChartModel newInstance(ChartHead chart, List<ChartData> data)
	{
		SingleChartModel singleChartModel = new SingleChartModel();
		singleChartModel.setChartHead(chart);
		singleChartModel.setData(data);
		return singleChartModel;
	}

	public Map<String, Object> toContentMap(Map<String, Object> map)
	{
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		List<Map<String, String>> lineList = new ArrayList<Map<String, String>>();
		Map<String, Object> trendLinesMap = new HashMap<String, Object>();
		map.put("chart", chartHead.toChartHeadMap());
		for (ChartData vo : data)
		{
			dataList.add(vo.toChartDataMap());
		}
		if (trendLines != null)
		{
			for (ChartLine line : trendLines)
			{
				lineList.add(line.toLineMap());
			}
			trendLinesMap.put("line", lineList);
			map.put("trendlines", trendLinesMap);
		}

		map.put("data", dataList);
		return map;
	}

}
