/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

import java.io.File;
import java.io.InputStream;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 上午9:25:16<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractFileProtocol extends BaseModel
{
	protected String filename;// 协议类型信息尽量设计在名字里面
	protected InputStream binFile;// 二进制文件
	protected File tmpFile;// 根据binFile超出一定大小时使用临时文件进行中转
	protected boolean deleteTmpFile = true;// 是否删除临时文件

	public File getTmpFile()
	{
		return tmpFile;
	}

	public void setTmpFile(File tmpFile)
	{
		this.tmpFile = tmpFile;
	}

	public String getFilename()
	{
		return filename;
	}

	public InputStream getBinFile()
	{
		return binFile;
	}

	public void setFilename(String filename)
	{
		this.filename = filename;
	}

	public void setBinFile(InputStream binFile)
	{
		this.binFile = binFile;
	}

	public boolean isDeleteTmpFile()
	{
		return deleteTmpFile;
	}

	public void setDeleteTmpFile(boolean deleteTmpFile)
	{
		this.deleteTmpFile = deleteTmpFile;
	}

	/**
	 * 判断临时文件是否需要删除
	 * 
	 * @return
	 */
	public boolean needDeleteTmp()
	{
		return deleteTmpFile && tmpFile != null;
	}
}
