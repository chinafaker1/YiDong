package cn.com.taiji.common.pub.file.helper;

import java.io.File;
import java.io.Serializable;
import java.util.Comparator;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-1 上午09:53:52
 * @since 1.0
 * @version 1.0
 */
public class FileTimeComparator implements Comparator<File>, Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7238067321492742457L;
	private boolean desc;

	public FileTimeComparator()
	{
		this.desc = false;
	}

	public FileTimeComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(File o1, File o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null) return desc ? 1 : -1;
		if (o2 == null) return desc ? -1 : 1;
		long o1Time = o1.lastModified();
		long o2Time = o2.lastModified();
		if (o1Time == o2Time) return 0;
		if (desc) return o2Time > o1Time ? 1 : -1;
		return o1Time > o2Time ? 1 : -1;
	}
}
