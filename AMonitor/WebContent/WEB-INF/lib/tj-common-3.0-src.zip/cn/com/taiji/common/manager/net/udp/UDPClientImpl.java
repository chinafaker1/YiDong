package cn.com.taiji.common.manager.net.udp;

import java.io.IOException;

import javax.annotation.PreDestroy;

import org.xsocket.datagram.IConnectedEndpoint;
import org.xsocket.datagram.UserDatagram;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.net.ClientFactory;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 上午09:57:24
 * @since 1.0
 * @version 1.0
 */
public class UDPClientImpl extends AbstractManager implements UDPClient
{
	public void send(UserDatagram datagram) throws IOException
	{
		try
		{
			IConnectedEndpoint client = ClientFactory.getUDPClient(datagram.getRemoteAddress()
					.getHostName(), datagram.getRemotePort());
			client.send(datagram);
		}
		catch (IOException e)
		{
			ClientFactory.removeUDPClient(datagram.getRemoteAddress().getHostName(),
					datagram.getRemotePort());
			throw e;
		}
	}

	@PreDestroy
	public void stop()
	{
		ClientFactory.stopUDPClients();
	}

}
