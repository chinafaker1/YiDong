package cn.com.taiji.common.model.net.snmp;

import java.util.List;

import org.snmp4j.PDU;
import org.snmp4j.PDUv1;
import org.snmp4j.ScopedPDU;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:05:53
 * @since 1.0
 * @version 1.0
 */
public class AlertTrap extends BaseModel implements V1Trap, V2Trap, V3Trap
{

	private String oid = "1.3.6.1.3.94";

	private List<String> alerts;

	public AlertTrap()
	{

	}

	public AlertTrap(List<String> alerts)
	{
		this.alerts = alerts;
	}

	public AlertTrap(String oid, List<String> alerts)
	{
		this.oid = oid;
		this.alerts = alerts;
	}

	public List<String> getAlerts()
	{
		return alerts;
	}

	public void setAlerts(List<String> alerts)
	{
		this.alerts = alerts;
	}

	public String getOid()
	{
		return oid;
	}

	public void setOid(String oid)
	{
		this.oid = oid;
	}

	public PDU getV2cTrap()
	{
		if (getAlerts() == null) throw new RuntimeException("欲发送的报警数据不能为空.");
		PDU request = new PDU();
		request.setType(PDU.TRAP);
		OID oid = new OID(getOid());
		for (String str : getAlerts())
			request.add(new VariableBinding(oid, new OctetString(str)));
		return request;
	}

	public ScopedPDU getV3Trap()
	{
		if (getAlerts() == null) throw new RuntimeException("欲发送的报警数据不能为空.");
		ScopedPDU request = new ScopedPDU();
		request.setType(ScopedPDU.TRAP);
		OID oid = new OID(getOid());
		for (String str : getAlerts())
			request.add(new VariableBinding(oid, new OctetString(str)));
		return request;
	}

	public PDUv1 getV1Trap()
	{
		if (getAlerts() == null) throw new RuntimeException("欲发送的报警数据不能为空.");
		PDUv1 request = new PDUv1();
		request.setType(PDUv1.V1TRAP);
		OID oid = new OID(getOid());
		for (String str : getAlerts())
			request.add(new VariableBinding(oid, new OctetString(str)));
		return request;
	}

}
