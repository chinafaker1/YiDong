/*
 * Date: 2011-9-1
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub;

import org.springframework.util.TypeUtils;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-9-1 下午2:49:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class TypeTools extends TypeUtils
{

}
