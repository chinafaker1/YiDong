/*
 * Date: 2015年8月13日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net;

import java.util.concurrent.atomic.AtomicBoolean;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.finals.SysFinals;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年8月13日 下午6:08:38<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractClientService extends AbstractManager implements ClientService
{
	protected static final String ISO8859 = "ISO8859-1";
	protected static final boolean enableDebug = false;
	protected static final int DEFAULT_CONNECT_TIMEOUT = 30000;
	protected static final int DEFAULT_SO_TIMEOUT = 30000;
	protected static final int BUFFERED_SIZE = 8192;

	protected String server;
	protected int port = 21;
	protected int connTimeout = DEFAULT_CONNECT_TIMEOUT;
	protected int soTimeout = DEFAULT_SO_TIMEOUT;
	protected String username;
	protected String password;
	protected String encoding = "UTF-8";
	
	protected AtomicBoolean running = new AtomicBoolean(false);

	public String getServer()
	{
		return server;
	}

	public int getPort()
	{
		return port;
	}

	public String getUsername()
	{
		return username;
	}

	public String getPassword()
	{
		return password;
	}

	public String getEncoding()
	{
		return encoding;
	}

	public int getConnTimeout()
	{
		return connTimeout;
	}

	public void setConnTimeout(int connTimeout)
	{
		this.connTimeout = connTimeout;
	}

	@Override
	public void setSoTimeout(int soTimeout)
	{
		this.soTimeout = soTimeout;
	}

	@Override
	public int getSoTimeout()
	{
		return soTimeout;
	}
	
	public boolean isRunning()
	{
		return running.get();
	}
	
	public String getPartSuffix()
	{
		return SysFinals.PART_FILE_SUFFIX;
	}
}
