package cn.com.taiji.common.model;

import java.util.UUID;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2015年4月13日 下午2:09:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class StringUUIDModel extends BaseModel
{
	protected String id;

	public String getId()
	{
		if (id == null) id = UUID.randomUUID().toString().replace("-", "");
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

}
