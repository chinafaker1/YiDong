package cn.com.taiji.common.pub;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;
import org.springframework.util.FileCopyUtils;

/**
 * Base64编解码工具
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-3 上午10:21:13
 * @since 1.0
 * @version 1.0
 */
public class EncodeTool
{
	public static String encodeBase64(InputStream in) throws IOException
	{
		return encodeBase64(in, false);
	}

	public static String encodeBase64Chunked(InputStream in) throws IOException
	{
		return encodeBase64(in, true);
	}

	public static String encodeBase64(InputStream in, boolean chunked) throws IOException
	{
		AssertUtil.notNull(in, "the inputStream can not be null.");
		byte[] data = FileCopyUtils.copyToByteArray(in);
		return new String(Base64.encodeBase64(data, chunked), "ISO8859-1");
	}

	public static String encodeBase64(File file) throws IOException
	{
		return encodeBase64(new FileInputStream(file));
	}

	/**
	 * 将原字符集是UTF-8的字符串编码成Base64字符串，将中文传递变成ascii码传递。
	 * 
	 * @param str
	 *            需要编码的字符串
	 * @return 编码后的字符串
	 * @see {@link #decodeBase64(String)} {@link String#String(byte[], String)}
	 */
	public static String encodeBase64UTF8(String str)
	{
		return encodeBase64(str, "UTF-8");
	}

	/**
	 * 将原字符集是GBK的字符串编码成Base64字符串，将中文传递变成ascii码传递。
	 * 
	 * @param str
	 *            需要编码的字符串
	 * @return 编码后的字符串
	 * @see {@link #decodeBase64(String)} {@link String#String(byte[], String)}
	 */
	public static String encodeBase64GBK(String str)
	{
		return encodeBase64(str, "GBK");
	}

	public static String encodeBase64(String str, String charset)
	{
		return encodeBase64(str, charset, false);
	}

	/**
	 * 将字符串编码成Base64字符串，一般用于处理中文传递问题
	 * 
	 * @param str
	 *            需要编码的字符串
	 * @param charset
	 *            字符串本身的字符集
	 * @return 编码后的字符串（ISO8859-1）
	 * @see {@link #decodeBase64(String)}
	 */
	public static String encodeBase64(String str, String charset, boolean chunked)
	{
		AssertUtil.hasText(str, "param must has text");
		try
		{
			byte[] data = str.getBytes(charset);
			return new String(Base64.encodeBase64(data, chunked), "ISO8859-1");
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * 对二进制数据进行base64编码
	 * 
	 * @param data
	 *            待编码的二进制数据
	 * @param chunked
	 * @return 编码后的二进制数据
	 */
	public static byte[] encodeBase64(byte[] data, boolean chunked)
	{
		return Base64.encodeBase64(data, chunked);
	}

	/**
	 * 将经过base64编码的字符串解码
	 * 
	 * @param base64Str
	 *            base64字符串（ISO8859-1格式）
	 * @return 解码后的byte数组
	 */
	public static byte[] decodeBase64(String base64Str)
	{
		try
		{
			return Base64.decodeBase64(base64Str.getBytes("ISO8859-1"));
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}
}
