package cn.com.taiji.common.manager.pub;

import java.io.File;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

import org.dbunit.DatabaseUnitException;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.ForwardOnlyResultSetTableFactory;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.CachedDataSet;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.datatype.IDataTypeFactory;
import org.dbunit.dataset.stream.IDataSetProducer;
import org.dbunit.dataset.xml.XmlProducer;
import org.dbunit.operation.DatabaseOperation;
import org.xml.sax.InputSource;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.pub.MyFile;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.file.FileSuffixFilter;


/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-7-24 下午03:54:12
 * @since 1.0
 * @version 1.0
 */
public class InitDBManagerImpl extends AbstractManager implements InitDBManager
{
	/**
	 * Database connection
	 */
	private Connection conn = null;

	/**
	 * DB driver.
	 */
	private String driver = null;

	/**
	 * DB url.
	 */
	private String url = null;

	/**
	 * User name.
	 */
	private String userId = null;

	/**
	 * Password
	 */
	private String password = null;

	private String schema = null;

	/**
	 * Flag for using the qualified table names.
	 */
	private boolean useQualifiedTableNames = false;

	/**
	 * Flag for using batched statements.
	 */
	private boolean supportBatchStatement = false;

	/**
	 * Flag for datatype warning.
	 */
	private boolean datatypeWarning = true;

	// protected String escapePattern = null;

	private String dataTypeFactory = "org.dbunit.dataset.datatype.DefaultDataTypeFactory";

	public synchronized void initByFile(String fileName) throws ManagerException
	{
		File src = new File(fileName);
		try
		{
			IDataSet dataSet = getSrcDataSet(src);
			IDatabaseConnection connection = createConnection();
			DatabaseOperation.CLEAN_INSERT.execute(connection, dataSet);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new ManagerException(e.getMessage(), e);
		}
		finally
		{
			try
			{
				if (conn != null) conn.close();
			}
			catch (SQLException e)
			{
			}
		}
	}

	public synchronized void initByPath(String path) throws ManagerException
	{
		try
		{
			List<MyFile> list = FileHelper.getFiles(path, new FileSuffixFilter(".xml"));
			IDatabaseConnection connection = createConnection();
			for (MyFile file : list)
			{
				File src = new File(file.getPath());
				IDataSet dataSet = getSrcDataSet(src);
				DatabaseOperation.CLEAN_INSERT.execute(connection, dataSet);
			}
			logger.info("Init DB success.^_^");
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new ManagerException(e.getMessage(), e);
		}
		finally
		{
			try
			{
				if (conn != null) conn.close();
			}
			catch (SQLException e)
			{
			}
		}

	}

	private IDatabaseConnection createConnection() throws SQLException, DatabaseUnitException
	{
		AssertUtil.notNull(driver, "Driver attribute must be set!");
		AssertUtil.notNull(userId, "User Id attribute must be set!");
		AssertUtil.notNull(password, "Password attribute must be set!");
		AssertUtil.notNull(url, "Url attribute must be set!");

		// Instanciate JDBC driver
		Driver driverInstance = null;
		try
		{
			Class<?> dc = Class.forName(driver);
			driverInstance = (Driver) dc.newInstance();
		}
		catch (ClassNotFoundException e)
		{
			throw new RuntimeException("Class Not Found: JDBC driver " + driver + " could not be loaded", e);
		}
		catch (IllegalAccessException e)
		{
			throw new RuntimeException("Illegal Access: JDBC driver " + driver + " could not be loaded", e);
		}
		catch (InstantiationException e)
		{
			throw new RuntimeException("Instantiation Exception: JDBC driver " + driver + " could not be loaded", e);
		}
		Properties info = new Properties();
		info.put("user", userId);
		info.put("password", password);
		conn = driverInstance.connect(url, info);
		if (conn == null)
		{
			// Driver doesn't understand the URL
			throw new SQLException("No suitable Driver for " + url);
		}
		conn.setAutoCommit(true);

		IDatabaseConnection connection = new DatabaseConnection(conn, schema);
		DatabaseConfig config = connection.getConfig();
		config.setProperty(DatabaseConfig.FEATURE_BATCHED_STATEMENTS, supportBatchStatement);
		config.setProperty(DatabaseConfig.FEATURE_QUALIFIED_TABLE_NAMES, useQualifiedTableNames);
		config.setProperty(DatabaseConfig.FEATURE_DATATYPE_WARNING, datatypeWarning);
		config.setProperty(DatabaseConfig.PROPERTY_ESCAPE_PATTERN, null);
		config.setProperty(DatabaseConfig.PROPERTY_RESULTSET_TABLE_FACTORY, new ForwardOnlyResultSetTableFactory());

		// Setup data type factory
		try
		{
			IDataTypeFactory dataTypeFactory = (IDataTypeFactory) Class.forName(this.dataTypeFactory).newInstance();
			config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, dataTypeFactory);
		}
		catch (ClassNotFoundException e)
		{
			throw new RuntimeException("Class Not Found: DataType factory " + driver + " could not be loaded", e);
		}
		catch (IllegalAccessException e)
		{
			throw new RuntimeException("Illegal Access: DataType factory " + driver + " could not be loaded", e);
		}
		catch (InstantiationException e)
		{
			throw new RuntimeException("Instantiation Exception: DataType factory " + driver + " could not be loaded",
					e);
		}

		return connection;
	}

	protected IDataSet getSrcDataSet(File src) throws MalformedURLException, DataSetException
	{
		logger.info("File path = " + src.getAbsolutePath());
		IDataSetProducer producer = new XmlProducer(new InputSource(src.toURI().toURL().toString()));
		return new CachedDataSet(producer);
	}

	public void setDriver(String driver)
	{
		this.driver = driver;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public void setSchema(String schema)
	{
		this.schema = schema;
	}

}
