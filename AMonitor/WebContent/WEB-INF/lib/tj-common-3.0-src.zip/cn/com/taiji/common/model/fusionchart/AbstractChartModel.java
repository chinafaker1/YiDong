package cn.com.taiji.common.model.fusionchart;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.json.JsonTools;

public abstract class AbstractChartModel extends BaseModel
{
	protected ChartHead chartHead;

	public ChartHead getChartHead()
	{
		return chartHead;
	}

	public List<ChartLine> getTrendLines()
	{
		return trendLines;
	}

	public void setTrendLines(List<ChartLine> trendLines)
	{
		this.trendLines = trendLines;
	}

	public void setChartHead(ChartHead chartHead)
	{
		this.chartHead = chartHead;
	}

	protected List<ChartLine> trendLines;

	// public abstract AbstractChartModel fillMonthReportData(ReportWordContext reportWordContext,
	// Calendar countTime);
	//
	// public abstract AbstractChartModel fillQuaterReportData(ReportWordContext reportWordContext,
	// Calendar countTime);

	protected abstract Map<String, Object> toContentMap(Map<String, Object> map);

	public final String toChartJson() throws IOException
	{
		Map<String, Object> map = new HashMap<String, Object>();
		toContentMap(map);
		return JsonTools.toJsonStr(map);
	}
}
