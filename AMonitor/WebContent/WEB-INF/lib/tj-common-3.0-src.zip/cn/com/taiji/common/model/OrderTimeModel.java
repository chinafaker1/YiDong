package cn.com.taiji.common.model;

import cn.com.taiji.common.pub.StringTools;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-13 下午05:56:32
 * @since 1.0
 * @version 1.0
 */
public class OrderTimeModel extends TimeModel
{
	protected String orderBy;// 排序的字段
	protected boolean desc;// 是否逆序

	public String getOrderBy()
	{
		return orderBy;
	}

	public void setOrderBy(String orderBy)
	{
		this.orderBy = orderBy;
	}

	public boolean isDesc()
	{
		return desc;
	}

	public void setDesc(boolean desc)
	{
		this.desc = desc;
	}

	public String toOrderSql()
	{
		if (!StringTools.hasText(orderBy)) return null;
		return desc ? " order by " + orderBy + " desc" : " order by " + orderBy + " asc";
	}

}
