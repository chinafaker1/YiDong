/*
 * Date: 2015年4月10日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月10日 下午4:11:37<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractHttpJsonCommHandleManager extends AbstractCommHandleManager implements
		HttpJsonCommHandleManager
{

	@Override
	public final JsonProtocol handleComm(JsonProtocol protocol, HttpServletRequest request) throws IOException
	{
		checkProtocol(protocol);
		return handleRequest(protocol, request);
	}

	protected abstract JsonProtocol handleRequest(JsonProtocol protocol, HttpServletRequest request) throws IOException;
}
