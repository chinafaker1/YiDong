package cn.com.taiji.common.pub.video;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.ScriptTool;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.SystemTools;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-2 下午01:33:27
 * @since 1.0
 * @version 1.0
 */
public class VideoConvertHelper
{
	public static File generateGif(File src, int startTime, VideoRatio ratio, int frames, String savePath)
	{
		String destPath = getPicDestPath(".gif", src, savePath);
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		if (SystemTools.IS_OS_WINDOWS) command.add(FileHelper.getToolPath() + "/flv/ffmpeg");
		else command.add("ffmpeg");
		command.add("-i");// 输入文件
		command.add(src.getAbsolutePath());
		command.add("-ss");// 从指定时间点开始转换任务,秒
		command.add("" + startTime);
		command.add("-f");//
		command.add("gif");
		command.add("-pix_fmt");//
		command.add("rgb24");
		if (ratio != null && ratio != VideoRatio.AS_SRC)
		{
			command.add("-s");// -s 指定分辨率大小,默认与源相同
			command.add(ratio.getValue());
		}
		command.add("-vframes");// 帧数
		command.add("" + frames);
		command.add("-y");// 输出文件
		command.add(destPath);
		pb.command(command);
		boolean rs = ScriptTool.processCommand(pb, null, null, null);
		if (!rs) throw new RuntimeException("Execute ffmpeg gif failed.");
		return new File(destPath);
	}

	/**
	 * 
	 * @param src
	 * @param startTime
	 * @param ratio
	 * @param savePath
	 * @return
	 */
	public static File generatePic(File src, int startTime, VideoRatio ratio, String savePath)
	{
		return ffmpegPic(src, startTime, ratio, getPicDestPath(".png", src, savePath));
	}

	private static String getPicDestPath(String suffix, File src, String savePath)
	{
		checkFile(src);
		String name = src.getName();
		if (!name.contains(".")) throw new RuntimeException("Can not decide the file type:" + src.getAbsolutePath());
		String strType = name.substring(name.lastIndexOf(".") + 1, name.length()).toLowerCase();
		VideoPara.Type type = VideoPara.Type.getInstance(strType);
		if (!VideoPara.Type.isFfmpegSupport(type)) throw new RuntimeException("Can not support this type:" + strType);
		name = name.substring(0, name.lastIndexOf("."));
		String srcPath = src.getAbsolutePath();
		srcPath = srcPath.substring(0, srcPath.lastIndexOf("."));
		String destPath = StringTools.hasText(savePath) ? savePath + "/" + name + suffix : srcPath + suffix;
		return destPath;
	}

	public static File convert(File src, VideoPara para, String savePath)
	{
		return convert(src, para, savePath, true);
	}

	/**
	 * 视频转换
	 * 
	 * @param src
	 *            源文件
	 * @param para
	 *            参数，详见注释
	 * @param savePath
	 *            转换后文件的保存路径,为空时存放于源文件所在的目录
	 * @param enableMencoder
	 *            是否启用mencoder转换，新的ffmpeg已经支持rmvb等格式
	 * @return
	 */
	public static File convert(File src, VideoPara para, String savePath, boolean enableMencoder)
	{
		checkPara(src, para);
		String name = src.getName();
		if (!name.contains(".")) throw new RuntimeException("Can not decide the file type:" + src.getAbsolutePath());
		String strType = name.substring(name.lastIndexOf(".") + 1, name.length()).toLowerCase();
		VideoPara.Type type = VideoPara.Type.getInstance(strType);
		if (!VideoPara.Type.isSupport(type)) throw new RuntimeException("Can not support this type:" + strType);
		String myType = (para.getDestType() == null) ? VideoPara.Type.FLV.getValue() : para.getDestType().getValue();
		String destPath = StringTools.hasText(savePath) ? savePath + "/" + name + "." + myType : src.getAbsolutePath()
				+ "." + myType;
		File aviFile = null;
		if (enableMencoder && !VideoPara.Type.isFfmpegSupport(type))
		{
			String aviPath = StringTools.hasText(savePath) ? savePath + "/" + name + "_tmp.avi" : src.getAbsolutePath()
					+ "_tmp.avi";
			aviFile = mencoderConvert(src, para, aviPath);
		}
		File mySrc = aviFile == null ? src : aviFile;
		return ffmpegConvert(mySrc, para, destPath);
	}

	private static File ffmpegPic(File src, int startTime, VideoRatio ratio, String destPath)
	{
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		if (SystemTools.IS_OS_WINDOWS) command.add(FileHelper.getToolPath() + "/flv/ffmpeg");
		else command.add("ffmpeg");
		command.add("-i");// 输入文件
		command.add(src.getAbsolutePath());
		command.add("-ss");// 从指定时间点开始转换任务,秒
		command.add("" + startTime);
		command.add("-f");//
		command.add("image2");
		if (ratio != null && ratio != VideoRatio.AS_SRC)
		{
			command.add("-s");// -s 指定分辨率大小,默认与源相同
			command.add(ratio.getValue());
		}
		command.add("-vframes");// 帧数
		command.add("1");
		command.add("-y");// 输出文件
		command.add(destPath);
		pb.command(command);
		boolean rs = ScriptTool.processCommand(pb, null, null, null);
		if (!rs) throw new RuntimeException("Execute ffmpeg pic failed.");
		return new File(destPath);
	}

	private static File ffmpegConvert(File src, VideoPara para, String destPath)
	{
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		if (SystemTools.IS_OS_WINDOWS) command.add(FileHelper.getToolPath() + "/flv/ffmpeg");
		else command.add("ffmpeg");
		command.add("-i");// 输入文件
		command.add(src.getAbsolutePath());
		command.add("-ac");// -ac设定声道数：1为单声道，2为立体声
		command.add("2");
		command.add("-ab");// -ab设定声音比特率(-ac设为立体声时要以一半比特率来设置，比如192kbps的就设成96)
		command.add(para.getAudioBitrate() + "k");
		command.add("-ar");// -ar设定声音采样率(8000，11025，22050) psp 24000
		command.add("22050");
		command.add("-acodec");// acodec 设定声音编码
		// linux升级ffmpeg后两者相同
		command.add(para.getAcodec());
		// if (SystemTools.IS_OS_WINDOWS)
		// command.add("libmp3lame");
		// else
		// command.add("mp3");
		if (para.getVol() != null)
		{
			command.add("-vol");// <百分比> 设定音量 ex:-vol 200
			command.add("" + para.getVol());
		}
		// 视频参数
		command.add("-r");// -r帧速率 非标准数值会导致音画不同步 标准值为15或29.97
		command.add("29.97");
		command.add("-b:v");// -b:v指定压缩比特率(手机一般支持较低比特率，A1200<280k以下>)
		command.add(para.getBitrate() + "k");
		if (para.getRatio() != null && para.getRatio() != VideoRatio.AS_SRC)
		{
			command.add("-s");// -s 指定分辨率大小,默认与源相同
			command.add(para.getRatio().getValue());
		}
		if (para.isEnableSameq())
		{
			command.add("-sameq");
		}
		// 高级参数
		if (para.getStartTime() != null)
		{
			command.add("-ss");// 从指定时间点开始转换任务,秒
			command.add("" + para.getStartTime());
		}
		if (para.getDuration() != null)
		{
			command.add("-t");// 持续时间
			command.add("" + para.getDuration());//
		}
		command.add("-y");// 输出文件
		command.add(destPath);
		pb.command(command);
		boolean rs = ScriptTool.processCommand(pb, null, null, null);
		if (!rs) throw new RuntimeException("Execute ffmpeg convert failed.");
		return new File(destPath);
	}

	private static File mencoderConvert(File src, VideoPara para, String aviPath)
	{
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		if (SystemTools.IS_OS_WINDOWS) command.add(FileHelper.getToolPath() + "/flv/mencoder");
		else command.add("mencoder");
		command.add(src.getAbsolutePath());// 源文件
		command.add("-of");// 目标格式
		command.add("avi");
		command.add("-oac");// 音频设定
		command.add("mp3lame");
		command.add("-lameopts");
		command.add("preset=" + para.getAudioBitrate());
		command.add("-ovc");// 视频设定
		command.add("xvid");
		command.add("-xvidencopts");
		command.add("bitrate=" + para.getBitrate());
		command.add("-o");// 输出文件
		command.add(aviPath);
		pb.command(command);
		boolean rs = ScriptTool.processCommand(pb, null, null, null);
		if (!rs) throw new RuntimeException("Execute mencoder convert failed.");
		return new File(aviPath);
	}

	private static void checkPara(File file, VideoPara para)
	{
		AssertUtil.notNull(para, "para can not be null");
		if (!(SystemTools.IS_OS_WINDOWS || SystemTools.IS_OS_LINUX))
			throw new RuntimeException("Can not support this os:" + SystemTools.OS_NAME);
		if (para.getBitrate() < 20 || para.getAudioBitrate() < 20)
			throw new IllegalArgumentException("bitrate(A,V) must bigger than 20.");
		checkFile(file);
	}

	private static void checkFile(File file)
	{
		if (file == null) throw new IllegalArgumentException("file can not be null.");
		if (!file.exists() || file.isDirectory())
			throw new IllegalArgumentException("file not exist :" + file.getAbsolutePath());
	}
}
