package cn.com.taiji.common.pub.handler;

import java.io.OutputStream;

/**
 * 操作执行脚本后的输入流
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-1 上午10:48:15
 * @since 1.0
 * @version 1.0
 */
public interface ScriptOutputHandler
{
	/**
	 * 操作执行脚本后的输入流
	 * 
	 * @param output
	 */
	public void handle(final OutputStream output);
}
