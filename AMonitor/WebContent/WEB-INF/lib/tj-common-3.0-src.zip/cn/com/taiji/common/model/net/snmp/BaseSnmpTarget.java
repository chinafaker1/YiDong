package cn.com.taiji.common.model.net.snmp;

import org.snmp4j.CommunityTarget;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;

import cn.com.taiji.common.model.net.BaseTarget;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:19:51
 * @since 1.0
 * @version 1.0
 */
public class BaseSnmpTarget extends BaseTarget
{
	protected String communityString = "public";

	protected int version = SnmpConstants.version2c;

	protected long timeOut = 1000;

	public String getCommunityString()
	{
		return communityString;
	}

	public void setCommunityString(String communityString)
	{
		this.communityString = communityString;
	}

	public int getVersion()
	{
		return version;
	}

	public void setVersion(int version)
	{
		this.version = version;
	}

	public CommunityTarget getCommunityTarget()
	{
		CommunityTarget target = new CommunityTarget();
		target.setCommunity(new OctetString(getCommunityString()));
		target.setVersion(getVersion());
		target.setAddress(new UdpAddress(getIp() + "/" + getPort()));
		target.setRetries(0);
		target.setTimeout(getTimeOut());
		return target;
	}

	public long getTimeOut()
	{
		return timeOut;
	}

	public void setTimeOut(long timeOut)
	{
		this.timeOut = timeOut;
	}

}
