package cn.com.taiji.common.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 上午09:15:05
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class LongAutoIdEntity extends BaseEntity
{
	protected long id;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof LongAutoIdEntity)) return false;
		LongAutoIdEntity other = (LongAutoIdEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}

}
