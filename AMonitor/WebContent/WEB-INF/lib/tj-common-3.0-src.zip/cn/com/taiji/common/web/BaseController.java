package cn.com.taiji.common.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.common.pub.CommonAbstract;
import cn.com.taiji.common.pub.EncodeTool;
import cn.com.taiji.common.pub.MessageTool;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.json.JsonTools;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2008-2-15 上午10:14:51
 * @since 1.0
 * @version 1.1
 * @see {@link HttpMimeResponseHelper}
 */
public abstract class BaseController extends CommonAbstract
{
	protected static final String GBK = "GBK";
	protected static final String UTF8 = "UTF-8";
	protected static final String ISO8859 = "ISO8859-1";

	protected boolean isGET(HttpServletRequest request)
	{
		return request.getMethod().equalsIgnoreCase("GET");
	}

	/**
	 * 另一个方法会根据request判断是否启用gzip压缩
	 * 
	 * @param jsonStr
	 * @param response
	 * @throws IOException
	 * @see {@link #responseJson(String, HttpServletRequest, HttpServletResponse)}
	 */
	protected static final void responseJson(String jsonStr, HttpServletResponse response) throws IOException
	{
		HttpMimeResponseHelper.responseJson(jsonStr, response);
	}

	protected static final void responseJson(String jsonStr, HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		HttpMimeResponseHelper.responseJson(jsonStr, request, response);
	}

	/**
	 * 取得指定代码所对应的国际化信息
	 * 
	 * @param request
	 * @param code
	 *            国际化代码
	 * @param args
	 *            代码中的参数
	 * @return 对应的国际化信息
	 */
	protected final String getMessage(HttpServletRequest request, String code, Object... args)
	{
		return MessageTool.getMessage(request, code, args);
	}

	/**
	 * 将ISO编码的字符串转换成UTF8编码
	 * 
	 * @param str
	 *            iso8859-1编码的字符串
	 * @return utf-8编码的字符串
	 */
	protected final static String iso2UTF8(String str)
	{
		return StringTools.iso2UTF8(str);
	}

	/**
	 * 将base64编码的字符串解码后的字节数组用UTF-8编码转换为字符串
	 * 
	 * @param base64Str
	 *            base64编码后的字符串
	 * @return
	 */
	protected final static String decode2UTF8(String base64Str)
	{
		try
		{
			return new String(EncodeTool.decodeBase64(base64Str), UTF8);
		}
		catch (UnsupportedEncodingException e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * 添加，修改，删除等操作完成成功后，返回页面操作成功的信息 写在父类的原因是，<BR>
	 * manage的jquery插件目前需要使用此固定名称进行处理
	 * 
	 * @param model
	 * @param message
	 *            页面显示的成功信息
	 * @param args
	 *            信息中的占位符参数
	 */
	protected void addSuccess(Model model, String message, Object... args)
	{
		model.addAttribute("taiji_result", "taiji_success");
		model.addAttribute("taiji_message", toLogString(message, args));
	}

	/**
	 * 添加，修改，删除等操作完成成功后，返回页面操作失败的信息 写在父类的原因是，<BR>
	 * manage的jquery插件目前需要使用此固定名称进行处理
	 * 
	 * @param model
	 * @param error
	 *            失败的原因
	 * @param args
	 *            信息中的占位符参数
	 */
	protected void addError(Model model, String error, Object... args)
	{
		model.addAttribute("taiji_result", "taiji_error");
		model.addAttribute("taiji_message", toLogString(error, args));
	}

	protected void addViolation(Model model, ConstraintViolationException cve)
	{
		model.addAttribute("taiji_result", "taiji_violation");
		model.addAttribute("taiji_message", violation2Json(cve));
	}

	protected final String fieldErrors2Json(BindingResult result)
	{
		if (!result.hasFieldErrors()) throw new RuntimeException("没有字段错误");
		try
		{
			Map<String, String> map = new HashMap<String, String>();
			for (FieldError error : result.getFieldErrors())
			{
				String msg = error.getDefaultMessage();
				// logger.debug("bingdingFailure:{}\tmsg:{}\trejectValue:{}", new Object[] {
				// error.isBindingFailure(),
				// msg, error.getRejectedValue() });
				if (error.isBindingFailure()) msg = "数据的类型错误";
				map.put(error.getField(), hasText(msg) ? msg : "数据(" + error.getRejectedValue() + ")错误");
			}
			return JsonTools.toJsonStr(map);
		}
		catch (IOException e)
		{
			logger.error("", e);
			throw new RuntimeException(e.getMessage());
		}
	}

	protected final String violation2Json(ConstraintViolationException cve)
	{
		Set<ConstraintViolation<?>> cvs = cve.getConstraintViolations();
		StringBuilder sb = new StringBuilder("{");
		for (ConstraintViolation<?> cv : cvs)
		{
			sb.append("\"").append(cv.getPropertyPath());
			sb.append("\":\"").append(cv.getMessage()).append("\",");
		}
		if (sb.length() > 1) sb.deleteCharAt(sb.length() - 1);
		sb.append("}");
		return sb.toString();
	}

}
