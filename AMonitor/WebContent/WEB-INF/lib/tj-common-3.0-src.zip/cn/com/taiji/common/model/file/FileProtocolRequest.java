/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 上午11:38:30<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class FileProtocolRequest extends AbstractFileProtocol
{
	/**
	 * 通过http传输时，会将md5写在request的头部
	 * 
	 * @see {@link FileProtocolConstant#MD5_HEADER}
	 */
	private String md5;// 请求者指定md5，未指定则不校验
	/**
	 * 通过http传输时，如果启用gzip，会在header中设置gzip为true
	 * 
	 * @see {@link FileProtocolConstant#GZIP_HEADER}
	 */
	private boolean enableGzip;// 请求者指定gzip
	/**
	 * 通过http传输时，在header中设置鉴权信息
	 * 
	 * @see {@link FileProtocolConstant#AUTH_HEADER}
	 */
	private String authStr;// 鉴权信息

	public String getAuthStr()
	{
		return authStr;
	}

	public void setAuthStr(String authStr)
	{
		this.authStr = authStr;
	}

	public boolean isEnableGzip()
	{
		return enableGzip;
	}

	public void setEnableGzip(boolean enableGzip)
	{
		this.enableGzip = enableGzip;
	}

	public String getMd5()
	{
		return md5;
	}

	public void setMd5(String md5)
	{
		this.md5 = md5;
	}

}
