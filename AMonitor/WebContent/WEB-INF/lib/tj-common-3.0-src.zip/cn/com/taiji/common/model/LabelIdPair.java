package cn.com.taiji.common.model;

import java.util.ArrayList;
import java.util.List;

import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.model.BaseModel;

/**
 * @author TOM
 * 
 */
public class LabelIdPair extends BaseModel
{
	private String label;
	private String id;

	public LabelIdPair()
	{

	}

	public LabelIdPair(String label, String id)
	{
		this.label = label;
		this.id = id;
	}

	public String getLabel()
	{
		return label;
	}

	public void setLabel(String label)
	{
		this.label = label;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public static <E extends BaseEntity> List<LabelIdPair> fromList(List<E> list, String labelPropertyName,
			String idPropertyName)
	{
		List<LabelIdPair> rs = new ArrayList<LabelIdPair>();
		for (E e : list)
		{
			Object id = e.getPropertyValue(Object.class, idPropertyName);
			rs.add(new LabelIdPair(e.getPropertyValue(String.class, labelPropertyName), "" + id));
		}
		return rs;
	}
}
