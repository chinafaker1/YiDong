package cn.com.taiji.common.model.net.snmp;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:31:35
 * @since 1.0
 * @version 1.0
 */
public class SwitchIp extends BaseModel
{
	private String ip;

	private String mac;

	private String ifNum;

	public String getIfNum()
	{
		return ifNum;
	}

	public void setIfNum(String ifNum)
	{
		this.ifNum = ifNum;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getMac()
	{
		return mac;
	}

	public void setMac(String mac)
	{
		this.mac = mac;
	}

}
