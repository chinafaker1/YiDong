package cn.com.taiji.common.manager.pub;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.core.io.Resource;

import cn.com.taiji.common.model.pub.DocContentInfo;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.CollectionTools;
import cn.com.taiji.common.pub.EncodeTool;
import cn.com.taiji.common.pub.FileCopyTools;
import cn.com.taiji.common.pub.GBStringTools;
import cn.com.taiji.common.pub.file.FileTools;

/**
 * 根据word模板（mht格式）生成word文件
 * 
 * @author Peream <br>
 *         Create Time：2009-9-10 下午02:37:27<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class DocTemplateHelper extends AbstractTemplateHelper
{
	/**
	 * 使用模板生成Word文件
	 * 
	 * @param info
	 * @return
	 * @throws IOException
	 */
	public static File generateDoc(DocContentInfo info) throws IOException
	{
		AssertUtil.notNull(info);
		Resource resource = getResource(info);
		String content = FileCopyTools.copyToStr(resource.getInputStream(), info.getTemplateEncoding());
		content = handleTexts(content, info.getTexts());
		content = handleImages(content, info.getImages());
		return FileTools.string2File(getSavePath(info), content, getFileName(info), info.isAlwaysNew());
	}

	private static String handleTexts(String content, Map<String, String> texts)
	{
		if (CollectionTools.isEmpty(texts)) return content;
		String rs = content;
		for (Entry<String, String> entry : texts.entrySet())
		{
			String key = entry.getKey();
			String value = GBStringTools.toDecStr(entry.getValue());
			value = value == null ? "" : value;// fix bug
			rs = rs.replace(key, value);
		}
		return rs;
	}

	private static String handleImages(String content, Map<String, InputStream> images) throws FileNotFoundException,
			IOException
	{
		if (CollectionTools.isEmpty(images)) return content;
		String rs = content;
		for (Entry<String, InputStream> entry : images.entrySet())
		{
			String key = entry.getKey();
			InputStream input = entry.getValue();
			try
			{
				String value = EncodeTool.encodeBase64(input, true);
				rs = rs.replace(key, value);
			}
			finally
			{
				closeQuietly(input);
			}
		}
		return rs;
	}
}
