/*
 * Date: 2013-4-18
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import cn.com.taiji.common.manager.CronTaskRunner;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-4-18 下午4:16:15<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface RunnableProxy extends Runnable
{
	/**
	 * 具体的任务
	 * @return
	 */
	public Runnable getTask();
	
	public CronTaskRunner getTaskRunner();
	
	public void setTaskRunner(CronTaskRunner taskRunner);

	public Object init();

	/**
	 * 任务名称，需要唯一
	 * @return
	 */
	public String getTaskName();

	/**
	 * 任务当前是否在运行
	 * @return
	 */
	public boolean isRunning();
}
