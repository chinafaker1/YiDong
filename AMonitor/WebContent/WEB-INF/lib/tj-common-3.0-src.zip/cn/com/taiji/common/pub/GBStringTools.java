package cn.com.taiji.common.pub;

import net.sourceforge.pinyin4j.PinyinHelper;

/**
 * 汉字拼音处理类
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-9-2 下午03:20:47
 * @since 1.0
 * @version 1.0
 */
public abstract class GBStringTools extends StringTools
{
	// 字母Z使用了两个标签，这里有２７个值
	// i, u, v都不做声母, 跟随前面的字母
	private static char[] chartable = { '啊', '芭', '擦', '搭', '蛾', '发', '噶', '哈', '哈', '击', '喀', '垃',
			'妈', '拿', '哦', '啪', '期', '然', '撒', '塌', '塌', '塌', '挖', '昔', '压', '匝', '座' };
	private static int[] table = new int[27];

	static
	{
		for (int i = 0; i < 27; ++i)
		{
			table[i] = gbValue(chartable[i]);
		}
	}

	public GBStringTools()
	{

	}

	public static int char2Dec(char ch)
	{
		return ch & 0xffff;
	}

	/**
	 * 转换为10进制的字符串。mht等文件的编码方式
	 * 
	 * @param str
	 * @return
	 */
	public static String toDecStr(String str)
	{
		if (!hasText(str)) return str;
		StringBuilder sb = new StringBuilder();
		int length = str.length();
		for (int i = 0; i < length; i++)
		{
			char ch = str.charAt(i);
			if (isAscii(ch))
				sb.append(ch);
			else
				sb.append("&#").append(char2Dec(ch)).append(";");
		}
		return sb.toString();
	}

	public static String char2HexStr(char ch)
	{
		return Integer.toHexString(ch);
	}

	/**
	 * 将字符串转换为16进制的.类似native2Ascii的功能
	 * 
	 * @param str
	 * @return
	 */
	public static String toHexStr(String str)
	{
		if (!hasText(str)) return str;
		StringBuilder sb = new StringBuilder();
		int length = str.length();
		for (int i = 0; i < length; i++)
		{
			char ch = str.charAt(i);
			if (isAscii(ch))
				sb.append(ch);
			else
				sb.append("\\u").append(char2HexStr(ch));
		}
		return sb.toString();
	}

	/**
	 * 利用pinyin4j提高拼音辨认准确率
	 * 
	 * @author Peream (peream@gmail.com)
	 * @param ch
	 *            需要转换的字符
	 * @param fill
	 *            无法转换时填充的字符
	 * @return
	 */
	public static char char2Py(char ch, char fill)
	{
		if (isAscii(ch)) return ch;
		String[] strs = PinyinHelper.toHanyuPinyinStringArray(ch);
		if (ObjectTools.isEmpty(strs)) return fill;
		// 多音字取第一个发音
		if (strs[0].length() > 0) return strs[0].charAt(0);
		return fill;
	}

	/**
	 * 字母和符号返回true
	 * 
	 * @param ch
	 * @return
	 */
	public static boolean isAscii(char ch)
	{
		if (ch >= 'a' && ch <= 'z') return true;
		if ((int) ch >= 33 && (int) ch <= 126) return true;
		return false;
	}

	/**
	 * 根据一个包含汉字的字符串返回一个汉字拼音首字母的字符串 相当于str2PY(String str,'?')
	 * 
	 * @param srcStr
	 *            要转换的中文字符串
	 * @return 拼音首字母
	 */
	public static String str2PY(String srcStr)
	{
		return str2PY(srcStr, '?', true);
	}

	public static String str2PY(String srcStr, char fill)
	{
		return str2PY(srcStr, fill, true);
	}

	/**
	 * 根据一个包含汉字的字符串返回一个汉字拼音首字母的字符串
	 * 
	 * @param srcStr
	 *            要转换的中文字符串
	 * @param fill
	 *            填充字符
	 * @param upper
	 *            是否转换为大写字母
	 * @return 拼音首字母，英文转换为大写，无法处理的用fill填充
	 */
	public static String str2PY(String srcStr, char fill, boolean upper)
	{
		if (!hasText(srcStr)) return "";
		StringBuilder rs = new StringBuilder();
		int StrLength = srcStr.length();
		int i;
		try
		{
			for (i = 0; i < StrLength; i++)
			{
				rs.append(char2Py(srcStr.charAt(i), fill));
			}
		}
		catch (Exception e)
		{
			rs = new StringBuilder();
		}
		if (upper) return rs.toString().toUpperCase();
		return rs.toString();
	}

	/**
	 * <p>
	 * 过程名称：intercept(截取文字的长度)
	 * </p>
	 * <p>
	 * 创建时间：2005-8-16,17:01:27
	 * </p>
	 * <p>
	 * 创建人员：wangkai
	 * </p>
	 * 
	 * @param fromStr
	 *            需要截取的文字
	 * @param maxLen
	 *            截取多长
	 * @param showMore
	 *            是否显示更多的三点
	 * @return 截取后的文字
	 */
	public static String intercept(String fromStr, int maxLen, boolean showMore)
	{
		StringBuilder toStr = new StringBuilder();

		if (maxLen <= 0) return fromStr;
		if (!StringTools.hasText(fromStr)) return "";
		if (maxLen >= chineseLen(fromStr)) return fromStr;
		if (showMore && maxLen > 5) maxLen = maxLen - 3;
		int k = 0;
		try
		{
			for (int i = 0; i < maxLen;)
			{
				char ch = fromStr.charAt(k);
				toStr.append(ch);
				if (gbValue(ch) > 0)
					i = i + 2;
				else
					i++;
				k++;

			}
		}
		catch (Exception e)
		{
		}
		if (showMore && maxLen > 4) toStr.append("...");
		return toStr.toString();
	}

	/**
	 * **********************************************
	 * <p>
	 * 过程名称：ChineseLen(获得当前文字的长度，中文为2个字符)
	 * </p>
	 * <p>
	 * 创建时间：2005-8-16,17:00:51
	 * </p>
	 * <p>
	 * 创建人员：wangkai
	 * </p>
	 * 
	 * @param fromStr
	 * @return
	 ********************************************** 
	 */
	public static int chineseLen(String fromStr)
	{
		if (!hasText(fromStr)) return 0;
		int fromLen = fromStr.length();
		int chineseLen = 0;
		for (int i = 0; i < fromLen; i++)
		{
			if (gbValue(fromStr.charAt(i)) > 0)
			{
				chineseLen = chineseLen + 2;
			}
			else
			{
				chineseLen++;
			}
		}
		return chineseLen;
	}

	/*******
	 * **********************************************
	 * <p>
	 * 过程名称：gbValue(返回GBK的编码)
	 * </p>
	 * <p>
	 * 创建时间：2005-8-16,16:22:52
	 * </p>
	 * <p>
	 * 创建人员：wangkai
	 * </p>
	 * 
	 * @param ch
	 * @return
	 ********************************************** 
	 */
	public static int gbValue(char ch)
	{
		String str = "" + ch;
		try
		{
			byte[] bytes = str.getBytes("GBK");
			if (bytes.length < 2) return 0;
			return (bytes[0] << 8 & 0xff00) + (bytes[1] & 0xff);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public static void main(String[] args)
	{
		String str = "陈培安家%$黄宜婕捷,FELENE吼5吼";
		System.out.println(str2PY("asdf测试:中华人民共和国!"));
		System.out.println(str2PY(str, '_'));
		System.out.println(gbValue('婕'));
		System.out.println(gbValue('击'));
		System.out.println(chineseLen(str));
		System.out.println(intercept(str, 10, true));
		System.out.println(Integer.toHexString('中'));
		System.out.println(Integer.toHexString('C'));
		System.out.println(GBStringTools.char2Dec('中'));
		System.out.println(GBStringTools.char2Dec('C'));
		System.out.println(toHexStr(str));
		System.out.println(toDecStr(str));
		return;
	}
}
