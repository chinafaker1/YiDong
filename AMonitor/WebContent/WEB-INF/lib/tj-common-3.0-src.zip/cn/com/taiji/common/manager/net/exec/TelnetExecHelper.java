package cn.com.taiji.common.manager.net.exec;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.UUID;

import org.apache.commons.net.telnet.TelnetClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.net.ExecResultHandler;
import cn.com.taiji.common.manager.net.ExecStrResultHandler;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.net.TelnetExecTarget;
import cn.com.taiji.common.pub.FileCopyTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-7-27 上午11:07:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class TelnetExecHelper
{
	protected static Logger logger = LoggerFactory.getLogger(TelnetExecHelper.class);

	private static final String LOGIN = "login:";
	private static final String PASSWORD = "Password:";

	public static void execCmd(TelnetExecTarget target, String cmd, ExecResultHandler handler) throws IOException
	{
		execCmd(target, cmd, handler, "UTF-8");
	}

	public static void execCmd(TelnetExecTarget target, String cmd, ExecStrResultHandler handler) throws IOException
	{
		execCmd(target, cmd, handler, "UTF-8");
	}

	/**
	 * 通过telnet执行命令
	 * 
	 * @param target
	 * @param cmd
	 * @param handler
	 * @param rsEncoding
	 *            返回结果的字符编码
	 * @throws IOException
	 */
	public static void execCmd(TelnetExecTarget target, String cmd, ExecResultHandler handler, String rsEncoding)
			throws IOException
	{
		TelnetClient tc = new TelnetClient();
		tc.connect(target.getIp(), target.getPort());
		try
		{
			if (target.getTimeout() > 0)
			{
				tc.setDefaultTimeout(target.getTimeout());
				tc.setSoTimeout(target.getTimeout());
			}
			InputStream in = tc.getInputStream();
			PrintStream out = new PrintStream(tc.getOutputStream());
			String str = FileCopyTools.copyUntil(rsEncoding, in, LOGIN);
			logger.debug(str);
			out.println(target.getUser());
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, PASSWORD);
//			 if (logger.isDebugEnabled()) System.out.println(str);
			out.println(target.getPass());
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, target.getTag());
			// if (logger.isDebugEnabled()) System.out.println(str);
			out.println(cmd);
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, target.getTag());
			str = handleStr(str);
			// if (logger.isDebugEnabled()) System.out.println(str);
			String uid = UUID.randomUUID().toString();
			File file = new File(FileHelper.getTmpPath() + "/telnetRs-" + uid + ".txt");
			FileWriter writer = new FileWriter(file);
			FileCopyUtils.copy(str, writer);
			out.close();
			if (handler != null) handler.handle(file);
		}
		finally
		{
			tc.disconnect();
		}
	}

	/**
	 * 通过telnet执行命令
	 * 
	 * @param target
	 * @param cmd
	 * @param handler
	 * @param rsEncoding
	 *            返回结果的字符编码
	 * @throws IOException
	 */
	public static void execCmd(TelnetExecTarget target, String cmd, ExecStrResultHandler handler, String rsEncoding)
			throws IOException
	{
		TelnetClient tc = new TelnetClient();
		tc.connect(target.getIp(), target.getPort());
		try
		{
			if (target.getTimeout() > 0)
			{
				tc.setDefaultTimeout(target.getTimeout());
				tc.setSoTimeout(target.getTimeout());
			}
			InputStream in = tc.getInputStream();
			PrintStream out = new PrintStream(tc.getOutputStream());
			String str = FileCopyTools.copyUntil(rsEncoding, in, LOGIN);
			// if (logger.isDebugEnabled()) logger.debug(str);
			out.println(target.getUser());
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, PASSWORD);
			// if (logger.isDebugEnabled()) System.out.println(str);
			out.println(target.getPass());
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, target.getTag());
			// if (logger.isDebugEnabled()) System.out.println(str);
			out.println(cmd);
			out.flush();
			str = FileCopyTools.copyUntil(rsEncoding, in, target.getTag());
			str = handleStr(str);
			// if (logger.isDebugEnabled()) System.out.println(str);
			out.close();
			if (handler != null) handler.handle(str);
		}
		finally
		{
			tc.disconnect();
		}
	}

	private static String handleStr(String str)
	{
		int beginIndex = str.indexOf("\n");
		int endIndex = str.lastIndexOf("\n");
		logger.debug(beginIndex + "\t" + endIndex);
		if (beginIndex < 0 || endIndex < 0) return str;
		if (beginIndex == endIndex) return str.substring(0, beginIndex);
		return str.substring(beginIndex + 1, endIndex);
	}
}
