package cn.com.taiji.common.pub.file.helper;

import java.io.File;
import java.io.Serializable;
import java.util.Comparator;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-1 上午10:06:06
 * @since 1.0
 * @version 1.0
 */
public class FileSizeComparator implements Comparator<File>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3274163042473709379L;
	private boolean desc;

	public FileSizeComparator()
	{
		this.desc = false;
	}

	public FileSizeComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(File o1, File o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null) return desc ? 1 : -1;
		if (o2 == null) return desc ? -1 : 1;
		long o1Size = o1.length();
		long o2Size = o2.length();
		if (desc) return o2Size > o1Size ? 1 : -1;
		return o1Size > o2Size ? 1 : -1;
	}
}
