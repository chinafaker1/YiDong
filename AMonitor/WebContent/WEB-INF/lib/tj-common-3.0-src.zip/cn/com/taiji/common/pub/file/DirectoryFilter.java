package cn.com.taiji.common.pub.file;

import java.io.File;
import java.io.FileFilter;

/**
 * 
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-26 下午06:44:11
 * @since 1.0
 * @version 1.0
 */
public class DirectoryFilter implements FileFilter
{
	private static DirectoryFilter instance;

	public static DirectoryFilter getInstance()
	{
		if (instance == null) instance = new DirectoryFilter();
		return instance;
	}

	public boolean accept(File pathname)
	{
		if (pathname.isDirectory()) return true;
		return false;
	}

}
