/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.net.http.AbstractFileCommManager;
import cn.com.taiji.common.manager.net.http.FileCommHelper;
import cn.com.taiji.common.manager.net.http.HttpFileCommHandleManager;
import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.common.model.file.FileProtocolConstant;
import cn.com.taiji.common.model.file.FileProtocolResponse;
import cn.com.taiji.common.model.file.HttpFileProtocolModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午3:52:01<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link HttpFileCommHandleManager} {@link FileCommHelper} {@link AbstractFileCommManager}
 */
public abstract class BaseFileCommController extends BaseController
{

	protected final void handleFileComm(HttpFileProtocolModel model, HttpFileCommHandleManager handleManager,
			HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		FileProtocolResponse rs = handleManager.handleComm(model.toFileProtocolRequest(), request, response);
		int sc = rs.getStatusCode();
		if (sc >= FileProtocolResponse.MIN_ERROR_CODE)
		{
			response.setContentType("text/plain");
			response.setStatus(sc);
			response.getWriter().println(rs.getErrorMsg());
			return;
		}
		try
		{
			// header中指定启用gzip时，响应使用gzip进行输出（客户端需要支持gzip响应为前提）
			String gzip = request.getHeader(FileProtocolConstant.GZIP_HEADER.getValue());
			boolean enableGzip = "true".equalsIgnoreCase(gzip) ? true : false;
			HttpMimeResponseHelper.doDownLoad(request, response, rs.getBinFile(), rs.getFilename(), enableGzip);
		}
		finally
		{
			File file = rs.getTmpFile();
			if (rs.needDeleteTmp() && !file.delete())
				logger.error("delete FileProtocolResponse file error:{}", file.getAbsolutePath());
		}
	}
}
