package cn.com.taiji.common.model.finals;


/**
 * 
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-11-26 上午11:03:54
 * @since 1.0
 * @version 1.1
 */
public abstract class SessionNames
{
	// 登录用户
	public static final String LOGIN_USER = "loginUser";

	// 用户名字
	public static final String LOGIN_ROLE = "loginRole";

	// 用户登录IP
	public static final String LOGIN_IP = "loginIp";

	// 用户登录时间
	public static final String LOGIN_TIME = "loginTime";

	public static final String LOGIN_ERROR = "loginError";

	public static final String NORIGHT_ERROR = "norightError";

	/**
	 * 最后一次请求的URI
	 * 
	 * @since 1.1
	 */
	public static final String LAST_URI = "lastURI";

}
