package cn.com.taiji.common.manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-10-23 下午01:47:09<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link CronTaskRunner}
 */
public abstract class AbstractThreadManager<E extends Exception> extends AbstractManager implements
		Runnable, LifecycleService
{
	private AtomicBoolean running = new AtomicBoolean(false);
	private AtomicBoolean stop = new AtomicBoolean(false);
	private ExecutorService executor;

	private final String name;

	protected AbstractThreadManager()
	{
		this("Unknown");
	}

	protected AbstractThreadManager(String name)
	{
		this.name = name;
	}

	/**
	 * 
	 * @throws E
	 *             抛出该异常后将停止线程
	 */
	protected abstract void runTask() throws E;

	public final void run()
	{
		stop.set(false);
		while (!stop.get())
		{
			try
			{
				runTask();
			}
			catch (RuntimeException e)
			{
				logger.error(e.getMessage(), e);
			}
			catch (Exception e)
			{
				stop.set(true);
				running.set(false);
				logger.info("Catch the exception to stop the {} thread :{}", name, e.getMessage());
			}
		}
	}

	public boolean isRunning()
	{
		return running.get();
	}

	@PostConstruct
	public final synchronized void start() throws Exception
	{
		if (running.get())
		{
			logger.info("{} thread is already running.", name);
			return;
		}
		beforeStartThread();// 线程开始前执行的任务
		stop.set(false);
		executor = Executors.newSingleThreadExecutor();
		executor.execute(this);
		running.set(true);
		Thread.yield();
		logger.info("Start {} thread success.", name);
	}

	/**
	 * 线程开启前执行的任务
	 */
	protected abstract void beforeStartThread();

	@PreDestroy
	public final synchronized void stop()
	{
		if (!running.get())
		{
			logger.info("{} thread is NOT running.", name);
			return;
		}
		try
		{
			stop.set(true);
			if (executor != null) executor.shutdownNow();
			afterStopThread();
			logger.info("Stop {} thread success.", name);
		}
		finally
		{
			running.set(false);
			executor = null;
		}
	}

	/**
	 * 线程停止后执行的任务
	 */
	protected abstract void afterStopThread();

}
