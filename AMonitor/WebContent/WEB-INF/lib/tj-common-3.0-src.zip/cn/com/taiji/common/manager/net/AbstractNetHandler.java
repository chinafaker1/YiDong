package cn.com.taiji.common.manager.net;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午09:40:59
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractNetHandler
{
	protected Logger logger = LoggerFactory.getLogger(getClass());
}
