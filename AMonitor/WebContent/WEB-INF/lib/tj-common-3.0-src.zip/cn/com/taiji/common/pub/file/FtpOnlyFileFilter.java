package cn.com.taiji.common.pub.file;

import java.io.File;
import java.io.FileFilter;

import cn.com.taiji.common.model.finals.SysFinals;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-5-19 下午02:53:00
 * @since 1.0
 * @version 1.0
 */
public class FtpOnlyFileFilter implements FileFilter
{
	private static FtpOnlyFileFilter instance;

	public static FtpOnlyFileFilter getInstance()
	{
		if (instance == null) instance = new FtpOnlyFileFilter();
		return instance;
	}

	public boolean accept(File pathname)
	{
		if (pathname.isDirectory()) return false;
		if (pathname.getName().endsWith(SysFinals.PART_FILE_SUFFIX)) return false;
		return true;
	}

}
