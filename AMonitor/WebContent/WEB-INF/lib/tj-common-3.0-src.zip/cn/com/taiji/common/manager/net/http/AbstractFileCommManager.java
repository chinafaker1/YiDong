/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.file.FileProtocolRequest;
import cn.com.taiji.common.model.file.FileProtocolResponse;
import cn.com.taiji.common.pub.NumberTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午6:37:33<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractFileCommManager extends AbstractManager
{

	protected <T> T filePost(String url, FileProtocolRequest request, FileProtocolResponseHandler<T> handler)
			throws IOException
	{
		return filePost(url, 10000, request, -1, handler);
	}

	/**
	 * 
	 * @param url
	 * @param connTimeout
	 * @param request
	 * @param soTimeout
	 *            响应超时毫秒
	 * @param handler
	 * @throws IOException
	 */
	protected <T> T filePost(String url, int connTimeout, FileProtocolRequest request, int soTimeout,
			FileProtocolResponseHandler<T> handler) throws IOException
	{
		FileProtocolResponse rs = FileCommHelper.filePost(url, connTimeout, request, soTimeout);
		File tmpFile = rs.getTmpFile();
		InputStream in = rs.getBinFile();
		if (tmpFile != null) logger.debug("本次响应使用了文件中转，响应大小:{}", NumberTools.bytesAsHumanStr(tmpFile.length()));
		try
		{
			return handler.handleResponse(rs.getStatusCode(), rs.getFilename(), in, rs.getErrorMsg());
		}
		finally
		{
			if (in != null)
			{
				closeQuietly(in);
				if (rs.needDeleteTmp() && !tmpFile.delete())
					logger.error("delete FileProtocolResponse tmpFile error:{}", tmpFile.getAbsolutePath());
			}
		}
	}
}
