/*
 * Date: 2015年4月10日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月10日 下午1:37:27<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public enum FileProtocolConstant
{
	MD5_HEADER("binfile-md5") {},
	GZIP_HEADER("binfile-gzip") {},
	AUTH_HEADER("binfile-auth") {},//预留鉴权用，如果接口需要鉴权，必需在请求的header中设置鉴权凭据
	IN_MEM_MAXSIZE("binfile-memsize") {
		private static final long IN_MEM_MAX_SIZE = 1024L * 1024 * 2;// 2M以内的缓存在内存中

		public long getSize()
		{
			return IN_MEM_MAX_SIZE;
		}
	},
	;
	private String value;

	private FileProtocolConstant(String value)
	{
		this.value = value;
	}

	public String getValue()
	{
		return value;
	}

	/**
	 * {@link #IN_MEM_MAXSIZE} 时有用
	 * 
	 * @return
	 */
	public long getSize()
	{
		return 0L;
	}
}
