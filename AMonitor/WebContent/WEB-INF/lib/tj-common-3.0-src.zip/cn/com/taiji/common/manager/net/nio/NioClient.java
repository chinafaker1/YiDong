package cn.com.taiji.common.manager.net.nio;

import java.io.IOException;

import org.xsocket.connection.INonBlockingConnection;

import cn.com.taiji.common.model.net.nio.NioProtocol;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-22 下午04:13:51
 * @since 1.0
 * @version 1.0
 */
public interface NioClient extends Runnable
{
	/**
	 * 启动与服务器的连接，启动后不管是否连接上都会开启线程进行连接检测<BR>
	 * 如果连接失败或断开会自动重新连接
	 * 
	 */
	public void start();

	/**
	 * 停止连接检测线程并关闭连接
	 */
	public void stop();

	/**
	 * 当前连接状态
	 * 
	 * @return
	 */
	public boolean isConnected();

	/**
	 * 
	 * @throws IOException
	 */
	public void autoReconnect() throws IOException;

	/**
	 * 向服务端发送请求.
	 * 
	 * @param protocol
	 * @throws IOException
	 */
	public void sendRequest(NioProtocol protocol) throws IOException;

	/**
	 * 取得当前client对应的连接,可通过包装此连接达到发送同步请求的目的
	 * 
	 * @return
	 * @throws IOException
	 */
	public INonBlockingConnection getConnection() throws IOException;
}
