/*
 * Date: 2011-7-28
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.apache.tools.zip.ZipOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.ClassTools;
import cn.com.taiji.common.pub.FileCopyTools;
import cn.com.taiji.common.pub.ProjectEnv;
import cn.com.taiji.common.pub.StringTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-7-28 上午10:55:11<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class ZipHelper extends AbstractHelper
{
	protected static Logger logger = LoggerFactory.getLogger(ZipHelper.class);

	/**
	 * 压缩二进制
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 */
	public static byte[] gzip(byte[] data) throws IOException
	{
		AssertUtil.notNull(data);
		ByteArrayOutputStream out = new ByteArrayOutputStream(BUFFER);
		GZIPOutputStream gzip = new GZIPOutputStream(out);
		gzip.write(data);
		gzip.close();
		return out.toByteArray();
	}

	/**
	 * 解压二进制
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 */
	public static byte[] unzip(byte[] data) throws IOException
	{
		AssertUtil.notNull(data);
		ByteArrayOutputStream out = new ByteArrayOutputStream(BUFFER);
		ByteArrayInputStream in = new ByteArrayInputStream(data);
		GZIPInputStream gunzip = new GZIPInputStream(in);
		byte[] buffer = new byte[BUFFER];
		int n;
		while ((n = gunzip.read(buffer)) >= 0)
		{
			out.write(buffer, 0, n);
		}
		gunzip.close();
		return out.toByteArray();
	}

	/**
	 * 压缩字符串
	 * 
	 * @param str
	 *            被压缩的字符串
	 * @return 压缩后的字符串
	 * @throws IOException
	 */
	public static String compress(String str) throws IOException
	{
		if (str == null || str.length() == 0) return str;
		return new String(gzip(str.getBytes()), "ISO8859-1");
	}

	/**
	 * 解压缩字符串，返回的字符串使用默认编码
	 * 
	 * @param str
	 *            压缩后的字符串
	 * @return 解压后的字符串
	 * @throws IOException
	 * @see {@link #uncompress(String, String)}
	 */
	public static String uncompress(String str) throws IOException
	{
		return uncompress(str, null);
	}

	/**
	 * 解压缩字符串，返回的字符串使用指定编码
	 * 
	 * @param str
	 *            压缩后的字符串
	 * @param encoding
	 *            指定编码，null时使用默认编码
	 * @return 解压后的字符串
	 * @throws IOException
	 */
	public static String uncompress(String str, String encoding) throws IOException
	{
		if (str == null || str.length() == 0) return str;
		byte[] data = unzip(str.getBytes("ISO8859-1"));
		if (encoding == null) return new String(data);
		return new String(data, encoding);
	}

	/**
	 * 等同于unzip(File, String, null)
	 * 
	 * @see {@link #unzip(File, String, String)}
	 * @param file
	 *            压缩文件
	 * @param outputDirectory
	 *            解压目录
	 * @throws IOException
	 */
	public static void unzip(File file, String outputDirectory) throws IOException
	{
		unzip(file, outputDirectory, null);
	}

	/**
	 * 解压zip压缩文件,会覆盖解压目录下的同名文件
	 * 
	 * @param zipIn
	 *            zip压缩文件的流
	 * @param outputDirectory
	 *            输出到的文件夹，文件夹不存在时会自动创建
	 * @param encoding
	 *            the encoding to use for file names, use null for the platform's default encoding
	 * 
	 * @throws IOException
	 */
	public static void unzip(File file, String outputDirectory, String encoding) throws IOException
	{
		AssertUtil.notNull(file);
		AssertUtil.notNull(outputDirectory);
		File od = new File(outputDirectory);
		if (!(od.exists() && od.isDirectory()) && !od.mkdirs()) throw new IOException("创建输出文件夹失败:" + outputDirectory);
		ZipFile zipFile = new ZipFile(file, encoding);
		try
		{
			Enumeration<?> en = zipFile.getEntries();
			while (en.hasMoreElements())
			{
				ZipEntry z = ClassTools.cast(en.nextElement(), ZipEntry.class);
				File f = new File(outputDirectory + "/" + z.getName());
				logger.debug("unziping {} to {}", z.getName(), outputDirectory);
				if (z.isDirectory())
				{
					if (!(f.exists() && f.isDirectory()) && !f.mkdirs())
						throw new RuntimeException("mkdirs failed:" + f.getAbsolutePath());
					continue;
				}
				// unzip file
				if (!(f.exists() && f.isFile()))
				{
					File floder = f.getParentFile();
					if (!(floder.exists() && floder.isDirectory())) ProjectEnv.mkdirs(floder.getAbsolutePath());
				}
				FileCopyTools.copy(zipFile.getInputStream(z), new FileOutputStream(f));
			}
		}
		finally
		{
			if (zipFile != null) zipFile.close();
		}
	}

	public static void zip(File source, File dest) throws IOException
	{
		zip(source, null, dest);
	}

	/**
	 * 压缩文件或者文件夹
	 * 
	 * @param source
	 *            被压缩的源
	 * @param encoding
	 *            压缩文件编码，为空使用平台默认编码
	 * @param dest
	 *            压缩文件
	 * @throws IOException
	 *             压缩失败抛出异常
	 */
	public static void zip(File source, String encoding, File dest) throws IOException
	{
		AssertUtil.notNull(source);
		AssertUtil.notNull(dest);
		ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(dest)));
		try
		{
			if (StringTools.hasText(encoding)) zos.setEncoding(encoding);
			String basePath = source.isDirectory() ? source.getPath() : source.getParent();
			zipFile(source, basePath, zos);
		}
		finally
		{
			if (zos != null)
			{
				zos.closeEntry();
				zos.close();
			}
		}
	}

	private static void zipFile(File source, String basePath, ZipOutputStream zos) throws IOException
	{
		File[] files = source.isDirectory() ? source.listFiles() : new File[] { source };
		String pathName;
		byte[] buf = new byte[1024];
		int length = 0;
		for (File file : files)
		{
			if (file.isDirectory())
			{
				pathName = file.getPath().substring(basePath.length() + 1) + "/";
				zos.putNextEntry(new ZipEntry(pathName));
				zipFile(file, basePath, zos);
			}
			else
			{
				pathName = file.getPath().substring(basePath.length() + 1);
				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
				try
				{
					zos.putNextEntry(new ZipEntry(pathName));
					while ((length = bis.read(buf)) > 0)
					{
						zos.write(buf, 0, length);
					}
				}
				finally
				{
					if (bis != null) bis.close();
				}
			}
		}
	}

	/**
	 * 对指定的流进行压缩
	 * 
	 * @param entryName
	 *            在压缩文档中的名字
	 * @param in
	 *            被压缩的流
	 * @param encoding
	 *            压缩文件编码，为空使用平台默认编码
	 * @param out
	 *            压缩文件输出到的流
	 * @throws IOException
	 *             压缩失败抛出异常
	 */
	public static void zip(String entryName, InputStream in, String encoding, OutputStream out) throws IOException
	{
		AssertUtil.notNull(in);
		AssertUtil.notNull(out);
		byte[] buf = new byte[1024];
		int length = 0;
		BufferedInputStream bis = new BufferedInputStream(in);
		ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(out));
		try
		{
			if (StringTools.hasText(encoding)) zos.setEncoding(encoding);
			zos.putNextEntry(new ZipEntry(entryName));
			while ((length = bis.read(buf)) > 0)
			{
				zos.write(buf, 0, length);
			}
		}
		finally
		{
			bis.close();
			zos.closeEntry();
			zos.close();
		}
	}
}
