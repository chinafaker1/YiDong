/*
 * Date: 2015年4月10日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月10日 上午11:13:42<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public enum FileProtocolSystemError
{
	AUTH_FAILED(950, "鉴权失败") {},
	MD5_FAILED(951, "文件md5校验失败") {},
	UNKNOWN_ERROR(999, "未知错误") {},
	;
	private final int code;
	private final String msg;

	private FileProtocolSystemError(int code, String msg)
	{
		this.code = code;
		this.msg = msg;
	}

	public FileProtocolResponse newResponse()
	{
		return new FileProtocolResponse(code, msg);
	}

	public int getCode()
	{
		return code;
	}

	public String getMsg()
	{
		return msg;
	}

}
