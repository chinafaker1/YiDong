package cn.com.taiji.common.manager;

import java.io.Serializable;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.com.taiji.common.dao.AbstractDao;
import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.pub.AssertUtil;


/**
 * 
 * @author Peream <br>
 *         Create Time：2010-7-29 上午11:04:46<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link DaoManager}
 */
public abstract class AbstractDaoManager<E extends BaseEntity, D extends AbstractDao<E>> extends AbstractManager
		implements DaoManager<E, D>
{
	protected final D dao;

	protected AbstractDaoManager(D dao)
	{
		AssertUtil.notNull(dao);
		this.dao = dao;
	}

	public E findById(Serializable id)
	{
		return dao.findById(id);
	}

	@Transactional(rollbackFor = { ManagerException.class })
	public Serializable add(E entity) throws ManagerException
	{
		AssertUtil.notNull(entity);
		checkAdd(entity);
		return dao.save(entity);
	}

	/**
	 * 请覆盖本方法实现添加校验
	 * 
	 * @param entity
	 *            记录
	 * @throws ManagerException
	 *             不能添加时抛出异常
	 */
	protected void checkAdd(E entity) throws ManagerException
	{

	}

	@Transactional(rollbackFor = { ManagerException.class })
	public void update(E entity) throws ManagerException
	{
		AssertUtil.notNull(entity);
		checkUpdate(entity);
		dao.update(entity);
	}

	/**
	 * 请覆盖本方法实现修改校验
	 * 
	 * @param entity
	 *            记录
	 * @throws ManagerException
	 *             不能修改时抛出异常
	 */
	protected void checkUpdate(E entity) throws ManagerException
	{

	}

	@Transactional(rollbackFor = { ManagerException.class })
	public void delete(E entity) throws ManagerException
	{
		if (entity == null) return;
		checkDelete(entity);
		dao.delete(entity);
	}

	@Transactional(rollbackFor = { ManagerException.class })
	public void deleteById(Serializable id) throws ManagerException
	{
		E entity = dao.findById(id);
		if (entity == null) return;
		checkDelete(entity);
		dao.delete(entity);
	}

	/**
	 * 请覆盖本方法实现删除校验
	 * 
	 * @param entity
	 *            记录
	 * @throws ManagerException
	 *             不能删除时抛出异常
	 */
	protected void checkDelete(E entity) throws ManagerException
	{

	}

	public long getTotalCount()
	{
		return dao.getTotalCount();
	}

	public List<E> listAll()
	{
		return dao.getAll();
	}

	public Pagination pageAll(int pageNo, int pageSize)
	{
		return dao.getAll(pageNo, pageSize);
	}
}
