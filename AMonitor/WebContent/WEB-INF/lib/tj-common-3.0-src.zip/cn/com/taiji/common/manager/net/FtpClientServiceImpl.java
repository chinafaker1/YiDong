package cn.com.taiji.common.manager.net;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ProtocolCommandEvent;
import org.apache.commons.net.ProtocolCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPCmd;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import cn.com.taiji.common.model.finals.SysFinals;
import cn.com.taiji.common.model.net.FtpStorePara;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-1 下午05:04:52
 * @since 1.0
 * @version 1.0
 */
public class FtpClientServiceImpl extends AbstractClientService implements FtpClientService, ProtocolCommandListener,
		Runnable
{
	private FTPClient ftp;
	private FTPClientConfig clientConfig;
	private AtomicBoolean connected = new AtomicBoolean(false);
	private List<ProtocolCommandListener> listeners;

	private AtomicBoolean stop = new AtomicBoolean(false);
	private Thread keepAliveThread;
	private final long liveCheckInterval;

	private Object lock = new Object();

	/**
	 * 
	 * @param server
	 *            服务器地址（IP）
	 * @param port
	 *            服务器端口
	 * @param username
	 *            登录ftp的用户名
	 * @param password
	 *            登录ftp的密码
	 * @param liveCheckInterval
	 *            ftp长连接的检测时间（毫秒）
	 * @param encoding
	 *            服务器编码方式
	 * @param connTimeout
	 *            服务器连接的超时时间（毫秒），大于0时生效
	 * @param soTimeout
	 *            服务器读取数据的超时时间（毫秒），大于0时生效
	 */
	public FtpClientServiceImpl(String server, int port, String username, String password, long liveCheckInterval,
			String encoding, int connTimeout, int soTimeout)
	{
		AssertUtil.notNull(server, "server can not be null");
		this.server = server;
		this.port = port;
		this.username = username == null ? "" : username;
		this.password = password == null ? "" : password;
		if (liveCheckInterval < 100) throw new IllegalArgumentException("liveCheckInterVal can not less than 100");
		this.liveCheckInterval = liveCheckInterval;
		this.encoding = encoding;
		this.connTimeout = connTimeout;
		this.soTimeout = soTimeout;
	}

	public FtpClientServiceImpl(String server, int port, String username, String password, long liveCheckInterval,
			String encoding, int connTimeout)
	{
		this(server, port, username, password, liveCheckInterval, encoding, connTimeout, DEFAULT_SO_TIMEOUT);
	}

	public FtpClientServiceImpl(String server, int port, String username, String password, long liveCheckInterval,
			String encoding)
	{
		this(server, port, username, password, liveCheckInterval, encoding, DEFAULT_CONNECT_TIMEOUT);
	}

	public FtpClientServiceImpl(String server, int port, String username, String password, long liveCheckInterval)
	{
		this(server, port, username, password, liveCheckInterval, "UTF-8");
	}

	public FtpClientServiceImpl(String server, int port, String username, String password)
	{
		this(server, port, username, password, 15000);// 15 seconds
	}

	public FtpClientServiceImpl(String server, String username, String password, String encoding)
	{
		this(server, 21, username, password, 15000, encoding);
	}

	public FtpClientServiceImpl(String server, String username, String password)
	{
		this(server, 21, username, password);
	}

	public synchronized void start() throws IOException
	{
		if (running.get())
		{
			logger.info("ftp client service already start.");
			return;
		}
		stop.set(false);
		connect();// ftp 连接
		// if (!connected)
		// throw new IOException("Can not create ftp connection server:"
		// + server + "\tusername:" + username + "\tpassword:"
		// + password);
		if (keepAliveThread == null)
		{
			keepAliveThread = new Thread(this);
			keepAliveThread.start();// 启动连接监听线程
			Thread.yield();
		}
		logger.info("Star ftp client service...\t" + server);
		running.set(true);
	}

	public synchronized void stop()
	{
		if (!running.get())
		{
			logger.info("Ftp client service is not running.");
			return;
		}
		try
		{
			stop.set(true);
			if (keepAliveThread != null)
			{
				keepAliveThread.interrupt();
				Thread.yield();
			}
			disconnect();
		}
		finally
		{
			running.set(false);
			logger.info("Stop Ftp client service...\t{}", server);
		}

	}

	@Override
	public boolean doCommand(FTPCmd cmd, String params) throws IOException
	{
		AssertUtil.notNull(cmd);
		prepare();
		try
		{
			synchronized (lock)
			{
				return ftp.doCommand(cmd.getCommand(), params);
			}
		}
		catch (Exception e)
		{
			disconnect();
			logger.error("", e);
			throw new IOException(e.getMessage());
		}
	}

	@Override
	public boolean cd(String remotePath) throws IOException
	{
		AssertUtil.hasText(remotePath);
		String isoPath = new String(remotePath.getBytes(encoding), ISO8859);
		return doCommand(FTPCmd.CWD, isoPath);
	}

	public String[] listNames(String pathname) throws IOException
	{
		prepare();
		try
		{
			String isoPath = new String(pathname.getBytes(encoding), ISO8859);
			synchronized (lock)
			{
				return ftp.listNames(isoPath);
			}
		}
		catch (Exception e)
		{
			disconnect();
			logger.error("", e);
			throw new IOException(e.getMessage());
		}
	}

	public List<FTPFile> listFiles(String pathname) throws IOException
	{
		return listFiles(pathname, null, null);
	}

	public List<FTPFile> listFiles(String path, Comparator<FTPFile> comparator) throws IOException
	{
		return listFiles(path, null, comparator);
	}

	public List<FTPFile> listFiles(String path, Pattern namePattern) throws IOException
	{
		return listFiles(path, namePattern, null);
	}

	public List<FTPFile> listFiles(String path, Pattern namePattern, Comparator<FTPFile> comparator) throws IOException
	{
		prepare();
		try
		{
			List<FTPFile> list = new ArrayList<FTPFile>();
			String isoPath = new String(path.getBytes(encoding), ISO8859);
			FTPFile[] files = null;
			synchronized (lock)
			{
				files = ftp.mlistDir(isoPath);// 优先使用mlsd，可以得到更详细的文件信息，特别是修改时间
				if (isEmpty(files)) files = ftp.listFiles(isoPath);
			}
			if (isEmpty(files)) return list;
			for (FTPFile file : files)
			{
				if (namePattern == null)
				{
					list.add(file);
					continue;
				}
				if (namePattern.matcher(file.getName()).matches()) list.add(file);
			}
			if (comparator != null) Collections.sort(list, comparator);
			return list;
		}
		catch (Exception e)
		{
			disconnect();
			logger.error("", e);
			throw new IOException(e.getMessage());
		}
	}

	@Override
	public boolean downFile(String remote, String local, boolean binaryTransfer, String suffix) throws IOException
	{
		AssertUtil.notNull(remote, "param remote can not be null");
		AssertUtil.notNull(local, "param local can not be null");
		String mySuffix = hasText(suffix) ? suffix : SysFinals.PART_FILE_SUFFIX;
		File localFile = new File(local);
		String localTmp = local + mySuffix;
		File tmpFile = new File(localTmp);
		FTPClient ftp = prepareClient(binaryTransfer);
		long begin = System.currentTimeMillis();
		File parent = tmpFile.getParentFile();
		if (!parent.isDirectory() && !parent.mkdirs())
			logger.error(toLogString("创建文件夹 {} 失败", parent.getAbsolutePath()));
		OutputStream out = new FileOutputStream(tmpFile);
		try
		{
			String isoRemote = new String(remote.getBytes(encoding), ISO8859);
			boolean rs = ftp.retrieveFile(isoRemote, out);
			out.close();
			out = null;
			logger.debug("down file ({}---{}) in {} ms,result:{}",
					new Object[] { remote, tmpFile.length(), (System.currentTimeMillis() - begin), rs });
			if (!rs)
			{
				logger.error("下载文件({})失败", remote);
				if (!tmpFile.delete()) logger.error("删除临时文件({})失败", tmpFile.getAbsolutePath());
				return false;
			}
			if (localFile.exists() && !localFile.delete()) logger.error("delete local file failed:{}", local);
			rs = tmpFile.renameTo(localFile);
			if (!rs)
			{
				logger.error("将文件 {} 重命名成 {} 失败.", tmpFile.getAbsolutePath(), localFile.getAbsolutePath());
				if (!tmpFile.delete()) logger.error("删除临时文件({})失败", tmpFile.getAbsolutePath());
			}
			return rs;
		}
		finally
		{
			if (out != null) out.close();
			disconnect(ftp);
		}
	}

	public boolean downFile(String remote, String local, boolean binaryTransfer) throws IOException
	{
		return downFile(remote, local, binaryTransfer, getPartSuffix());
	}

	public boolean downFile(String remote, String local) throws IOException
	{
		return downFile(remote, local, true);
	}

	public boolean storeFile(String remote, String local, boolean binaryTransfer) throws IOException
	{
		return storeFile(remote, false, local, binaryTransfer);
	}

	public boolean storeFile(String remote, boolean mkdirs, String local) throws IOException
	{
		return storeFile(remote, mkdirs, local, true);
	}

	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer) throws IOException
	{
		return storeFile(remote, mkdirs, local, binaryTransfer, getPartSuffix(), true);
	}

	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer, boolean useSuffix)
			throws IOException
	{
		return storeFile(remote, mkdirs, local, binaryTransfer, getPartSuffix(), useSuffix);
	}

	public boolean storeFile(String remote, boolean mkdirs, String local, boolean binaryTransfer, String suffix,
			boolean useSuffix) throws IOException
	{
		FtpStorePara para = new FtpStorePara();
		para.setRemote(remote);
		para.setLocal(local);
		para.setMkdirs(mkdirs);
		para.setBinaryTransfer(binaryTransfer);
		para.setSuffix(suffix);
		para.setUseSuffix(useSuffix);

		para.setDeleteBeforeStore(true);
		return storeFile(para);
	}

	public boolean storeFile(FtpStorePara para) throws IOException
	{
		String remote = para.getRemote();
		String local = para.getLocal();
		AssertUtil.notNull(remote, "param remote can not be null");
		AssertUtil.notNull(local, "param local can not be null");
		// 创建必要的文件夹
		if (para.isMkdirs() && remote.contains("/"))
		{
			String remotePath = remote.substring(0, remote.lastIndexOf("/"));
			if (!mkdir(remotePath))
			{
				logger.debug("mkdir创建文件夹失败,用mkdirs创建文件夹");
				if (!mkdirs(remotePath)) throw new IOException("创建文件夹失败：" + remotePath);
				logger.debug("使用mkdirs创建文件夹:{}", remotePath);
			}
		}
		FTPClient ftp = null;
		InputStream input = null;
		try
		{
			ftp = prepareClient(para.isBinaryTransfer());
			long begin = System.currentTimeMillis();
			File localFile = new File(local);
			input = new FileInputStream(localFile);
			if (para.isDeleteBeforeStore() && hasFile(remote) && !deleteFile(remote))
				throw new IOException("FTP存在目标文件且不允许删除:" + remote);
			String remoteTmp = para.isUseSuffix() ? remote + para.getSuffix() : remote;
			String isoRemote = new String(remoteTmp.getBytes(encoding), ISO8859);
			boolean rs = ftp.storeFile(isoRemote, input);
			logger.debug("store file ({}---{}) in {} ms, result:{}",
					new Object[] { remote, localFile.length(), (System.currentTimeMillis() - begin), rs });
			if (!rs)
			{
				logger.warn("上传文件({})失败,可能是权限不足.", remote);
				return false;
			}
			return para.isUseSuffix() ? rename(remoteTmp, remote) : true;
		}
		finally
		{
			if (input != null) input.close();
			if (ftp != null) disconnect(ftp);
		}
	}

	public boolean resumeStore(String remote, String local, boolean useSuffix, String suffix) throws IOException
	{
		AssertUtil.notNull(remote, "param remote can not be null");
		AssertUtil.notNull(local, "param local can not be null");
		File localFile = new File(local);
		long localSize = localFile.length();
		// 判断文件是否已经上传过
		if (useSuffix)
		{
			List<FTPFile> files = listFiles(remote);
			if (files.size() == 1)
			{
				long remoteSize = files.get(0).getSize();
				if (remoteSize == localSize) return true;
			}
		}
		String remoteTmp = useSuffix ? remote + suffix : remote;
		// 远程服务器上没有文件，重新传送
		List<FTPFile> files = listFiles(remoteTmp);
		if (files.size() == 0) return storeFile(remote, true, local, true, suffix, useSuffix);

		long remoteSize = files.get(0).getSize();
		if (remoteSize > localSize) throw new IOException("远程文件比本地文件大，无法续传");
		// 文件续传
		FTPClient ftp = null;
		InputStream is = new FileInputStream(localFile);
		try
		{
			ftp = prepareClient(true);
			String isoRemote = new String(remoteTmp.getBytes(encoding), ISO8859);
			if (is.skip(remoteSize) == remoteSize)
			{
				ftp.setRestartOffset(remoteSize);
				logger.debug("续传中,已上传:{}", remoteSize);
				// 续传成功，直接返回
				if (ftp.storeFile(isoRemote, is)) return useSuffix ? rename(remoteTmp, remote) : true;
			}
		}
		finally
		{
			if (is != null) is.close();
			if (ftp != null) disconnect(ftp);
		}
		// 续传没成功，重新传
		logger.debug("续传没成功，将重新上传...");
		return storeFile(remote, true, local, true, suffix, useSuffix);
	}

	public boolean storeFile(String remote, String local) throws IOException
	{
		return storeFile(remote, false, local, true);
	}

	public boolean deleteFile(String pathname) throws IOException
	{
		AssertUtil.notNull(pathname, "param pathname can not be null.");
		String isoPath = new String(pathname.getBytes(encoding), ISO8859);
		return doCommand(FTPCmd.DELE, isoPath);
	}

	public boolean hasFile(String pathname) throws IOException
	{
		AssertUtil.notNull(pathname, "Param pathname can not be null.");
		List<FTPFile> files = listFiles(pathname);
		return (files.size() > 0);
	}

	public boolean rename(String from, String to) throws IOException
	{
		String isoFrom = new String(from.getBytes(encoding), ISO8859);
		String isoTo = new String(to.getBytes(encoding), ISO8859);
		prepare();
		try
		{
			synchronized (lock)
			{
				return ftp.rename(isoFrom, isoTo);
			}
		}
		catch (Exception e)
		{
			disconnect();
			logger.error("", e);
			throw new IOException(e.getMessage());
		}
	}

	public boolean mkdir(String path) throws IOException
	{
		if (!hasText(path)) return false;
		String isoPath = new String(path.getBytes(encoding), ISO8859);
		if (doCommand(FTPCmd.CWD, isoPath)) return true;
		return doCommand(FTPCmd.MKD, isoPath);
	}

	public boolean mkdirs(String path) throws IOException
	{
		if (!hasText(path)) return false;
		boolean rs = false;
		String[] strs = path.split("/");
		StringBuilder sb = new StringBuilder("/");
		String isoPath = new String(path.getBytes(encoding), ISO8859);
		if (doCommand(FTPCmd.CWD, isoPath)) return true;
		for (String str : strs)
		{
			if (!hasText(str)) continue;
			sb.append(str).append("/");
			rs = doCommand(FTPCmd.MKD, new String(sb.toString().getBytes(encoding), ISO8859));
		}
		return rs;
	}

	public boolean rmdir(String path) throws IOException
	{
		if (!hasText(path)) return false;
		String isoPath = new String(path.getBytes(encoding), ISO8859);
		return doCommand(FTPCmd.RMD, isoPath);
	}

	public String printWorkingDirectory() throws IOException
	{
		prepare();
		synchronized (lock)
		{
			String pwd = ftp.printWorkingDirectory();
			return new String(pwd.getBytes(ISO8859), encoding);
		}
	}

	private synchronized void connect()
	{
		if (connected.get())
		{
			logger.info("Already connected to ftp server:{}@{}", username, server);
			return;
		}
		ftp = new FTPClient();
		ftp.addProtocolCommandListener(this);// 监听命令执行错误事件
		if (!isEmpty(listeners))
		{
			for (ProtocolCommandListener listener : listeners)
				ftp.addProtocolCommandListener(listener);
		}
		try
		{
			doConnect(ftp);
			logger.info("connect to server ({}@{}) success.", username, server);
			connected.set(true);
		}
		catch (Exception e)
		{
			logger.error(toLogString("can not connect to:{}@{}", username, server), e);
			disconnect();
		}
	}

	private void doConnect(FTPClient ftp) throws IOException
	{
		if (getClientConfig() != null) ftp.configure(getClientConfig());
		// 连接30秒超时
		if (connTimeout > 0) ftp.setConnectTimeout(connTimeout);
		ftp.connect(server, port);
		if (soTimeout > 0)// 数据读取的超时时间设置
		{
			ftp.setDataTimeout(soTimeout);
			ftp.setSoTimeout(soTimeout);
		}
		ftp.setRemoteVerificationEnabled(false);// 关闭远程校验
		int reply = ftp.getReplyCode();
		// After connection attempt, you should check the reply code to verify success
		if (!FTPReply.isPositiveCompletion(reply))
			throw new IOException("connection is established,but the reply is not positive.");
		if (!ftp.login(username, password))
			throw new IOException(toLogString("Ftp login failed:{}@{}", username, server));
		// Use passive mode as default because most of us are behind firewalls these days
		ftp.enterLocalPassiveMode();
		ftp.setControlEncoding(encoding);
		ftp.setBufferSize(BUFFERED_SIZE);
	}

	private FTPClient getClient()
	{
		FTPClient ftp = new FTPClient();
		try
		{
			doConnect(ftp);
			return ftp;
		}
		catch (Exception e)
		{
			logger.error(toLogString("can not connect to:{}@{}", username, server), e);
			disconnect(ftp);
			return null;
		}
	}

	public boolean isConnected()
	{
		return connected.get();
	}

	private synchronized void disconnect()
	{
		try
		{
			disconnect(ftp);
		}
		finally
		{
			connected.set(false);
		}
	}

	private void disconnect(FTPClient ftp)
	{
		try
		{
			// if (ftp == null || !(ftp.isConnected())) return;
			if (ftp == null) return;
			logger.debug("Disconnect ftp client here:{}", ftp);
			ftp.logout();
			ftp.disconnect();
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
	}

	protected boolean autoReconnect()
	{
		if (!connected.get()) connect();
		return connected.get();
	}

	public void run()
	{
		while (!stop.get())
		{
			try
			{
				if (connected.get())
				{
					synchronized (lock)
					{
						ftp.sendNoOp();
					}
				}
				else
				{
					logger.info("The Connection({}@{}) is broken,Reconnect here..", username, server);
					connect();
				}
				Thread.sleep(liveCheckInterval);
			}
			catch (InterruptedException e)
			{
				logger.info("Catch interrupt ,stop connection listen thread.");
				stop.set(true);
			}
			catch (IOException e)
			{
				logger.error(e.getMessage());
				disconnect();
			}
			catch (Exception e)
			{
				logger.error(e.getMessage());
			}
		}
	}

	public void protocolCommandSent(ProtocolCommandEvent event)
	{
		// do nothing
	}

	public void protocolReplyReceived(ProtocolCommandEvent event)
	{
		int reply = event.getReplyCode();
		// 主要是421 Connection timed out - closing.
		// 命令错误时断开连接
		// FTPReply.isNegativePermanent(reply) 不可恢复的命令，重连也没有意义
		if (FTPReply.isNegativeTransient(reply))
		{
			logger.warn("ftp client ({}@{}) command ({}) failed,reason:{}",
					new Object[] { username, server, event.getCommand(), event.getMessage() });
			disconnect();
		}
	}

	protected void prepare() throws IOException
	{
		if (!autoReconnect()) throw new IOException(toLogString("Can not connect to server:{}@{}", username, server));
	}

	protected FTPClient prepareClient(boolean binaryTransfer) throws IOException
	{
		return prepareClient(binaryTransfer, enableDebug);
	}

	protected FTPClient prepareClient(boolean binaryTransfer, boolean enableDebug) throws IOException
	{
		long begTime = System.currentTimeMillis();
		FTPClient ftp = getClient();
		if (ftp == null) throw new IOException(toLogString("Can not create Connection: {}@{}", username, server));
		if (binaryTransfer) ftp.setFileType(FTP.BINARY_FILE_TYPE);
		// 1分钟服务器无反馈，主动关闭连接
		ftp.setDefaultTimeout(60000);
		logger.debug("prepare ftp client use time:{} ms", (System.currentTimeMillis() - begTime));
		if (enableDebug)
			ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(new OutputStreamWriter(System.out,
					ISO8859))));
		return ftp;
	}

	public FTPClientConfig getClientConfig()
	{
		if (clientConfig == null) clientConfig = new FTPClientConfig();
		return clientConfig;
	}

	public void setClientConfig(FTPClientConfig clientConfig)
	{
		this.clientConfig = clientConfig;
	}

	public void setListeners(List<ProtocolCommandListener> listeners)
	{
		this.listeners = listeners;
	}

	public long getLiveCheckInterval()
	{
		return liveCheckInterval;
	}

}
