/*
 * Date: 2011-6-15
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.pub;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-15 下午03:37:47<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class PdfContentInfo extends AbstractContentInfo
{
	private Map<String, Object> contents;
	private List<String> fonts;

	public PdfContentInfo()
	{
		templateUrl = "defaultTemplate.ftl";// 模板文件路径
		templateEncoding = "UTF-8";
	}

	public Map<String, Object> getContents()
	{
		return contents;
	}

	public void setContents(Map<String, Object> contents)
	{
		this.contents = contents;
	}

	public List<String> getFonts()
	{
		return fonts;
	}

	public void setFonts(List<String> fonts)
	{
		this.fonts = fonts;
	}

}
