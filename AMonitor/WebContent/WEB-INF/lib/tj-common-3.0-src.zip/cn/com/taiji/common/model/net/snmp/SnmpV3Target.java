package cn.com.taiji.common.model.net.snmp;

import org.snmp4j.UserTarget;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.security.AuthMD5;
import org.snmp4j.security.PrivDES;
import org.snmp4j.security.SecurityLevel;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 下午04:26:10
 * @since 1.0
 * @version 1.0
 */
public class SnmpV3Target extends BaseSnmpTarget
{
	private String securityName = "MD5DES";
	private OID authOid = AuthMD5.ID;
	private String authPass = "12345678";
	private OID priOid = PrivDES.ID;
	private String priPass = "12345678";

	public String getSecurityName()
	{
		return securityName;
	}

	public void setSecurityName(String securityName)
	{
		this.securityName = securityName;
	}

	public OID getAuthOid()
	{
		return authOid;
	}

	public void setAuthOid(OID authOid)
	{
		this.authOid = authOid;
	}

	public String getAuthPass()
	{
		return authPass;
	}

	public void setAuthPass(String authPass)
	{
		this.authPass = authPass;
	}

	public OID getPriOid()
	{
		return priOid;
	}

	public void setPriOid(OID priOid)
	{
		this.priOid = priOid;
	}

	public String getPriPass()
	{
		return priPass;
	}

	public void setPriPass(String priPass)
	{
		this.priPass = priPass;
	}

	public UserTarget getUserTarget()
	{
		return getUserTarget(SecurityLevel.AUTH_PRIV);
	}

	public UserTarget getUserTarget(int securityLevel)
	{
		UserTarget target = new UserTarget();
		target.setAddress(new UdpAddress(getIp() + "/" + getPort()));
		target.setRetries(1);
		target.setTimeout(5000);
		target.setVersion(SnmpConstants.version3);
		target.setSecurityLevel(securityLevel);
		target.setSecurityName(new OctetString(securityName));
		return target;
	}

}
