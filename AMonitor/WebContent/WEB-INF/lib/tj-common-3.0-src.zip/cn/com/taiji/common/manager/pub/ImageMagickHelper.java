package cn.com.taiji.common.manager.pub;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.ScriptExecuteException;
import cn.com.taiji.common.pub.ScriptTool;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.SystemTools;


/**
 * 本类的方法需要ImageMagick的支持，请确认运行的机器上已经安装了ImageMagick<br/>
 * 请从官网<a href="http://www.imagemagick.org">http://www.imagemagick.org</a> 下载对应平台的软件进行安装。<br/>
 * 本类中所有方法出现用像素当参数时，可以为以下形式：180 25% 180x320 35%x35% 60x25%<br/>
 * 另：windows下convert与windows/system32下的convert冲突，请设置IMAGE_MAGICK_HOME环境变量
 * 
 * @author Peream <br>
 *         Create Time：2009-11-20 上午10:04:46<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class ImageMagickHelper
{
	protected static Logger logger = LoggerFactory.getLogger(ImageMagickHelper.class);

	/**
	 * 图片边缘凸起效果
	 * 
	 * @param srcImage
	 *            源图片
	 * @param raisePx
	 *            凸起像素
	 * @param destImage
	 *            目标图片
	 * @throws ScriptExecuteException
	 */
	public static void raiseImage(String srcImage, String raisePx, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-raise", raisePx, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 以图片为中心的漩涡效果
	 * 
	 * @param srcImage
	 *            源图片
	 * @param angle
	 *            漩涡的角度,负数反方向漩涡
	 * @param destImage
	 *            目标图片
	 * @throws ScriptExecuteException
	 */
	public static void swirlImage(String srcImage, int angle, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-swirl", "" + angle, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 炭笔画效果
	 * 
	 * @param srcImage
	 *            源图片
	 * @param level
	 *            炭笔画效果的程度，数值越大越黑转换也越慢，建议取值1-5
	 * @param destImage
	 *            目标图片
	 * @throws ScriptExecuteException
	 */
	public static void coalImage(String srcImage, int level, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-charcoal", "" + level, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 毛玻璃效果
	 * 
	 * @param srcImage
	 *            源图片
	 * @param level
	 *            毛玻璃效果的程度，数值越大越模糊 建议取值 0-100
	 * @param destImage
	 *            目标图片
	 * @throws ScriptExecuteException
	 */
	public static void spreadImage(String srcImage, int level, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-spread", "" + level, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 将图片旋转一定角度
	 * 
	 * @param srcImage
	 *            源图片
	 * @param angle
	 *            角度，负数为向左旋转
	 * @param destImage
	 *            目标图片
	 * @throws ScriptExecuteException
	 */
	public static void rorateImage(String srcImage, int angle, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-rotate", "" + angle, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 给图片加边框
	 * 
	 * @param srcImage
	 *            源图片
	 * @param color
	 *            边框颜色，ex：#000000
	 * @param framePx
	 *            边框像素
	 * @param destImage
	 *            目标文件
	 * @throws ScriptExecuteException
	 */
	public static void frameImage(String srcImage, String color, String framePx, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		AssertUtil.hasText(color);
		AssertUtil.hasText(framePx);
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(getCommand(pb, "convert"), "-mattecolor", "\"" + color + "\"", "-frame",
				framePx, srcImage, destImage);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 将多张图片合成一个pdf文件
	 * 
	 * @param srcImages
	 *            源文件集合
	 * @param destPdf
	 *            目标pdf文件
	 * @throws ScriptExecuteException
	 */
	public static void image2pdf(List<String> srcImages, String destPdf)
			throws ScriptExecuteException
	{
		AssertUtil.notEmpty(srcImages);
		AssertUtil.hasText(destPdf);
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		command.add(getCommand(pb, "convert"));
		for (String image : srcImages)
		{
			command.add(image);
		}
		command.add(destPdf);
		pb.command(command);
		ScriptTool.executeCommand(pb, null, null);
	}

	/**
	 * 图片格式转换，由文件后缀名确定格式
	 * 
	 * @param srcImage
	 *            源文件
	 * @param destImage
	 *            目标文件
	 * @throws ScriptExecuteException
	 */
	public static void convert(String srcImage, String destImage) throws ScriptExecuteException
	{
		convert(srcImage, null, destImage);
	}

	/**
	 * 图片格式转换，可以同时进行缩放（转换后会保持纵横比）
	 * 
	 * @param srcImage
	 *            源文件
	 * @param resizePx
	 *            转换后的像素
	 * @param destImage
	 *            目标文件
	 * @throws ScriptExecuteException
	 */
	public static void convert(String srcImage, String resizePx, String destImage)
			throws ScriptExecuteException
	{
		AssertUtil.hasText(srcImage);
		AssertUtil.hasText(destImage);
		ProcessBuilder pb = new ProcessBuilder();
		List<String> command = new ArrayList<String>();
		command.add(getCommand(pb, "convert"));
		if (StringTools.hasText(resizePx))
		{
			command.add("-sample");
			command.add(resizePx);// 像素或百分比，ex：80或25%
		}
		command.add(srcImage);
		command.add(destImage);
		pb.command(command);
		ScriptTool.executeCommand(pb, null, null);
	}

	protected static String getCommand(ProcessBuilder pb, String command)
	{
		if (SystemTools.IS_OS_WINDOWS)
		{
			Map<String, String> env = pb.environment();
			String magicHome = env.get("IMAGE_MAGICK_HOME");
			if (!StringTools.hasText(magicHome))
				throw new RuntimeException("请设置IMAGE_MAGICK_HOME环境变量");
			return magicHome + "\\" + command;
		}
		else
			return command;
	}
}
