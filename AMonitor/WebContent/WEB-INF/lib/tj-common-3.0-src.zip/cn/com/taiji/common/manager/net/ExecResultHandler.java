package cn.com.taiji.common.manager.net;

import java.io.File;

import cn.com.taiji.common.manager.net.exec.SshExecHelper;


/**
 * 命令执行结果的处理器
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-17 下午04:09:16
 * @since 1.0
 * @version 1.0
 * @see {@link SshExecHelper}
 */
public interface ExecResultHandler
{
	/**
	 * 命令执行结果存放于文件中，此方法处理此结果文件
	 * @param file
	 */
	public void handle(File file);
}
