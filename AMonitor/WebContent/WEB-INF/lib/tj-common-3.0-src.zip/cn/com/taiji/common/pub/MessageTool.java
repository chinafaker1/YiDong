package cn.com.taiji.common.pub;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-9-28 上午09:37:31
 * @since 1.0
 * @Version 1.0
 */
public abstract class MessageTool
{
	public static String getMessage(HttpServletRequest request, String code, Object[] args, String defaultMsg)
	{
		if (request == null) return "无法获取WebApplicationContext";
		HttpSession session = request.getSession();
		WebApplicationContext ac = WebApplicationContextUtils.getRequiredWebApplicationContext(session
				.getServletContext());
		String name = SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME;
		Locale locale = (Locale) session.getAttribute(name);
		return ac.getMessage(code, args, defaultMsg, locale);
	}

	public static String getMessage(HttpServletRequest request, String code, Object... args)
	{
		return getMessage(request, code, args, "未找到国际化定义");
	}
}
