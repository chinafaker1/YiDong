package cn.com.taiji.common.model;

import cn.com.taiji.common.entity.BaseEntity;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2008-2-25 上午11:01:03
 * @since 1.0
 * @version 1.0
 */
public abstract class BaseModel extends BaseEntity
{
	
}
