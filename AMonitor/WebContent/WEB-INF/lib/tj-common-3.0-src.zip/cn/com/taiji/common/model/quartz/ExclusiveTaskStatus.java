/*
 * Date: 2013-4-19
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-4-19 上午10:39:36<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class ExclusiveTaskStatus extends BaseModel
{
	private boolean running;
	private String nodeTag;

	public ExclusiveTaskStatus()
	{}

	public ExclusiveTaskStatus(boolean running, String nodeTag)
	{
		super();
		this.running = running;
		this.nodeTag = nodeTag;
	}

	public boolean isRunning()
	{
		return running;
	}

	public String getNodeTag()
	{
		return nodeTag;
	}

	public void setRunning(boolean running)
	{
		this.running = running;
	}

	public void setNodeTag(String nodeTag)
	{
		this.nodeTag = nodeTag;
	}

	public static ExclusiveTaskStatus fromJson(String jsonStr)
	{
		return fromJson(jsonStr, ExclusiveTaskStatus.class);
	}
}
