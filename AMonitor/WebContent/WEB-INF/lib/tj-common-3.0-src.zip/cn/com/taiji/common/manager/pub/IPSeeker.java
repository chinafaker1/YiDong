package cn.com.taiji.common.manager.pub;

import cn.com.taiji.common.model.pub.IPLocation;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-1-19 下午10:57:52<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.5
 * @version 1.0
 */
public interface IPSeeker
{

	/**
	 * 获取IP所在的地址(利用纯真IP地址数据库)
	 * 
	 * @param ip
	 *            ip地址
	 * @return IP所在的地区和国家
	 */
	public IPLocation getIPLocation(String ip);

	/**
	 * 停止IPSeeker,释放资源
	 */
	public void stop();

}