package cn.com.taiji.common.manager.quartz;

import java.util.Random;

import net.spy.memcached.CASResponse;
import net.spy.memcached.CASValue;
import net.spy.memcached.MemcachedClient;
import cn.com.taiji.common.model.quartz.ExclusiveTaskStatus;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * 通过memcached进行互斥的独占任务，同一时刻最多只有一个任务在运行<BR>
 * (适用于极端情况下能够容忍同时有2个以上任务同时运行的情况)
 * 
 * @author Peream <br>
 *         Create Time：2013-4-18 下午4:18:01<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class MemcachedExclusiveTask extends AbstractClusterRunnableProxy implements RunnableProxy
{
	private static final String KEY_PREFIX = "taiji_exclusive_task_";
	private final MemcachedClient client;
	private final int maxExecuteSeconds;// 放在memcached中的过期时间
	private final String key;

	public MemcachedExclusiveTask(final Runnable task, MemcachedClient client, String taskName)
	{
		this(task, client, taskName, 60 * 60);// 默认任务最多执行1个小时
	}

	/**
	 * 
	 * @param task
	 *            代理的任务
	 * @param client
	 *            memcached客户端
	 * @param taskName
	 *            任务名字，确保唯一
	 * @param maxExecuteSeconds
	 *            设置比任务运行的最长时间长一些，不要太长也不要太短.<br/>
	 *            太长：某个节点异常中止时，memcached中的running一直是true，造成后续定时任务丢失；<br/>
	 *            太短：任务还没执行完成，memcahced中的状态已经超时丢失,<br/>
	 *            其他节点再从memcached中取状态时会认为没有定时任务在运行而启动新的任务，<br/>
	 *            造成同一个时刻任务重复运行。不确定长短时，设定时间往长了设置，起码可以通过重起memcached恢复
	 */
	public MemcachedExclusiveTask(final Runnable task, MemcachedClient client, String taskName, int maxExecuteSeconds)
	{
		this(task, client, taskName, maxExecuteSeconds, null);
	}

	public MemcachedExclusiveTask(final Runnable task, MemcachedClient client, String taskName, int maxExecuteSeconds,
			TaskListener listener)
	{
		super(task, taskName, listener);
		AssertUtil.notNull(client);
		this.client = client;
		this.maxExecuteSeconds = maxExecuteSeconds;
		this.key = KEY_PREFIX + taskName;
	}

	public CASValue<Object> init()
	{
		CASValue<Object> value = client.gets(key);
		try
		{
			if (value == null)
			{
				// 通过一个简易的sleep机制，避免几个虚拟机之间同时调用init
				int ms = hashCode() % 500;
				Thread.sleep(ms);
				value = client.gets(key);
				if (value != null) return value;
				logger.info("value is null,init it to false first.");
				client.set(key, maxExecuteSeconds, new ExclusiveTaskStatus(false, nodeTag).toJson());
				ms = (ms * new Random().nextInt(216)) % 500;
				Thread.sleep(ms);
				value = client.gets(key);
				// 再次检查nodetag和刚才设置的是否一致，不一致时再次获取一次
				ExclusiveTaskStatus status = ExclusiveTaskStatus.fromJson(value.getValue().toString());
				if (!status.getNodeTag().equals(nodeTag))
				{
					value = client.gets(key);
					logger.info("value is modified by other node, re gets here:{}", value);
				}
			}
		}
		catch (InterruptedException e)
		{
			logger.error("", e);
		}
		return value;
	}

	@Override
	public void run()
	{
		CASValue<Object> value = init();
		logger.debug("casValue:{}", value);
		ExclusiveTaskStatus status = ExclusiveTaskStatus.fromJson(value.getValue().toString());
		if (status.isRunning() || taskRunning.get())
		{
			logger.info("{} 任务正在运行,本次任务调用忽略.", taskName);
			return;
		}
		try
		{
			// 修改memcached成功以后才会执行任务
			CASResponse res = client.cas(key, value.getCas(), maxExecuteSeconds,
					new ExclusiveTaskStatus(true, nodeTag).toJson(), client.getTranscoder());
			if (res == CASResponse.OK)
			{
				taskRunning.set(true);
				super.doTask();
			}
			else
				logger.info("本节点({})请求开始任务失败,不运行任务:{}", nodeTag, taskName);
		}
		finally
		{
			if (taskRunning.get())
			{
				taskRunning.set(false);
				client.set(key, maxExecuteSeconds, new ExclusiveTaskStatus(false, nodeTag).toJson());
			}
		}
	}

	public boolean isRunning()
	{
		if (taskRunning.get()) return true;
		CASValue<Object> casValue = client.gets(key);
		return casValue == null ? false : ExclusiveTaskStatus.fromJson(casValue.getValue().toString()).isRunning();
	}

	public int getMaxExecuteSeconds()
	{
		return maxExecuteSeconds;
	}

}