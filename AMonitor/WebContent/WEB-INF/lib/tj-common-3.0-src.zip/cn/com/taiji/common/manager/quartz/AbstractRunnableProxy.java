/*
 * Date: 2013年10月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.util.Calendar;
import java.util.concurrent.atomic.AtomicBoolean;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.CronTaskRunner;
import cn.com.taiji.common.model.quartz.TaskEvent;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年10月12日 下午5:32:23<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractRunnableProxy extends AbstractManager implements RunnableProxy
{
	protected final Runnable task;
	protected final String taskName;
	protected final TaskListener listener;
	protected CronTaskRunner taskRunner;
	protected AtomicBoolean taskRunning = new AtomicBoolean(false);

	protected AbstractRunnableProxy(Runnable task, String taskName, TaskListener listener)
	{
		AssertUtil.hasText(taskName);
		this.task = task;
		this.taskName = taskName;
		this.listener = listener;
	}

	protected final void doTask()
	{
		TaskEvent event = null;
		if (listener != null && taskRunner != null)
		{
			String tname = Thread.currentThread().getName();
			boolean bySystem = hasText(tname) ? tname.contains(taskRunner.getName()) : true;
			event = new TaskEvent(Calendar.getInstance(), taskName, bySystem, taskRunner.getCron().getExpression());
			listener.taskBegin(event);
		}
		else
		{
			logger.debug("listener is null or task({}) does not link to a taskRunner.", taskName);
		}
		task.run();
		if (listener != null && event != null)
		{
			event.setFinishTime(Calendar.getInstance());
			listener.taskFinish(event);
		}
	}

	@Override
	public CronTaskRunner getTaskRunner()
	{
		return this.taskRunner;
	}

	@Override
	public void setTaskRunner(CronTaskRunner taskRunner)
	{
		this.taskRunner = taskRunner;
	}

	@Override
	public String getTaskName()
	{
		return taskName;
	}

	@Override
	public Runnable getTask()
	{
		return task;
	}

	@Override
	public Object init()
	{
		return null;
	}
}
