package cn.com.taiji.common.pub;

import java.util.List;
import java.util.Map;

import org.springframework.util.ClassUtils;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-4 下午04:05:09
 * @since 1.0
 * @version 1.0
 */
public abstract class ClassTools extends ClassUtils
{
	public static <T> T cast(Object obj, Class<T> clazz)
	{
		return clazz.cast(obj);
	}

	@SuppressWarnings("unchecked")
	public static <E> List<E> castList(Object obj, Class<E> eleClass)
	{
		return List.class.cast(obj);
	}

	@SuppressWarnings("unchecked")
	public static <K, V> Map<K, V> castMap(Object obj, Class<K> keyClass, Class<V> valClass)
	{
		return Map.class.cast(obj);
	}
}
