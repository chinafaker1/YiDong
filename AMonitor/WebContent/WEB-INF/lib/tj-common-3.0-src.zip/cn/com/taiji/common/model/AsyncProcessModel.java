/*
 * Date: 2012-11-7
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-11-7 下午5:28:12<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class AsyncProcessModel extends AbstractAsyncModel {
	private double percent;
	private boolean running;
	private String msg;// 进度显示的信息

	public AsyncProcessModel() {
		super(AsyncProcessType.PROCESS);
	}

	public double getPercent() {
		return percent;
	}

	public void setPercent(double percent) {
		this.percent = percent;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
