/*
 * Date: 2011-10-31
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.dao;

/**
 * 结果转换
 * 
 * @author Peream <br>
 *         Create Time：2011-10-31 下午4:53:26<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see Pagination#convertResult(ResultConverter)
 */
public interface ResultConverter<F, T>
{
	public T convert(F from);
}
