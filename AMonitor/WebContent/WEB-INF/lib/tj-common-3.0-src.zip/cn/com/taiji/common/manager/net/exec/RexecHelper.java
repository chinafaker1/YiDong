package cn.com.taiji.common.manager.net.exec;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import org.apache.commons.net.bsd.RExecClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.net.ExecResultHandler;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.net.ExecTarget;
import cn.com.taiji.common.pub.AssertUtil;


/**
 * 远程在*nix上执行命令，如果服务器装有ssh，不建议使用本类的方法进行远程调用 <BR>
 * 服务器需要开启rexec服务(512)，同时由于通过rexec方式调用远程命令时，<BR>
 * 远程服务器会反向解析客户端的地址，故一般需要将客户端的IP加入到服务器的/etc/hosts文件中,<BR>
 * 否则调用方法无法执行.
 * 
 * @see {@link SshExecHelper}
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-18 下午02:43:41
 * @since 1.0
 * @version 1.0
 */
public abstract class RexecHelper
{
	protected Logger logger = LoggerFactory.getLogger(getClass());

	public static void execCmd(ExecTarget target, String cmd, ExecResultHandler handler)
			throws IOException
	{
		AssertUtil.notNull(target, "target can not be null.");
		AssertUtil.hasText(cmd, "cmd must has text");
		RExecClient client = new RExecClient();
		if (target.getTimeout() > 0) client.setDefaultTimeout(target.getTimeout());
		client.connect(target.getIp(), target.getPort());
		client.rexec(target.getUser(), target.getPass(), cmd);
		try
		{
			InputStream in = client.getInputStream();
			String uid = UUID.randomUUID().toString();
			File file = new File(FileHelper.getTmpPath() + "/rexecRs-" + uid + ".txt");
			FileOutputStream fos = new FileOutputStream(file);
			FileCopyUtils.copy(in, fos);
			if (handler != null) handler.handle(file);
		}
		finally
		{
			client.disconnect();
		}
	}
}
