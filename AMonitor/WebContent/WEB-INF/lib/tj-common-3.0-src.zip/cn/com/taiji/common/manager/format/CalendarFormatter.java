/*
 * Date: 2011-12-20
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.format;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.springframework.format.Formatter;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-20 下午2:51:03<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CalendarFormatter extends AbstractManager implements Formatter<Calendar>
{
	@Override
	public String print(Calendar object, Locale locale)
	{
		if (object == null) return "";
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(object.getTime());
	}

	@Override
	public Calendar parse(String text, Locale locale) throws ParseException
	{
		if (!StringTools.hasText(text)) return null;
		SimpleDateFormat normalDf = text.contains(":") ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				: new SimpleDateFormat("yyyy-MM-dd");
		normalDf.setLenient(false);
		Calendar c = Calendar.getInstance();
		c.setTime(normalDf.parse(text));
		return c;
	}

}
