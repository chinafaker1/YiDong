/*
 * Date: 2013-5-6
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.util.List;
import java.util.Map;

import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.model.quartz.CronTaskConfig;
import cn.com.taiji.common.model.quartz.CronTaskQueryModel;
import cn.com.taiji.common.model.quartz.CronTaskView;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-6 下午2:01:04<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface CronQuartzManager
{
	public List<CronTaskView> listAll();

	/**
	 * 按条件查询所有的定时器
	 * 
	 * @param qm
	 * @return
	 */
	public List<CronTaskView> listAll(CronTaskQueryModel qm);

	/**
	 * 分页查询定时器
	 * 
	 * @param qm
	 * @return
	 */
	public Pagination queryPage(CronTaskQueryModel qm);

	public CronTaskView findOne(String taskName);

	/**
	 * 设置所有任务
	 * 
	 * @param configs
	 * @see use {@link #addTaskConfig(CronTaskConfig)} instead.
	 */
	@Deprecated
	public void setTaskConfigs(Map<String, CronTaskConfig> configs);

	/**
	 * 增加任务
	 * 
	 * @param config
	 */
	public void addTaskConfig(CronTaskConfig config);

	public void removeTaskConfig(String taskName);

	public void updateTaskCron(String taskName, String cron);

	/**
	 * 指定任务对应的调度器是否在运行
	 * 
	 * @param taskName
	 * @return
	 */
	public boolean isRunning(String taskName);

	/**
	 * 指定的任务是否正在执行
	 * 
	 * @param taskName
	 * @return
	 */
	public boolean isTaskRunning(String taskName);

	/**
	 * 立即执行任务
	 * 
	 * @param taskName
	 * @throws ManagerException
	 */
	public void runTaskNow(String taskName) throws ManagerException;

	/**
	 * 启动指定任务的调度器
	 * 
	 * @param taskName
	 */
	public void start(String taskName) throws Exception;

	/**
	 * 停止指定任务的调度器
	 * 
	 * @param taskName
	 */
	public void stop(String taskName);

	/**
	 * 初始化，验证及开启所有调度器
	 */
	public void init() throws Exception;

	/**
	 * 销毁所有调度器
	 */
	public void destory();
}
