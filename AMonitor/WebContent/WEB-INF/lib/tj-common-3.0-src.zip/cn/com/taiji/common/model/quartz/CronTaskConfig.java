/*
 * Date: 2013-5-6
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import org.springframework.util.ErrorHandler;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.com.taiji.common.manager.quartz.RunnableProxy;
import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-6 下午2:02:07<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link CronTaskView}
 */
public class CronTaskConfig extends BaseModel
{
	private RunnableProxy task;
	private boolean stopImmediate = true;
	private String cron;
	private boolean invokeTaskAfterStart = false;
	private ErrorHandler errorHandler;
	private boolean autoStart = true;// 默认自动开启
	private String type;// 定时器的分类，用于查询一组类型时比较方便
	private String info;// 备注

	@JsonIgnore
	public ErrorHandler getErrorHandler()
	{
		return errorHandler;
	}

	public void setErrorHandler(ErrorHandler errorHandler)
	{
		this.errorHandler = errorHandler;
	}

	@JsonIgnore
	public RunnableProxy getTask()
	{
		return task;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public boolean isAutoStart()
	{
		return autoStart;
	}

	public void setAutoStart(boolean autoStart)
	{
		this.autoStart = autoStart;
	}

	public String getInfo()
	{
		return info;
	}

	public void setInfo(String info)
	{
		this.info = info;
	}

	public boolean isStopImmediate()
	{
		return stopImmediate;
	}

	public String getCron()
	{
		return cron;
	}

	public boolean isInvokeTaskAfterStart()
	{
		return invokeTaskAfterStart;
	}

	public void setTask(RunnableProxy task)
	{
		this.task = task;
	}

	public void setStopImmediate(boolean stopImmediate)
	{
		this.stopImmediate = stopImmediate;
	}

	public void setCron(String cron)
	{
		this.cron = cron;
	}

	public void setInvokeTaskAfterStart(boolean invokeTaskAfterStart)
	{
		this.invokeTaskAfterStart = invokeTaskAfterStart;
	}

}
