/*
 * Date: 2013-2-24
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.zip.GZIPOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.manager.pub.AbstractHelper;
import cn.com.taiji.common.manager.pub.ZipHelper;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.FileCopyTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-2-24 下午8:23:38<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class HttpMimeResponseHelper extends AbstractHelper
{
	protected static Logger logger = LoggerFactory.getLogger(HttpMimeResponseHelper.class);
	private static final int MAX_MEM_SIZE = 1024 * 1024 * 16;// 16M

	public static void responseJson(String jsonStr, final HttpServletResponse response) throws IOException
	{
		setJsonResponseHeader(response);
		response.getWriter().print(jsonStr);
	}

	/**
	 * 会根据客户端判断是否支持gzip而启动gzip
	 * 
	 * @param jsonStr
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static void responseJson(String jsonStr, HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		boolean supportGzip = isClientSupportGzip(request);
		if (supportGzip) response.setHeader("Content-Encoding", "gzip");
		PrintWriter writer = supportGzip ? new PrintWriter(new BufferedWriter(new OutputStreamWriter(
				new GZIPOutputStream(response.getOutputStream()), "UTF-8"))) : response.getWriter();
		setJsonResponseHeader(response);
		writer.print(jsonStr);
		writer.close();
	}

	private static boolean isClientSupportGzip(HttpServletRequest request)
	{
		String headEncoding = request.getHeader("Accept-Encoding");
		boolean supportGzip = headEncoding != null && (headEncoding.toLowerCase().indexOf("gzip") != -1);
		return supportGzip;
	}

	private static void setJsonResponseHeader(HttpServletResponse response)
	{
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "No-cache");
		response.setHeader("Expires", "0");
		response.setContentType("application/json");
	}

	public static void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final InputStream stream, String displayName, boolean enableGzip) throws IOException
	{
		AssertUtil.notNull(stream, "被下载的文件流不能为空");
		setDownloadHeader(request, response, displayName);
		OutputStream output = null;
		InputStream fis = null;
		try
		{
			fis = stream;
			output = response.getOutputStream();
			boolean useGzip = enableGzip && isClientSupportGzip(request);
			int size = fis.available();
			if (useGzip)
			{
				response.setHeader("Content-Encoding", "gzip");
				if (size <= MAX_MEM_SIZE)
				{
					byte[] bytes = ZipHelper.gzip(FileCopyTools.copyToByteArray(fis));
					response.setContentLength(bytes.length);// 压缩后的长度
					fis = new ByteArrayInputStream(bytes);
				}
				else
				{
					output = new GZIPOutputStream(response.getOutputStream());
				}
			}
			else
			{
				response.setContentLength(size);
			}
			byte[] b = new byte[BUFFER];
			int i = 0;
			while ((i = fis.read(b)) > 0)
			{
				output.write(b, 0, i);
			}
			output.flush();
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
				fis = null;
			}
			if (output != null)
			{
				output.close();
				output = null;
			}
		}
	}

	private static void setDownloadHeader(HttpServletRequest request, HttpServletResponse response, String displayName)
			throws IOException
	{
		AssertUtil.hasText(displayName, "显示名称必须指定");
		String ua = request.getHeader("user-agent"); // 获取终端类型
		if (ua == null) ua = " User-Agent: Mozilla/4.0 (compatible; MSIE 6.0;) ";
		boolean isIE = ua.toLowerCase().indexOf(" msie ") != -1;

		response.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "must-revalidate,post-check=0,pre-check=0");
		response.setContentType("application/octet-stream;charset=ISO8859-1");
		if (isIE) response.setContentType("application/x-download");// 设置为下载application/x-download
		// 解决中文乱码
		response.setHeader("Content-Disposition", "attachment;filename="
				+ new String(displayName.getBytes("GBK"), "ISO8859-1"));
	}

	public static void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final InputStream stream, String displayName) throws IOException
	{
		doDownLoad(request, response, stream, displayName, false);
	}

	public static void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final String content, String displayName) throws IOException
	{
		AssertUtil.hasText(content);
		doDownLoad(request, response, new ByteArrayInputStream(content.getBytes()), displayName);
	}

	public static void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final File file, String displayName) throws IOException
	{
		doDownLoad(request, response, new FileInputStream(file), displayName);
	}

	public static void doShowPic(HttpServletResponse response, final InputStream in) throws IOException
	{
		AssertUtil.notNull(in, "图片文件流不能为空");
		response.setContentType("image/jpeg");
		OutputStream output = null;
		InputStream fis = null;
		try
		{
			output = response.getOutputStream();
			fis = in;
			byte[] b = new byte[BUFFER];
			int i = 0;
			while ((i = fis.read(b)) > 0)
			{
				output.write(b, 0, i);
			}
			output.flush();
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
		finally
		{
			if (fis != null)
			{
				fis.close();
				fis = null;
			}
			if (output != null)
			{
				output.close();
				output = null;
			}
		}
	}
}
