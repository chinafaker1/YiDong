/*
 * Date: 2011-11-7
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import org.apache.poi.ss.usermodel.Workbook;

/**
 * 对workbook进行数据填充的回调接口，改用poi方式
 * 
 * @author Peream <br>
 *         Create Time：2011-11-7 下午2:17:12<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 2.0
 * @version 1.0
 */
public interface WorkbookHandler
{
	/**
	 * 填充excel的内容
	 * 
	 * @param workbook
	 *            待填充数据的excel
	 * @param template
	 *            模板excel
	 * @throws Exception
	 */
	public void fillWorkbook(Workbook workbook) throws Exception;
}
