package cn.com.taiji.common.manager.net.helper;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.net.ftp.FTPFile;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-24 下午01:03:59
 * @since 1.0
 * @version 1.0
 */
public class FtpFileNameComparator implements Comparator<FTPFile>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4494290862256339280L;
	private boolean desc;

	public FtpFileNameComparator()
	{
		this.desc = false;
	}

	public FtpFileNameComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(FTPFile o1, FTPFile o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null || o1.getName() == null) return desc ? 1 : -1;
		if (o2 == null || o2.getName() == null) return desc ? -1 : 1;
		if (desc) return o2.getName().compareToIgnoreCase(o1.getName());
		return o1.getName().compareToIgnoreCase(o2.getName());
	}

}
