package cn.com.taiji.common.pub;

import org.springframework.beans.BeanUtils;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-4 下午04:02:12
 * @since 1.0
 * @version 1.0
 */
public abstract class BeanTools extends BeanUtils
{

}
