package cn.com.taiji.common.pub;

import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:20:29
 * @since 1.0
 * @Version 1.0
 */
public abstract class WebDebugUtil
{
	protected static Logger logger = LoggerFactory.getLogger(WebDebugUtil.class);

	public static void echoRequestInfo(HttpServletRequest request)
	{
		if (!logger.isDebugEnabled()) return;
		System.out.println("\n=======Request INfo start =================");
		System.out.println("authType=" + request.getAuthType());
		System.out.println("characterEncoding=" + request.getCharacterEncoding());
		System.out.println("contentLength=" + request.getContentLength());
		System.out.println("contentType=" + request.getContentType());
		System.out.println("contextPath=" + request.getContextPath());
		System.out.println("localAddr=" + request.getLocalAddr());
		System.out.println("localName=" + request.getLocalName());
		System.out.println("localPort=" + request.getLocalPort());
		System.out.println("Locale=" + request.getLocale());
		System.out.println("Method=" + request.getMethod());
		System.out.println("pathInfo=" + request.getPathInfo());
		System.out.println("pathTranslated=" + request.getPathTranslated());
		System.out.println("requestURL=" + request.getRequestURL());
		System.out.println("parameterMap=" + request.getParameterMap());
		System.out.println("queryString=" + request.getQueryString());
		System.out.println("remoteAddr=" + request.getRemoteAddr());
		System.out.println("remoteUser=" + request.getRemoteUser());
		System.out.println("remoteHost=" + request.getRemoteHost());
		System.out.println("remotePort=" + request.getRemotePort());
		System.out.println("requestURI=" + request.getRequestURI());
		System.out.println("isRequestedSessionIdFromCookie=" + request.isRequestedSessionIdFromCookie());
		System.out.println("isRequestedSessionIdFromURL=" + request.isRequestedSessionIdFromURL());
		System.out.println("isRequestedSessionIdValid=" + request.isRequestedSessionIdValid());
		System.out.println("==========Request INfo end =================\n");
	}

	public static void echoAclRequestInfo(HttpServletRequest request)
	{
		if (!logger.isDebugEnabled()) return;
		System.out.println("=======Acl Request INfo start =================");
		System.out.println("requestURL=" + request.getRequestURL());
		System.out.println("contextPath=" + request.getContextPath());
		System.out.println("requestURI=" + request.getRequestURI());
		System.out.println("==========Acl Request INfo end =================\n");
	}

	public static void echoResponseInfo(HttpServletResponse response)
	{
		if (!logger.isDebugEnabled()) return;
		System.out.println("\n=======Reponse INfo start =================");
		System.out.println("characterEncoding=" + response.getCharacterEncoding());
		System.out.println("contentType=" + response.getContentType());
		System.out.println("Locale=" + response.getLocale());
		System.out.println("==========Reponse INfo end =================\n");
	}

	public static void echoSessionInfo(HttpSession session)
	{
		if (!logger.isDebugEnabled()) return;
		System.out.println("\n=======Session INfo start =================");
		System.out.println("MaxInactiveInterval=" + session.getMaxInactiveInterval());
		System.out.println("CreationTime=" + new Date(session.getCreationTime()));
		System.out.println("LastAccessedTime=" + new Date(session.getLastAccessedTime()));
		System.out.println("id=" + session.getId());
		Enumeration<?> en = session.getAttributeNames();
		if (!en.hasMoreElements()) return;
		System.out.println("\n=======Session 属性值 =================");
		while (en.hasMoreElements())
		{
			String name = (String) en.nextElement();
			Object value = session.getAttribute(name);
			if (value instanceof Calendar) value = ((Calendar) value).getTime();
			System.out.println("属性" + name + "的值为:" + value);
		}
		System.out.println("==========Session INfo end =================\n");
	}

	public static void echoRequestParams(HttpServletRequest request)
	{
		if (!logger.isDebugEnabled()) return;
		Map<String, String[]> params = request.getParameterMap();
		if (params.isEmpty()) return;
		String uri = request.getRequestURI();
		String method = request.getMethod();
		System.out.println("=======(" + uri + "\t" + method + ")参数列表 begin========================");
		for (Entry<String, String[]> en : params.entrySet())
		{
			if (ObjectTools.isEmpty(en.getValue())) continue;
			StringBuilder value = new StringBuilder();
			for (String str : en.getValue())
				value.append(str).append("\t");
			System.out.println("参数 " + en.getKey() + "的值为:" + value.toString());
		}
		System.out.println("=======(" + uri + "\t" + method + ")参数列表 end========================");
	}
}
