package cn.com.taiji.common.manager.net.nio;

import java.io.IOException;
import java.util.concurrent.Executor;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.xsocket.connection.IServer;
import org.xsocket.connection.Server;

import cn.com.taiji.common.manager.AbstractManager;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-15 下午01:40:14
 * @since 1.0
 * @version 1.0
 */
public class NioServerImpl extends AbstractManager implements NioServer
{
	private IServer server;
	private NioServerHandler handler;
	private final int port;
	private Executor workerpool;

	public NioServerImpl(int port)
	{
		this(port, null);
	}

	public NioServerImpl(int port, NioServerHandler handler)
	{
		this(port, handler, null);
	}

	public NioServerImpl(int port, NioServerHandler handler, Executor workerpool)
	{
		this.port = port;
		this.handler = handler;
		this.workerpool = workerpool;
	}

	public boolean isRunning()
	{
		return server == null ? false : server.isOpen();
	}

	@PostConstruct
	public synchronized void start() throws Exception
	{
		if (isRunning())
		{
			logger.info("nio server has already start~");
			return;
		}
		server = new Server(port, handler);
		if (workerpool != null) server.setWorkerpool(workerpool);
		server.start();
		logger.info("Start nio server success:{},listening at {}", server.isOpen(), port);
	}

	@PreDestroy
	public synchronized void stop()
	{
		try
		{
			if (server != null) server.close();
			logger.info("Close nio server success,port:{}", port);
		}
		catch (IOException e)
		{
			logger.error("", e);
		}
	}

	public void setHandler(NioServerHandler handler)
	{
		this.handler = handler;
	}

}
