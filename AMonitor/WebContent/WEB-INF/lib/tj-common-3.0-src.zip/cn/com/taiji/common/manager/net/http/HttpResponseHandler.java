/*
 * Date: 2011-9-16
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import org.apache.http.HttpResponse;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-9-16 下午3:18:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface HttpResponseHandler<T>
{
	public T handle(HttpResponse response) throws IOException;
}
