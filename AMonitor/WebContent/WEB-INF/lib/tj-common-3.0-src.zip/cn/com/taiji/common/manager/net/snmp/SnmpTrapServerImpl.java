package cn.com.taiji.common.manager.net.snmp;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午08:43:26
 * @since 1.0
 * @version 1.0
 */
public class SnmpTrapServerImpl extends AbstractManager implements SnmpTrapServer, CommandResponder
{
	private AtomicBoolean running = new AtomicBoolean(false);
	private Snmp snmp;
	private final int port;
	private SnmpTrapServerHandler handler;

	public SnmpTrapServerImpl(int port)
	{
		this.port = port;
	}

	public boolean isRunning()
	{
		return running.get();
	}

	@PostConstruct
	public synchronized void start() throws IOException
	{
		if (running.get())
		{
			logger.info("SnmpTrapServer is already running.");
			return;
		}
		TransportMapping transport = new DefaultUdpTransportMapping(new UdpAddress("0.0.0.0/" + port));
		snmp = new Snmp(transport);
		snmp.addCommandResponder(this);
		snmp.listen();
		running.set(true);
		logger.info("Start listening snmp trap,Port:", port);
	}

	@PreDestroy
	public synchronized void stop() throws IOException
	{
		if (!running.get())
		{
			logger.info("SnmpTrapServer is already stoped.");
			return;
		}
		try
		{
			snmp.close();
			logger.info("Stop listening snmp trap,Port:", port);
		}
		finally
		{
			running.set(false);
		}
	}

	public void processPdu(CommandResponderEvent event)
	{
		PDU msg = event.getPDU();
		if (msg == null)
		{
			logger.warn("can not get pdu from event.");
			return;
		}
		handler.handle(msg);
	}

	public void setHandler(SnmpTrapServerHandler handler)
	{
		this.handler = handler;
	}

}
