package cn.com.taiji.common.manager;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-3 下午04:17:46
 * @since 1.0
 * @version 1.0
 */
public interface LifecycleService
{
	/**
	 * 服务是否运行
	 * 
	 * @return 服务运行状态
	 */
	public boolean isRunning();

	/**
	 * 启动服务
	 * 
	 * @throws Exception 启动服务失败抛出的异常
	 */
	public void start() throws Exception;

	/**
	 * 停止服务
	 */
	public void stop();
}
