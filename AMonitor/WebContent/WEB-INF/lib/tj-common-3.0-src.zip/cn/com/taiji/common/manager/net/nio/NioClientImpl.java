package cn.com.taiji.common.manager.net.nio;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.xsocket.connection.INonBlockingConnection;
import org.xsocket.connection.NonBlockingConnection;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.net.nio.NioProtocol;
import cn.com.taiji.common.pub.AssertUtil;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-22 下午04:53:30
 * @since 1.0
 * @version 1.0
 */
public class NioClientImpl extends AbstractManager implements NioClient
{
	private String hostname = "127.0.0.1";
	private int port = 7616;
	private NioClientHandler handler;

	private int statusCheckInterval = 30;// 连接检测间隔,秒
	private INonBlockingConnection connection;
	private ExecutorService executor;
	private volatile boolean stop;
	private volatile boolean running;
	private Object lock = new Object();

	public NioClientImpl(String hostname, int port, NioClientHandler handler)
	{
		this.hostname = hostname;
		this.port = port;
		AssertUtil.notNull(handler, "handler must specified.");
		this.handler = handler;
	}

	public void run()
	{
		try
		{
			logger.info("Start client connection check thread.");
			while (!stop)
			{
				TimeUnit.SECONDS.sleep(statusCheckInterval);
				try
				{
					autoReconnect();
					// 连接维护用:先看看xsocket有没有合适的方法，没有的话考虑在hanler中加方法
					// sendRequest(new StatusProtocol());
				}
				catch (IOException e)
				{
					String error = "自动重连至 " + hostname + " 失败," + statusCheckInterval + "秒后将再次尝试.";
					logger.error(error, e);
				}
			}
			logger.info("Stop client connection check thread.");
		}
		catch (InterruptedException e)
		{
			logger.info("Catch interuppt exception~");
			stop = true;
		}
	}

	public boolean isConnected()
	{
		return connection == null ? false : connection.isOpen();
	}

	public void autoReconnect() throws IOException
	{
		// 同步块外进行判断，连接正常的情况下不会进入到同步块。
		if (isConnected()) return;
		synchronized (lock)
		{
			// 如果不进行判断，并发调用本方法时会重复进行连接
			if (isConnected()) return;
			logger.info("连接断开，重新进行连接...");
			connection = new NonBlockingConnection(hostname, port, handler);
		}
	}

	public INonBlockingConnection getConnection() throws IOException
	{
		autoReconnect();
		return connection;
	}

	public void sendRequest(NioProtocol protocol) throws IOException
	{
		getConnection().write(protocol.toProtocolString());
	}

	@PostConstruct
	public synchronized void start()
	{
		if (running)
		{
			logger.info("already start,return");
			return;
		}
		executor = Executors.newSingleThreadExecutor();
		executor.execute(this);
		running = true;
		// 将client给handler用
		handler.setClient(this);
		try
		{
			connection = new NonBlockingConnection(hostname, port, handler);
		}
		catch (IOException e)
		{
			logger.error("can not connect to " + hostname, e);
		}
	}

	@PreDestroy
	public synchronized void stop()
	{
		try
		{
			if (executor != null)
			{
				stop = true;
				executor.shutdownNow();
				Thread.yield();
			}
			if (connection != null) connection.close();
		}
		catch (IOException e)
		{
			logger.error("", e);
		}
		finally
		{
			connection = null;
			executor = null;
			running = false;
		}
	}

	public void setStatusCheckInterval(int statusCheckInterval)
	{
		this.statusCheckInterval = statusCheckInterval;
	}

}
