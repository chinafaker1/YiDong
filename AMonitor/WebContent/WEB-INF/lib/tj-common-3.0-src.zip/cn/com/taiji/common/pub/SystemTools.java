package cn.com.taiji.common.pub;

import org.apache.commons.lang3.SystemUtils;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-30 下午06:13:39
 * @since 1.0
 * @version 1.0
 */
public abstract class SystemTools extends SystemUtils
{

}
