/*
 * Date: 2014年1月25日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;

import cn.com.taiji.common.manager.AbstractManager;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年1月25日 上午10:46:34<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractReadRowAsStringHandler<E> extends AbstractManager implements ExcelReadRowHandler<E>
{

	public final E row2Model(int row, Map<Integer, Cell> rowData)
	{
		Map<Integer, String> rs = new HashMap<Integer, String>();
		for (Entry<Integer, Cell> en : rowData.entrySet())
		{
			Cell cell = en.getValue();
			if (cell == null)
				rs.put(en.getKey(), "");
			else
			{
				cell.setCellType(Cell.CELL_TYPE_STRING);
				rs.put(en.getKey(), cell.getStringCellValue());
			}
		}
		return strRow2Model(row, rs);
	}

	protected abstract E strRow2Model(int row, Map<Integer, String> rowData);
}
