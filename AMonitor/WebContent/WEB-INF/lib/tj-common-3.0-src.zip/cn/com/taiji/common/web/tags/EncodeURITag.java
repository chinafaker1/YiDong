/*
 * Date: 2014年1月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web.tags;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年1月12日 下午1:51:56<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class EncodeURITag
{
	public static String encodeURI(String uri) throws UnsupportedEncodingException
	{
		return URLEncoder.encode(uri, "UTF-8");
	}
}
