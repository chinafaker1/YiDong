package cn.com.taiji.common.model.net;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:08:38
 * @since 1.0
 * @version 1.0
 */
public class BaseTarget extends BaseModel
{
	protected String ip = "127.0.0.1";
	// 162forsnmp 514for syslog
	protected int port = 162;

	public BaseTarget()
	{

	}

	public BaseTarget(String ip, int port)
	{
		this.ip = ip;
		this.port = port;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}
}
