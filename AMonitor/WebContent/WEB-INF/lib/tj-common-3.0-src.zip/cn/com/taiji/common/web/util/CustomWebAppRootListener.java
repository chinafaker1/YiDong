/*
 * Date: 2011-7-18
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web.util;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-7-18 上午10:59:31<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CustomWebAppRootListener implements ServletContextListener
{
	@Override
	public void contextInitialized(ServletContextEvent sce)
	{
		AssertUtil.notNull(sce.getServletContext());
		String param = sce.getServletContext().getInitParameter(WebTools.WEB_APP_ROOT_KEY_PARAM);
		String key = (param != null ? param : WebTools.DEFAULT_WEB_APP_ROOT_KEY);
		param = sce.getServletContext().getInitParameter(WebTools.WEB_APP_ROOT_PATH_PARAM);
		if (!StringTools.hasText(param)) throw new RuntimeException("必须指定webAppRootPath的值.");
		System.setProperty(key, param);
		sce.getServletContext().log(
				"Set web app root system property: '" + key + "' = [" + param + "]");
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce)
	{
		AssertUtil.notNull(sce.getServletContext());
		String param = sce.getServletContext().getInitParameter(WebTools.WEB_APP_ROOT_KEY_PARAM);
		String key = (param != null ? param : WebTools.DEFAULT_WEB_APP_ROOT_KEY);
		System.getProperties().remove(key);
	}

}
