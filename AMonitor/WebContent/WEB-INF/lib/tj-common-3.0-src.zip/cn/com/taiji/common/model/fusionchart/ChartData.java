package cn.com.taiji.common.model.fusionchart;

import java.util.LinkedHashMap;
import java.util.Map;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;

public class ChartData extends BaseModel
{
	private String label;// 数据单元的名字
	private String value;// 数值
	private String color;// 每个数据单元的名字，可选，如要求每个柱子的颜色不一样

	public String getLabel()
	{
		return label;
	}

	public ChartData setLabel(String label)
	{
		this.label = label;
		return this;
	}

	public String getValue()
	{
		return value;
	}

	public ChartData setValue(String value)
	{
		this.value = value;
		return this;
	}

	public String getColor()
	{
		return color;
	}

	public ChartData setColor(String color)
	{
		this.color = color;
		return this;
	}

	public String toChartJson()
	{
		return null;
	}

	public static ChartData newInstance(String label, String value)
	{
		ChartData chartData = new ChartData();
		chartData.setLabel(label);
		chartData.setValue(value);
		return chartData;
	}

	public static ChartData newInstance(String label, String value, String color)
	{
		ChartData chartData = new ChartData();
		chartData.setLabel(label);
		chartData.setValue(value);
		chartData.setColor(color);
		return chartData;
	}

	public Map<String, String> toChartDataMap()
	{
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("label", label);
		map.put("value", value);
		if (StringTools.hasText(color)) map.put("color", color);
		return map;
	}

}
