/*
 * Date: 2012-9-27
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import cn.com.taiji.common.manager.quartz.RunnableProxy;
import cn.com.taiji.common.model.AsyncProcessModel;
import cn.com.taiji.common.model.AsyncSucessModel;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-9-27 上午11:20:12<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class BaseAsyncController<E> extends JsonValidController {
	private final RunnableProxy task;

	protected BaseAsyncController(RunnableProxy task) {
		this.task = task;
		AssertUtil.notNull(task);
	}

	protected abstract ThreadPoolTaskExecutor getExecutor();

	public final boolean isRunning() {
		return task.isRunning();
	}

	/**
	 * percent==0返回startmodel（预留），percent==1返回successModel
	 * 
	 * @param request
	 * @param response
	 * @param msg
	 * @param percent
	 * @throws IOException
	 * @see {@link #getSucessResult()}
	 */
	protected final void responseProcess(HttpServletRequest request,
			HttpServletResponse response, String msg, double percent)
			throws IOException {
		if (percent < 0)
			throw new RuntimeException("不是有效的进度数值." + percent);
		if (percent == 1) {
			AsyncSucessModel<E> rs = new AsyncSucessModel<E>();
			rs.setMsg(msg);
			rs.setTime(Calendar.getInstance());
			rs.setResult(getSucessResult());
			responseJson(rs.toJson(), request, response);
			return;
		}
		AsyncProcessModel model = new AsyncProcessModel();
		model.setMsg(msg);
		model.setRunning(isRunning());
		model.setPercent(percent);
		responseJson(model.toJson(), request, response);
	}

	/**
	 * 可以通过覆盖本方法得到返回值
	 * 
	 * @return
	 */
	protected E getSucessResult() {
		return null;
	}

	protected final void asyncDoTask() {
		getExecutor().execute(task);
	}
}
