package cn.com.taiji.common.pub;

import java.io.File;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.model.pub.MyEth;


/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-7-25 下午04:18:10
 * @since 1.0
 * @Version 1.0
 */
public class ProjectEnv
{
	protected static Logger logger = LoggerFactory.getLogger(ProjectEnv.class);
	private static String workingPath = null;
	private static volatile boolean isWin = false;
	private static String pathWEBINF = null;
	public static String webappPath = null;
	private static String confPath;
	private static String tmpPath;
	private static String dataPath;
	private static String toolPath;
	private static String eth;
	private static String serverIp;
	private static Object lock = new Object();

	public ProjectEnv()
	{
		setEth("eth0");
	}

	public ProjectEnv(String eth)
	{
		setEth(eth);
	}

	public ProjectEnv(String eth, String webappPath)
	{
		setEth(eth);
		setWebappPath(webappPath);
	}

	public static String getEth0IP()
	{
		return getLocalIP("eth0");
	}

	public static String getIpByConf()
	{
		if (serverIp == null && eth != null)
		{
			synchronized (lock)
			{
				serverIp = getLocalIP(eth);
			}
		}
		if (serverIp == null) return "127.0.0.1";
		return serverIp;
	}

	/**
	 * 获取所有eth网络接口
	 * 
	 * @return
	 * @throws SocketException
	 */
	public static List<MyEth> getAllEthIf() throws SocketException
	{
		Enumeration<NetworkInterface> eths = NetworkInterface.getNetworkInterfaces();
		List<MyEth> result = new ArrayList<MyEth>();
		while (eths.hasMoreElements())
		{
			NetworkInterface netInterface = eths.nextElement();
			String ifName = netInterface.getName();
			if (!ifName.contains("eth")) continue;
			MyEth myIf = new MyEth();
			myIf.setName(ifName);
			// get ip
			Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
			while (addresses.hasMoreElements())
			{
				InetAddress netAddress = addresses.nextElement();
				if (netAddress instanceof Inet4Address)
				{
					String ip = netAddress.getHostAddress();
					myIf.setIp(ip);
					break;
				}
			}
			result.add(myIf);
		}
		return result;
	}

	public static String getLocalIP(String eth)
	{
		if (eth == null) return "127.0.0.1";
		String ip = "127.0.0.1";
		try
		{
			NetworkInterface netInterface = NetworkInterface.getByName(eth);
			if (netInterface != null)
			{
				Enumeration<InetAddress> en = netInterface.getInetAddresses();
				while (en.hasMoreElements())
				{
					InetAddress netAddress = en.nextElement();
					if (netAddress instanceof Inet4Address)
					{
						ip = netAddress.getHostAddress();
						break;
					}
				}
			}
		}
		catch (SocketException e)
		{
			logger.error(e.getMessage(), e);
		}
		return ip;
	}

	public static String getWorkingPath()
	{
		if (workingPath == null)
		{
			try
			{
				workingPath = new File("").getCanonicalPath();
			}
			catch (IOException e)
			{
				logger.error(e.getMessage(), e);
			}
		}
		return workingPath;
	}

	/**
	 * 
	 * @return
	 */
	public static String getWEBINFRealPath()
	{
		if (pathWEBINF == null)
		{
			pathWEBINF = getWebappPath() + "/WEB-INF";
			pathWEBINF = pathWEBINF.replaceAll("//", "/");
			logger.info("WEB-INF path = {}", pathWEBINF);
		}
		return pathWEBINF;
	}

	/**
	 * 
	 * @return
	 */
	public static String getWebappPath()
	{
		if (StringTools.hasText(webappPath) && !webappPath.contains("${"))
		{
			webappPath = webappPath.replace("\\", "/");
			return webappPath;
		}
		String classPath = getClassPath();
		String[] splits = classPath.split("WEB-INF");
		webappPath = splits[0];
		logger.info("webappPath={}", webappPath);
		return webappPath;
	}

	public void setWebappPath(String webappPath)
	{
		logger.info("Set webapp path:{}", webappPath);
		initWebappPath(webappPath);
		init();
	}

	private static void initWebappPath(String webappPath)
	{
		ProjectEnv.webappPath = webappPath;
		// 清除原有的路径，重新获取生效
		pathWEBINF = null;
		confPath = null;
		tmpPath = null;
		dataPath = null;
		toolPath = null;
	}

	/**
	 * 
	 * @return
	 */
	public static String getConfPath()
	{
		if (confPath == null)
		{
			synchronized (lock)
			{
				confPath = new StringBuilder(getWEBINFRealPath()).append("/conf").toString();
			}
			logger.info("confPath={}", confPath);
			mkdirs(confPath);
		}
		return confPath;
	}

	public static String getTmpPath()
	{
		if (tmpPath == null)
		{
			synchronized (lock)
			{
				tmpPath = new StringBuilder(getWebappPath()).append("/tmp").toString();
				tmpPath = tmpPath.replaceAll("//", "/");
			}
			logger.info("tmpPath={}", tmpPath);
			mkdirs(tmpPath);
		}
		return tmpPath;
	}

	public static String getDataPath()
	{
		if (dataPath == null)
		{
			synchronized (lock)
			{
				dataPath = new StringBuilder(getWebappPath()).append("/data").toString();
				dataPath = dataPath.replaceAll("//", "/");
			}
			logger.info("dataPath={}", dataPath);
			mkdirs(dataPath);
		}
		return dataPath;
	}

	public static String getToolPath()
	{
		if (toolPath == null)
		{
			synchronized (lock)
			{
				toolPath = new StringBuilder(getWebappPath()).append("/tool").toString();
				toolPath = toolPath.replaceAll("//", "/");
			}
			logger.info("toolPath={}", toolPath);
			mkdirs(toolPath);
		}
		return toolPath;
	}

	public static void setEth(String eth)
	{
		ProjectEnv.eth = eth;
	}

	public static void mkdirs(String path)
	{
		File file = new File(path);
		if (!(file.exists() && file.isDirectory()))
		{
			synchronized (lock)
			{
				if (file.exists() && file.isDirectory()) return;
				boolean result = file.mkdirs();
				if (!result)
					throw new RuntimeException("创建文件夹失败,请查看application server权限设置path = " + path);
			}
		}
	}

	private static synchronized String getClassPath()
	{
		String strClassName = ProjectEnv.class.getName();
		String strClassFileName = strClassName.substring(strClassName.lastIndexOf(".") + 1,
				strClassName.length());
		URL url = null;
		url = ProjectEnv.class.getResource(strClassFileName + ".class");
		String strURL = url.toString();
		strURL = strURL.substring(strURL.indexOf('/') + 1);
		isWin = false;
		int index = strURL.indexOf(":/");
		if (index > 0) isWin = true;
		logger.info("Raw ProjectEnv path = {}", strURL);
		if (!isWin) return "/" + strURL;
		return strURL;
	}

	@PostConstruct
	public void init()
	{
		getWebappPath();
		getWEBINFRealPath();
		getConfPath();
		getTmpPath();
		getDataPath();
		getToolPath();
	}

}
