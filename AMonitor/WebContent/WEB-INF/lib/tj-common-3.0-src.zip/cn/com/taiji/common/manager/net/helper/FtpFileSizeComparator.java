package cn.com.taiji.common.manager.net.helper;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.net.ftp.FTPFile;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-24 下午12:58:29
 * @since 1.0
 * @version 1.0
 */
public class FtpFileSizeComparator implements Comparator<FTPFile>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1695007234111922953L;
	private boolean desc;

	public FtpFileSizeComparator()
	{
		this.desc = false;
	}

	public FtpFileSizeComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(FTPFile o1, FTPFile o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null) return desc ? 1 : -1;
		if (o2 == null) return desc ? -1 : 1;
		if (desc) return Long.valueOf(o2.getSize() - o1.getSize()).intValue();
		return Long.valueOf(o1.getSize() - o2.getSize()).intValue();
	}

}
