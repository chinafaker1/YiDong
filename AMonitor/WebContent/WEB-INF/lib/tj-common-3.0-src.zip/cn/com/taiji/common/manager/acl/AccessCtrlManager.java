package cn.com.taiji.common.manager.acl;

import cn.com.taiji.common.model.acl.AccessCtrl;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-28 下午03:55:37
 * @since 1.0
 * @version 1.0
 */
public interface AccessCtrlManager
{
	/**
	 * 校验权限
	 * 
	 * @param access
	 * @return 是否成功，如果失败，失败原因在AccessCtrl中
	 */
	public boolean checkPower(AccessCtrl access);
}
