/*
 * Date: 2012-6-28
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;

import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import cn.com.taiji.common.manager.JsonManagerException;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.pub.EncodeTool;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.validation.MyViolationException;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-6-28 上午10:17:05<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link JsonValidController}
 */
public abstract class BaseValidController extends BaseController
{
	protected final String responseFiledErrors(BindingResult result, Model model)
	{
		model.addAttribute("taiji_result", "taiji_violation").addAttribute("taiji_message", fieldErrors2Json(result));
		return "exceptionNote";
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ModelAndView handleConstraintViolationException(ConstraintViolationException cve)
	{
		ModelAndView model = new ModelAndView("exceptionNote");
		return model.addObject("taiji_result", "taiji_violation").addObject("taiji_message", violation2Json(cve));
	}

	@ExceptionHandler(BindException.class)
	public ModelAndView handleBindException(BindException be)
	{
		ModelAndView model = new ModelAndView("exceptionNote");
		return model.addObject("taiji_result", "taiji_violation").addObject("taiji_message",
				fieldErrors2Json(be.getBindingResult()));
	}

	@ExceptionHandler(MyViolationException.class)
	public ModelAndView handleMyViolationException(MyViolationException mve)
	{
		ModelAndView model = new ModelAndView("exceptionNote");
		return model.addObject("taiji_result", "taiji_violation").addObject("taiji_message", mve.toJson());
	}

	@ExceptionHandler(ManagerException.class)
	public ModelAndView handleManagerException(ManagerException e)
	{
		ModelAndView model = new ModelAndView("exceptionNote");
		return model.addObject("taiji_result", "taiji_error").addObject("taiji_message", "操作失败:" + e.getMessage());
	}

	/**
	 * 异常信息以json格式返回，前台可以用jquery进行处理
	 * 
	 * @param e
	 * @param response
	 * @throws IOException
	 */
	@ExceptionHandler(JsonManagerException.class)
	public void handleJsonManagerException(JsonManagerException e, HttpServletResponse response) throws IOException
	{
		String msg = StringTools.hasText(e.getMessage()) ? EncodeTool.encodeBase64UTF8(e.getMessage()) : "";
		response.setHeader("taiji_jme", msg);
		response.setContentType("application/json");
		if (StringTools.hasText(e.getJsonStr())) response.getWriter().print(e.getJsonStr());
	}
}
