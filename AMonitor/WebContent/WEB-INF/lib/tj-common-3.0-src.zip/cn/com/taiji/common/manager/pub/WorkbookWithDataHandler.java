/*
 * Date: 2011-12-27
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import org.apache.poi.ss.usermodel.Workbook;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-27 下午3:20:11<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface WorkbookWithDataHandler<E>
{
	/**
	 * 填充excel数据的回调接口
	 * 
	 * @param workbook
	 *            待填充的excel
	 * @param data
	 *            用于填充的数据
	 * @throws Exception
	 */
	public void fillWorkbook(Workbook workbook, E data) throws Exception;
}
