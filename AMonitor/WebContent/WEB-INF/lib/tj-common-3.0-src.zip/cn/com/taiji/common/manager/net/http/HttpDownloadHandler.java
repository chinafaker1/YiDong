/*
 * Date: 2011-8-29
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.Header;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-8-29 下午4:46:28<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface HttpDownloadHandler
{
	public void handle(InputStream is, String fileName, Header[] headers) throws IOException;
}
