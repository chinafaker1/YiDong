package cn.com.taiji.common.pub.video;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import cn.com.taiji.common.pub.StringTools;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-2 下午01:36:54
 * @since 1.0
 * @version 1.0
 */
public class VideoPara implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5764546260217955293L;
	private VideoRatio ratio = VideoRatio.AS_SRC;// 分辨率
	private int bitrate = 1500;// 压缩比特率,单位：k
	private int audioBitrate = 64;// 设定声音比特率(-ac设为立体声时要以一半比特率来设置，比如192kbps的就设成96)
	private Integer vol;// <百分比> 设定音量 ex:-vol 200,为空忽略
	private Type destType = Type.FLV;// 目标格式
	private Integer startTime;// 从多少秒处开始转换，为空从头开始
	private Integer duration;// 转换多长时间的视频，为空转换全部
	private String acodec = "libmp3lame";
	// 高级参数
	private boolean enableSameq = false;// 是否启用sameq参数

	public VideoRatio getRatio()
	{
		return ratio;
	}

	public void setRatio(VideoRatio ratio)
	{
		this.ratio = ratio;
	}

	public String getAcodec()
	{
		return acodec;
	}

	public void setAcodec(String acodec)
	{
		this.acodec = acodec;
	}

	public int getBitrate()
	{
		return bitrate;
	}

	public void setBitrate(int bitrate)
	{
		this.bitrate = bitrate;
	}

	public int getAudioBitrate()
	{
		return audioBitrate;
	}

	public void setAudioBitrate(int audioBitrate)
	{
		this.audioBitrate = audioBitrate;
	}

	public Integer getVol()
	{
		return vol;
	}

	public void setVol(Integer vol)
	{
		this.vol = vol;
	}

	public Type getDestType()
	{
		return destType;
	}

	public void setDestType(Type destType)
	{
		this.destType = destType;
	}

	public Integer getStartTime()
	{
		return startTime;
	}

	public void setStartTime(Integer startTime)
	{
		this.startTime = startTime;
	}

	public Integer getDuration()
	{
		return duration;
	}

	public void setDuration(Integer duration)
	{
		this.duration = duration;
	}

	public boolean isEnableSameq()
	{
		return enableSameq;
	}

	/**
	 * Option 'sameq' was removed. If you are looking for an option to preserve the quality (which
	 * is not what -sameq was for), use -qscale 0 or an equivalent quality factor option.
	 * 
	 * @param enableSameq
	 */
	@Deprecated
	public void setEnableSameq(boolean enableSameq)
	{
		this.enableSameq = enableSameq;
	}

	public enum Type
	{
		FLV("flv") {},
		AVI("avi") {},
		MPG("mpg") {},
		MPEG("mpeg") {},
		WMV("wmv") {},
		MOV("mov") {},
		MP4("mp4") {},
		MP3("mp3") {},
		WMA("wma") {},
		WAV("wav") {},
		ASF("asf") {},
		ASX("asx") {},
		T_3GP("3gp") {},
		RM("rm") {},
		RMVB("rmvb") {},
		WMV9("wmv9") {},
		MKV("mkv") {},
		MTS("mts") {},
		M2TS("m2ts") {},
		;

		private String value;
		private static Map<Type, String> ffmpegMap = new HashMap<Type, String>();
		static
		{
			for (Type type : Type.values())
			{
				// 新版本应该是都支持了
				// if (type == Type.RM || type == Type.RMVB || type == Type.WMV9) continue;
				ffmpegMap.put(type, type.value);
			}
		}
		private static Map<Type, String> mencoderMap = new HashMap<Type, String>();
		static
		{
			mencoderMap.put(Type.RM, Type.RM.value);
			mencoderMap.put(Type.RMVB, Type.RMVB.value);
			mencoderMap.put(Type.WMV9, Type.WMV9.value);
		}

		/**
		 * 转换程序是否支持此种类型
		 * 
		 * @param type
		 * @return
		 */
		public static boolean isSupport(Type type)
		{
			if (type == null) return false;
			return (ffmpegMap.get(type) != null || mencoderMap.get(type) != null);
		}

		/**
		 * 判断ffmpeg是否支持此类型
		 * 
		 * @param type
		 * @return
		 */
		public static boolean isFfmpegSupport(Type type)
		{
			return ffmpegMap.get(type) != null;
		}

		/**
		 * 判断是否要先转成avi
		 * 
		 * @param type
		 * @return
		 */
		public static boolean isNeedMencoder(Type type)
		{
			return mencoderMap.get(type) != null;
		}

		private Type(String value)
		{
			this.value = value;
		}

		public String getValue()
		{
			return value;
		}

		public static Type getInstance(String value)
		{
			if (!StringTools.hasText(value)) return null;
			if (value.equalsIgnoreCase("3gp")) return Type.T_3GP;
			try
			{
				return Type.valueOf(value.toUpperCase());
			}
			catch (Exception e)
			{
				return null;
			}
		}
	}

}
