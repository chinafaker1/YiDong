package cn.com.taiji.common.pub;

import org.springframework.util.ObjectUtils;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-29 下午04:22:18
 * @since 1.0
 * @version 1.0
 */
public abstract class ObjectTools extends ObjectUtils
{

}
