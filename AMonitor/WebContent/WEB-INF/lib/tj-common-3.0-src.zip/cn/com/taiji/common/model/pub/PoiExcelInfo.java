/*
 * Date: 2012-8-11
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.pub;

import java.io.InputStream;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-8-11 上午11:00:42<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class PoiExcelInfo extends BaseModel
{
	private InputStream excelInput;// excel的文件流
	private int sheetIndex;// 读取的sheet标签页
	private int fromRow;// 从哪行开始读，为负数时从头开始读取(包含该行)
	private int toRow;// 读取到哪行，为负数时读取到第一次碰到空行。(包含该行)
	private int colSize;// 每行总共读取的列数
	private boolean breakOnRowNull = true;// 当读取碰到空行时不再继续往下读取
	private boolean xlsx;// 是否是97以上的格式

	public boolean isXlsx()
	{
		return xlsx;
	}

	public void setXlsx(boolean xlsx)
	{
		this.xlsx = xlsx;
	}

	public InputStream getExcelInput()
	{
		return excelInput;
	}

	public void setExcelInput(InputStream excelInput)
	{
		this.excelInput = excelInput;
	}

	public int getSheetIndex()
	{
		return sheetIndex;
	}

	public void setSheetIndex(int sheetIndex)
	{
		this.sheetIndex = sheetIndex;
	}

	public int getFromRow()
	{
		return fromRow;
	}

	public void setFromRow(int fromRow)
	{
		this.fromRow = fromRow;
	}

	public int getToRow()
	{
		return toRow;
	}

	public void setToRow(int toRow)
	{
		this.toRow = toRow;
	}

	public int getColSize()
	{
		return colSize;
	}

	public void setColSize(int colSize)
	{
		this.colSize = colSize;
	}

	public boolean isBreakOnRowNull()
	{
		return breakOnRowNull;
	}

	public void setBreakOnRowNull(boolean breakOnRowNull)
	{
		this.breakOnRowNull = breakOnRowNull;
	}

}
