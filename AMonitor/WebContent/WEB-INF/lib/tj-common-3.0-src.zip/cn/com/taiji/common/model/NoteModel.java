/*
 * Date: 2012-11-6
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-11-6 上午9:27:35<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class NoteModel extends BaseModel
{
	private boolean success;
	private String msg;

	public NoteModel()
	{

	}

	public NoteModel(boolean success, String msg)
	{
		this.success = success;
		this.msg = msg;
	}

	public boolean isSuccess()
	{
		return success;
	}

	public void setSuccess(boolean success)
	{
		this.success = success;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

}
