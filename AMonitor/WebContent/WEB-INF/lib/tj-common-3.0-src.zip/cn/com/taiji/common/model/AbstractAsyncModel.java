package cn.com.taiji.common.model;

public abstract class AbstractAsyncModel extends BaseModel
{
	protected final AsyncProcessType processType;

	protected AbstractAsyncModel(AsyncProcessType processType)
	{
		this.processType = processType;
	}

	public AsyncProcessType getProcessType()
	{
		return processType;
	}

}
