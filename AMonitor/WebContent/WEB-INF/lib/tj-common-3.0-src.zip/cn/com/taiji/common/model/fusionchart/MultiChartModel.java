package cn.com.taiji.common.model.fusionchart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MultiChartModel extends AbstractChartModel
{
	private List<String> labels;
	private List<ChartDataSet> dataSet;

	public List<String> getLabels()
	{
		return labels;
	}

	public void setLabels(List<String> labels)
	{
		this.labels = labels;
	}

	public List<ChartDataSet> getDataSet()
	{
		return dataSet;
	}

	public void setDataSet(List<ChartDataSet> dataSet)
	{
		this.dataSet = dataSet;
	}

	public static MultiChartModel newInstance(ChartHead chartHead, List<String> labels, List<ChartDataSet> dataSets)
	{
		MultiChartModel multiChartModel = new MultiChartModel();
		multiChartModel.setChartHead(chartHead);
		multiChartModel.setDataSet(dataSets);
		multiChartModel.setLabels(labels);
		return multiChartModel;
	}

	protected Map<String, Object> toContentMap(Map<String, Object> map)
	{
		Map<String, Object> categoriesMap = new LinkedHashMap<String, Object>();
		List<Map<String, String>> categoryList = new ArrayList<Map<String, String>>();
		List<Map<String, Object>> dataSetList = new ArrayList<Map<String, Object>>();
		List<Map<String, String>> lineList = new ArrayList<Map<String, String>>();
		Map<String, Object> trendLinesMap = new HashMap<String, Object>();
		for (String label : labels)
		{
			Map<String, String> categoryMap = new LinkedHashMap<String, String>();
			categoryMap.put("label", label);
			categoryList.add(categoryMap);
		}
		categoriesMap.put("category", categoryList);
		for (ChartDataSet set : dataSet)
		{
			dataSetList.add(set.getDataSetMap(labels));
		}
		if (trendLines != null)
		{
			for (ChartLine line : trendLines)
			{
				lineList.add(line.toLineMap());
			}
			trendLinesMap.put("line", lineList);
			map.put("trendlines", trendLinesMap);
		}
		map.put("chart", chartHead.toChartHeadMap());
		map.put("categories", categoriesMap);
		map.put("dataset", dataSetList);
		return map;
	}

}
