/*
 * Date: 2011-6-30
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.manager.pub.AbstractHttpHelper;
import cn.com.taiji.common.model.net.http.FileUploadPara;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.json.JsonTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-30 下午3:45:37<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class HttpClientHelper extends AbstractHttpHelper
{
	protected static Logger logger = LoggerFactory.getLogger(HttpClientHelper.class);

	/**
	 * 使用GET的方式请求指定URI
	 * 
	 * @param uri
	 *            URI {@link URLEncodedUtils#format(List, String)}
	 * @param defaultResEncoding
	 *            返回信息的默认编码，如果返回中已经指定了编码，<br>
	 *            则使用返回的编码{@link HttpServletResponse#getCharacterEncoding()}
	 * @return 返回信息的字符串
	 * @throws IOException
	 *             请求错误时抛出此异常
	 */
	public static String httpGet(URI uri, String defaultResEncoding) throws IOException
	{
		return httpGet(uri, DEFAULT_CONN_TIMEOUT, new Response2StringHandler(defaultResEncoding), -1);
	}

	public static <T> T httpGet(URI uri, int connTimeout, HttpResponseHandler<T> handler, int soTimeout)
			throws IOException
	{
		return httpGet(uri, false, connTimeout, handler, soTimeout);
	}

	/**
	 * 使用GET的方式请求指定URI
	 * 
	 * @param uri
	 *            URI {@link URLEncodedUtils#format(List, String)}
	 * @param enableGzip
	 *            是否请求服务端启用gzip压缩
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param handler
	 *            返回内容处理的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @return 处理结果
	 * @throws IOException
	 * @see {@link Response2StringHandler}
	 */
	public static <T> T httpGet(URI uri, boolean enableGzip, int connTimeout, HttpResponseHandler<T> handler,
			int soTimeout) throws IOException
	{
		return httpGet(uri, enableGzip, connTimeout, handler, soTimeout, null);
	}

	/**
	 * 使用GET的方式请求指定URI
	 * 
	 * @param uri
	 *            URI {@link URLEncodedUtils#format(List, String)}
	 * @param enableGzip
	 *            是否请求服务端启用gzip压缩
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param handler
	 *            返回内容处理的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param interceptor
	 * @return 处理结果
	 * @throws IOException
	 * @see {@link Response2StringHandler}
	 */
	public static <T> T httpGet(URI uri, boolean enableGzip, int connTimeout, HttpResponseHandler<T> handler,
			int soTimeout, HttpClientInterceptor interceptor) throws IOException
	{
		HttpGet httpGet = new HttpGet(uri);
		return httpRequest(httpGet, enableGzip, connTimeout, handler, soTimeout, interceptor);
	}

	/**
	 * 通过post方式下载文件
	 * 
	 * @param uri
	 *            URL
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param handler
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param requestEncoding
	 *            请求参数编码
	 * @param params
	 *            post请求参数
	 * @return
	 * @throws IOException
	 *             下载异常时抛出
	 */
	public static <T> T postFileDownload(final URI uri, int connTimeout, final FileDownloadHandler<T> handler,
			int soTimeout, String requestEncoding, List<? extends NameValuePair> params) throws IOException
	{
		AssertUtil.notNull(uri);
		AssertUtil.notNull(params);
		HttpPost post = new HttpPost(uri);
		UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params, requestEncoding);
		post.setEntity(reqEntity);
		return fileDownload(post, connTimeout, handler, soTimeout);
	}

	/**
	 * 通过URI下载文件
	 * 
	 * @param uri
	 *            下载文件的URI
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param handler
	 *            下载文件的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @return 文件下载完成后的返回结果
	 * @throws IOException
	 *             下载异常时抛出
	 */
	public static <T> T fileDownload(final URI uri, int connTimeout, final FileDownloadHandler<T> handler, int soTimeout)
			throws IOException
	{
		AssertUtil.notNull(uri);
		HttpGet request = new HttpGet(uri);
		return fileDownload(request, connTimeout, handler, soTimeout);
	}

	private static <T> T fileDownload(final HttpUriRequest request, int connTimeout,
			final FileDownloadHandler<T> handler, int soTimeout) throws IOException
	{
		AssertUtil.notNull(handler);
		return httpRequest(request, true, connTimeout, new HttpResponseHandler<T>() {
			@Override
			public T handle(HttpResponse response) throws IOException
			{
				HttpEntity entity = response.getEntity();
				if (entity == null) throw new IOException(toLogString("No response:{}", request.getURI().toString()));
				StatusLine sl = response.getStatusLine();
				int code = sl.getStatusCode();
				if (code >= 400)
					throw new IOException(toLogString("Request Error:{}\t{}", code, request.getURI().toString()));
				boolean gzip = isContentGziped(response);
				HttpEntity resEntity = gzip ? new GzipDecompressingEntity(entity) : entity;
				Header[] headers = response.getAllHeaders();
				Header header = response.getFirstHeader("Content-Disposition");
				InputStream is = resEntity.getContent();
				try
				{
					return handler.handle(is, getFilename(header), headers, request.getURI());
				}
				finally
				{
					closeQuietly(is);
				}
			}

		}, soTimeout);
	}

	/**
	 * 使用POST的方式请求指定URI
	 * 
	 * @param uri
	 *            不带参数的uri例如：<code>http://127.0.0.1/ccc/sample/json/show.do</code>
	 * @param requestEncoding
	 *            请求参数的编码
	 * @param params
	 *            请求参数
	 * @param defaultResEncoding
	 *            返回信息的默认编码，如果返回中已经指定了编码，<br>
	 *            则使用返回的编码{@link HttpServletResponse#getCharacterEncoding()}
	 * @return 返回信息的字符串
	 * @throws IOException
	 *             请求错误时抛出此异常
	 */
	public static String httpPost(String uri, String requestEncoding, List<? extends NameValuePair> params,
			String defaultResEncoding) throws IOException
	{
		return httpPost(uri, DEFAULT_CONN_TIMEOUT, requestEncoding, params, new Response2StringHandler(
				defaultResEncoding), -1);
	}

	/**
	 * 使用POST的方式请求指定URI
	 * 
	 * @param uri
	 *            uri例如：<code>http://127.0.0.1/ccc/sample/json/show.do</code>
	 * @param requestJson
	 *            请求参数
	 * @param defaultResEncoding
	 *            返回信息的默认编码，如果返回中已经指定了编码，<br>
	 *            则使用返回的编码{@link HttpServletResponse#getCharacterEncoding()}
	 * @return 返回信息的字符串
	 * @throws IOException
	 *             请求错误时抛出此异常
	 */
	public static String jsonPost(String uri, String requestJson, String defaultResEncoding) throws IOException
	{
		HttpPost post = new HttpPost(uri);
		StringEntity reqEntity = new StringEntity(requestJson, ContentType.APPLICATION_JSON);
		post.setEntity(reqEntity);
		return httpRequest(post, defaultResEncoding);
	}

	public static String jsonPost(String uri, String requestJson) throws IOException
	{
		return jsonPost(uri, requestJson, "UTF-8");
	}

	public static <E extends BaseEntity> E jsonPost(Class<E> resultClass, String uri, String requestJson)
			throws IOException
	{
		String rs = jsonPost(uri, requestJson);
		if (!hasText(rs)) return null;
		return JsonTools.json2Object(rs, resultClass);
	}

	/**
	 * 文件上传
	 * 
	 * @param uri
	 *            不带参数的uri例如：<code>http://127.0.0.1/ccc/sample/json/show.do</code>
	 * @param files
	 *            被上传的文件
	 * @param requestEncoding
	 *            请求参数的编码
	 * @param params
	 *            其他参数
	 * @param defaultResEncoding
	 *            返回信息的默认编码，如果返回中已经指定了编码，<br>
	 *            则使用返回的编码{@link HttpServletResponse#getCharacterEncoding()}
	 * @return 返回信息的字符串
	 * @throws IOException
	 */
	public static String fileUpload(String uri, Map<String, File> files, String requestEncoding,
			List<? extends NameValuePair> params, String defaultResEncoding) throws IOException
	{
		FileUploadPara para = new FileUploadPara(uri, -1, -1);
		para.setDefaultResEncoding(defaultResEncoding);
		para.setRequestEncoding(requestEncoding);
		para.setFiles(files);
		para.setParams(params);
		return fileUpload(para);
	}

	/**
	 * 文件上传
	 * 
	 * @param para
	 *            上传参数，具体参见{@link FileUploadPara}的属性注释
	 * @param handler
	 *            请求返回的回调处理器
	 * @return 返回信息的字符串
	 * @throws IOException
	 */
	public static <T> T fileUpload(FileUploadPara para, HttpResponseHandler<T> handler) throws IOException
	{
		AssertUtil.notNull(para);
		AssertUtil.notEmpty(para.getFiles());
		HttpPost post = new HttpPost(para.getUri());
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		for (Entry<String, File> en : para.getFiles().entrySet())
		{
			builder.addBinaryBody(en.getKey(), en.getValue());
		}
		for (NameValuePair nv : para.getParams())
		{
			builder.addTextBody(nv.getName(), nv.getValue(),
					ContentType.create(ContentType.DEFAULT_TEXT.getMimeType(), para.getRequestEncoding()));
		}
		post.setEntity(builder.build());
		return httpRequest(post, para.getConnTimeout(), handler, para.getSoTimeout());
	}

	public static String fileUpload(FileUploadPara para) throws IOException
	{
		return fileUpload(para, new Response2StringHandler(para.getDefaultResEncoding()));
	}

	public static <T> T httpPost(String url, int connTimeout, String requestEncoding,
			List<? extends NameValuePair> params, HttpResponseHandler<T> handler, int soTimeout) throws IOException
	{
		return httpPost(url, false, connTimeout, requestEncoding, params, handler, soTimeout);
	}

	/**
	 * 使用POST的方式请求指定URI
	 * 
	 * @param url
	 *            不带参数的url例如：<code>http://127.0.0.1/ccc/sample/json/show.do</code>
	 * @param enableGzip
	 *            是否请求服务端启用gzip压缩
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param requestEncoding
	 *            请求参数的编码
	 * @param params
	 *            请求参数
	 * @param handler
	 *            返回内容处理的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @return 处理结果
	 * @throws IOException
	 */
	public static <T> T httpPost(String url, boolean enableGzip, int connTimeout, String requestEncoding,
			List<? extends NameValuePair> params, HttpResponseHandler<T> handler, int soTimeout) throws IOException
	{
		return httpPost(url, enableGzip, connTimeout, requestEncoding, params, handler, soTimeout, null);
	}

	/**
	 * 使用POST的方式请求指定URI
	 * 
	 * @param url
	 *            不带参数的url例如：<code>http://127.0.0.1/ccc/sample/json/show.do</code>
	 * @param enableGzip
	 *            是否请求服务端启用gzip压缩
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param requestEncoding
	 *            请求参数的编码
	 * @param params
	 *            请求参数
	 * @param handler
	 *            返回内容处理的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param interceptor
	 * @return 处理结果
	 * @throws IOException
	 */
	public static <T> T httpPost(String url, boolean enableGzip, int connTimeout, String requestEncoding,
			List<? extends NameValuePair> params, HttpResponseHandler<T> handler, int soTimeout,
			HttpClientInterceptor interceptor) throws IOException
	{
		HttpPost post = new HttpPost(url);
		UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params, requestEncoding);
		post.setEntity(reqEntity);
		return httpRequest(post, enableGzip, connTimeout, handler, soTimeout, interceptor);
	}

	private static String httpRequest(HttpUriRequest request, int connTimeout, final String defaultResEncoding,
			int soTimeout) throws IOException
	{
		return httpRequest(request, true, connTimeout, new Response2StringHandler(defaultResEncoding), soTimeout);
	}

	private static String httpRequest(HttpUriRequest request, final String defaultResEncoding) throws IOException
	{
		return httpRequest(request, DEFAULT_CONN_TIMEOUT, defaultResEncoding, -1);
	}

}
