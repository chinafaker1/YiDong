package cn.com.taiji.common.manager;

/**
 * 从1.1开始增加errorCode属性
 * 
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-7-27 上午09:17:36
 * @since 1.0
 * @version 1.1
 */
public class ManagerException extends Exception
{
	/**
	 * <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 7643195293790044743L;
	private String errorCode;

	public ManagerException()
	{
		super();
	}

	public ManagerException(String message)
	{
		super(message);
	}

	public ManagerException(String message, String errorCode)
	{
		super(message);
		this.errorCode = errorCode;
	}

	public ManagerException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public ManagerException(String message, Throwable cause, String errorCode)
	{
		super(message, cause);
		this.errorCode = errorCode;
	}

	public String getErrorCode()
	{
		return errorCode;
	}

}
