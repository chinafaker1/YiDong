/*
 * Date: 2012-8-11
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2013-3-5 上午10:18:31<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface ExcelReadRowHandler<E>
{
	/**
	 * 根据行信息生成model
	 * 
	 * @param row
	 *            行号
	 * @param rowData
	 *            行数据
	 * @return
	 */
	public E row2Model(int row, Map<Integer, Cell> rowData);
}
