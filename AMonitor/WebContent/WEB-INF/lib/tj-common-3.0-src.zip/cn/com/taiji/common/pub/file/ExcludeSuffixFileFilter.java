package cn.com.taiji.common.pub.file;

import java.io.File;
import java.io.FileFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-26 下午06:44:47
 * @since 1.0
 * @version 1.0
 */
public class ExcludeSuffixFileFilter implements FileFilter
{
	protected Logger logger = LoggerFactory.getLogger(getClass());

	private final String suffix;
	private boolean onlyFile;

	public ExcludeSuffixFileFilter(String suffix, boolean onlyFile)
	{
		this.suffix = (suffix == null) ? null : suffix.toLowerCase();
		this.onlyFile = onlyFile;
	}

	public boolean accept(File pathname)
	{
		if (pathname.isDirectory() && onlyFile) return false;
		String fileName = pathname.getName().toLowerCase();
		if (StringTools.hasText(suffix) && fileName.endsWith(suffix)) return false;
		return true;
	}

}
