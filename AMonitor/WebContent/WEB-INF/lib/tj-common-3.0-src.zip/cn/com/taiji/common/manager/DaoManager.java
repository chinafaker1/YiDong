package cn.com.taiji.common.manager;

import java.io.Serializable;
import java.util.List;

import cn.com.taiji.common.dao.AbstractDao;
import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.model.dao.Pagination;


/**
 * 
 * @author Peream <br>
 *         Create Time：2010-7-29 上午10:59:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link AbstractDaoManager}
 */
public interface DaoManager<E extends BaseEntity, T extends AbstractDao<E>>
{
	/**
	 * 根据ID查找记录
	 * 
	 * @param id
	 * @return
	 */
	public E findById(Serializable id);

	/**
	 * 添加记录,通过覆盖{@link AbstractDaoManager#checkAdd(BaseEntity)}方法达到添加前校验的目的
	 * 
	 * @param entity
	 * @return
	 * @throws ManagerException
	 */
	public Serializable add(E entity) throws ManagerException;

	/**
	 * 更新记录,通过覆盖{@link AbstractDaoManager#checkUpdate(BaseEntity)}方法达到修改前校验的目的
	 * 
	 * @param entity
	 * @throws ManagerException
	 */
	public void update(E entity) throws ManagerException;

	/**
	 * 删除记录,通过覆盖{@link AbstractDaoManager#checkDelete(BaseEntity)}方法达到删除前校验的目的
	 * 
	 * @param entity
	 * @throws ManagerException
	 */
	public void delete(E entity) throws ManagerException;

	/**
	 * 删除记录,通过覆盖{@link AbstractDaoManager#checkDelete(BaseEntity)}方法达到删除前校验的目的 <BR>
	 * 指定ID对应的记录不存在时直接返回
	 * 
	 * @param entity
	 * @throws ManagerException
	 */
	public void deleteById(Serializable id) throws ManagerException;

	/**
	 * 取得记录总数
	 * 
	 * @return 总数
	 */
	public long getTotalCount();

	/**
	 * 获取所有记录
	 * 
	 * @return 记录集合
	 */
	public List<E> listAll();

	/**
	 * 分页获取所有记录
	 * 
	 * @param pageNo
	 *            页码
	 * @param pageSize
	 *            每页条数
	 * @return
	 */
	public Pagination pageAll(int pageNo, int pageSize);
}
