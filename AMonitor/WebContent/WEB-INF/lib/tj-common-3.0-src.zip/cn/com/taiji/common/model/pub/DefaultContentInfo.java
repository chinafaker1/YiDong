/*
 * Date: 2012-8-14
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.pub;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-8-14 下午1:54:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class DefaultContentInfo extends AbstractContentInfo
{
	public DefaultContentInfo()
	{
		templateEncoding = "GBK";
	}
}
