/*
 * Date: 2013-5-1
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.net.http.HttpJsonCommHandleManager;
import cn.com.taiji.common.manager.net.http.JsonCommHandleManager;
import cn.com.taiji.common.manager.net.http.JsonCommHelper;
import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-1 下午4:56:26<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link JsonCommHelper} {@link JsonCommHandleManager} {@link HttpJsonCommHandleManager}
 */
public abstract class BaseJsonCommController extends BaseController
{
	private final int defaultErrorCode;

	protected BaseJsonCommController()
	{
		this(900);
	}

	protected BaseJsonCommController(int defaultErrorCode)
	{
		this.defaultErrorCode = defaultErrorCode;
	}

	/**
	 * 会根据request请求自动判断是否启用gzip压缩
	 * 
	 * @param protocol
	 * @param handleManager
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	protected final void handleJsonComm(JsonProtocol protocol, JsonCommHandleManager handleManager,
			HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		try
		{
			JsonProtocol result = handleManager.handleComm(protocol);
			responseJson(result.toJson(), request, response);
		}
		catch (IOException e)
		{
			logger.error("", e);
			response.sendError(defaultErrorCode, toLogString("处理请求({})失败:{}", protocol.getType(), e.getMessage()));
		}
	}

	/**
	 * 会根据request请求自动判断是否启用gzip压缩
	 * 
	 * @param protocol
	 * @param handleManager
	 *            会把request也传递给handleManager
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	protected final void handleJsonComm(JsonProtocol protocol, HttpJsonCommHandleManager handleManager,
			HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		try
		{
			JsonProtocol result = handleManager.handleComm(protocol, request);
			responseJson(result.toJson(), request, response);
		}
		catch (IOException e)
		{
			logger.error("", e);
			response.sendError(defaultErrorCode, toLogString("处理请求({})失败:{}", protocol.getType(), e.getMessage()));
		}
	}

}
