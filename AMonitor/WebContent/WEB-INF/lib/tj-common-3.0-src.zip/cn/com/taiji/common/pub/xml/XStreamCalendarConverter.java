/*
 * Date: 2015年4月30日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub.xml;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月30日 下午5:18:07<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class XStreamCalendarConverter extends AbstractSingleValueConverter
{
	@Override
	public boolean canConvert(@SuppressWarnings("rawtypes") Class type)
	{
		return type.equals(GregorianCalendar.class);
	}

	@Override
	public String toString(Object obj)
	{
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((Calendar) obj).getTime());
	}

	@Override
	public Object fromString(String str)
	{
		try
		{
			Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			return cal;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
}
