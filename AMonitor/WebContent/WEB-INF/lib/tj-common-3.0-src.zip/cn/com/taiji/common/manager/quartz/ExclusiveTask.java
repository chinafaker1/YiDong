/*
 * Date: 2011-10-24
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

/**
 * 独占任务，同一时刻最多只有一个任务在运行.只在当前虚拟机互斥
 * 
 * @author Peream <br>
 *         Create Time：2011-10-24 下午5:19:05<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link MemcachedExclusiveTask}
 * @see {@link DBExclusiveTask}
 */
public final class ExclusiveTask extends AbstractRunnableProxy implements RunnableProxy
{
	public ExclusiveTask(final Runnable task)
	{
		this(task, task.toString());
	}

	public ExclusiveTask(final Runnable task, String taskName)
	{
		this(task, taskName, null);
	}

	public ExclusiveTask(final Runnable task, String taskName, TaskListener listener)
	{
		super(task, taskName, listener);
	}

	@Override
	public void run()
	{
		if (taskRunning.get())
		{
			logger.info("{} 任务正在运行,本次任务调用忽略.", taskName);
			return;
		}
		try
		{
			taskRunning.set(true);
			doTask();
		}
		finally
		{
			taskRunning.set(false);
		}
	}

	public boolean isRunning()
	{
		return taskRunning.get();
	}

}
