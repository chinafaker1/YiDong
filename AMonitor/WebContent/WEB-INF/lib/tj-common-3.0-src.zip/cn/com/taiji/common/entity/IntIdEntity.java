package cn.com.taiji.common.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 上午09:00:57
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class IntIdEntity extends BaseEntity
{
	protected int id;

	@Id
	@Column(name = "id")
	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof IntIdEntity)) return false;
		IntIdEntity other = (IntIdEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}

}
