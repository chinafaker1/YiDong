package cn.com.taiji.common.model.fusionchart;

import java.util.HashMap;
import java.util.Map;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;

public class ChartHead extends BaseModel
{
	private String caption;// 图片主标题
	private String subCaption;// 图片副标题
	private String xAxisName = "省份";// 横轴名字
	private String yAxisName = "数值";// 纵轴名字
	private String useRoundedges = "1";// 是否采用玻璃风格
	private String baseFontSize;// 图标字体大小
	private String baseFont;// 图标字体样式
	private String showValues = "1";// 是否显示数值
	private String imageSave = "1";// 是否保存图片，默认保存
	private String animation = "1";// 是否动画显示数据
	// 数据格式
	private String numberPrefix;// 数值前缀，例如 $
	private String numberSuffix;// 数值后缀,例如 %
	private String formatNumberScale = "0";// 是否格式化显示数值，加上K,M
	private String decimalPrecision = "0";// 指定小数显示位数，为0即取整。
	// private String connectNullData＝"0"; null值处理为

	// 图片导出属性
	private String exportEnable = "1";// 是否可以到处图片1可以 ,0不可以
	private String exportAtClient = "0";
	private String exportAction = "save";
	private String exportDialogMessage = "正在导出，请稍候...";

	private String exportHandler = "report/FCExporter";
	private String exportShowMenuItem = "1";
	private String exportFileName = "image";

	private String chartRandType;
	// 如果存在双Y轴,则下面的属性用用
	private String pYAxisName;
	private String sYAxisName;
	private String sYAxisValuesDecimals = "0";
	private String pYAxisValuesDecimals = "0";
	private boolean adaptiveSYMin = false;
	private boolean adaptivePYMin = false;
	private String sNumberSuffix;
	private String pNumberSuffix;

	public ChartHead exportDisable()
	{
		this.exportEnable = "0";
		return this;
	}

	public ChartHead exportEnable()
	{
		this.exportEnable = "1";
		return this;
	}

	public ChartHead exportAtClient()
	{
		this.exportAtClient = "1";
		this.exportAction = "client";
		return this;
	}

	public ChartHead exportAtService()
	{
		this.exportAtClient = "0";
		this.exportAction = "save";
		return this;
	}

	public String getExportDialogMessage()
	{
		return exportDialogMessage;
	}

	public ChartHead setExportDialogMessage(String exportDialogMessage)
	{
		this.exportDialogMessage = exportDialogMessage;
		return this;
	}

	public String getExportHandler()
	{
		return exportHandler;
	}

	public ChartHead setExportHandler(String exportHandler)
	{
		this.exportHandler = exportHandler;
		return this;
	}

	public ChartHead showMenuItem()
	{
		this.exportShowMenuItem = "1";
		return this;
	}

	public ChartHead hideMenuItem()
	{
		this.exportShowMenuItem = "0";
		return this;
	}

	public ChartHead enableRoundeges()
	{
		this.useRoundedges = "1";
		return this;
	}

	public ChartHead disableRoundeges()
	{
		this.useRoundedges = "0";
		return this;
	}

	public ChartHead enableAnimation()
	{
		this.imageSave = "1";
		return this;
	}

	public ChartHead disableAnimation()
	{
		this.imageSave = "0";
		return this;
	}

	public ChartHead enableShowValues()
	{
		this.imageSave = "1";
		return this;
	}

	public ChartHead disableShowValues()
	{
		this.imageSave = "0";
		return this;
	}

	public ChartHead enableImageSave()
	{
		this.imageSave = "1";
		return this;
	}

	public ChartHead disableImageSave()
	{
		this.imageSave = "0";
		return this;
	}

	public String getCaption()
	{
		return caption;
	}

	public ChartHead setCaption(String caption)
	{
		this.caption = caption;
		return this;
	}

	public String getSubCaption()
	{
		return subCaption;
	}

	public ChartHead setSubCaption(String subCaption)
	{
		this.subCaption = subCaption;
		return this;
	}

	public String getxAxisName()
	{
		return xAxisName;
	}

	public ChartHead setxAxisName(String xAxisName)
	{
		this.xAxisName = xAxisName;
		return this;
	}

	public String getyAxisName()
	{
		return yAxisName;
	}

	public ChartHead setyAxisName(String yAxisName)
	{
		this.yAxisName = yAxisName;
		return this;
	}

	public String getUseRoundedges()
	{
		return useRoundedges;
	}

	public ChartHead setUseRoundedges(String useRoundedges)
	{
		this.useRoundedges = useRoundedges;
		return this;
	}

	public String getBaseFontSize()
	{
		return baseFontSize;
	}

	public ChartHead setBaseFontSize(String baseFontSize)
	{
		this.baseFontSize = baseFontSize;
		return this;
	}

	public String getBaseFont()
	{
		return baseFont;
	}

	public ChartHead setBaseFont(String baseFont)
	{
		this.baseFont = baseFont;
		return this;
	}

	public String getShowValues()
	{
		return showValues;
	}

	public ChartHead setShowValues(String showValues)
	{
		this.showValues = showValues;
		return this;
	}

	public String getImageSave()
	{
		return imageSave;
	}

	public ChartHead setImageSave(String imageSave)
	{
		this.imageSave = imageSave;
		return this;
	}

	public String getAnimation()
	{
		return animation;
	}

	public ChartHead setAnimation(String animation)
	{
		this.animation = animation;
		return this;
	}

	public String getNumberPrefix()
	{
		return numberPrefix;
	}

	public ChartHead setNumberPrefix(String numberPrefix)
	{
		this.numberPrefix = numberPrefix;
		return this;
	}

	public String getNumberSuffix()
	{
		return numberSuffix;
	}

	public ChartHead setNumberSuffix(String numberSuffix)
	{
		this.numberSuffix = numberSuffix;
		return this;
	}

	public String getFormatNumberScale()
	{
		return formatNumberScale;
	}

	public ChartHead setFormatNumberScale(String formatNumberScale)
	{
		this.formatNumberScale = formatNumberScale;
		return this;
	}

	public String getDecimalPrecision()
	{
		return decimalPrecision;
	}

	public ChartHead setDecimalPrecision(String decimalPrecision)
	{
		this.decimalPrecision = decimalPrecision;
		return this;
	}

	public String getpYAxisName()
	{
		return pYAxisName;
	}

	public ChartHead setpYAxisName(String pYAxisName)
	{
		this.pYAxisName = pYAxisName;
		return this;
	}

	public String getsYAxisName()
	{
		return sYAxisName;
	}

	public ChartHead setsYAxisName(String sYAxisName)
	{
		this.sYAxisName = sYAxisName;
		return this;
	}

	public String getsYAxisValuesDecimals()
	{
		return sYAxisValuesDecimals;
	}

	public ChartHead setsYAxisValuesDecimals(String sYAxisValuesDecimals)
	{
		this.sYAxisValuesDecimals = sYAxisValuesDecimals;
		return this;
	}

	public String getpYAxisValuesDecimals()
	{
		return pYAxisValuesDecimals;
	}

	public ChartHead setpYAxisValuesDecimals(String pYAxisValuesDecimals)
	{
		this.pYAxisValuesDecimals = pYAxisValuesDecimals;
		return this;
	}

	public String getExportFileName()
	{
		return exportFileName;
	}

	public ChartHead setExportFileName(String exportFileName)
	{
		this.exportFileName = exportFileName;
		return this;
	}

	public String getChartRandType()
	{
		return chartRandType;
	}

	public ChartHead setChartRandType(String chartRandType)
	{
		this.chartRandType = chartRandType;
		return this;
	}

	public boolean isAdaptiveSYMin()
	{
		return adaptiveSYMin;
	}

	public ChartHead setAdaptiveSYMin(boolean adaptiveSYMin)
	{
		this.adaptiveSYMin = adaptiveSYMin;
		return this;
	}

	public boolean isAdaptivePYMin()
	{
		return adaptivePYMin;
	}

	public ChartHead setAdaptivePYMin(boolean adaptivePYMin)
	{
		this.adaptivePYMin = adaptivePYMin;
		return this;
	}

	public String getsNumberSuffix()
	{
		return sNumberSuffix;
	}

	public ChartHead setsNumberSuffix(String sNumberSuffix)
	{
		this.sNumberSuffix = sNumberSuffix;
		return this;
	}

	public String getpNumberSuffix()
	{
		return pNumberSuffix;
	}

	public ChartHead setpNumberSuffix(String pNumberSuffix)
	{
		this.pNumberSuffix = pNumberSuffix;
		return this;
	}

	public static ChartHead newInstance(String caption)
	{
		ChartHead chartHead = new ChartHead();
		chartHead.setCaption(caption);
		return chartHead;
	}

	public static ChartHead newInstance(String caption, String subCaption)
	{
		ChartHead chartHead = new ChartHead();
		chartHead.setCaption(caption);
		chartHead.setSubCaption(subCaption);
		return chartHead;
	}

	public Map<String, String> toChartHeadMap()
	{
		Map<String, String> map = new HashMap<String, String>();
		if (StringTools.hasText(caption)) map.put("caption", caption);
		if (StringTools.hasText(subCaption)) map.put("subCaption", subCaption);
		map.put("xAxisName", xAxisName);
		map.put("yAxisName", yAxisName);
		map.put("useRoundedges", useRoundedges);
		if (StringTools.hasText(baseFontSize)) map.put("baseFontSize", baseFontSize);
		if (StringTools.hasText(baseFont)) map.put("baseFont", baseFont);
		map.put("showValues", showValues);
		map.put("imageSave", imageSave);
		map.put("animation", animation);
		if (StringTools.hasText(numberPrefix)) map.put("numberPrefix", numberPrefix);
		if (StringTools.hasText(numberSuffix)) map.put("numberSuffix", numberSuffix);
		if (StringTools.hasText(formatNumberScale)) map.put("formatNumberScale", formatNumberScale);
		if (StringTools.hasText(decimalPrecision)) map.put("decimalPrecision", decimalPrecision);
		if (StringTools.hasText(pYAxisName)) map.put("PYAxisName", pYAxisName);
		if (StringTools.hasText(sYAxisName)) map.put("SYAxisName", sYAxisName);
		if (StringTools.hasText(sYAxisValuesDecimals)) map.put("SYAxisValuesDecimals", sYAxisValuesDecimals);
		if (StringTools.hasText(pYAxisValuesDecimals)) map.put("PYAxisValuesDecimals", pYAxisValuesDecimals);
		map.put("exportEnable", exportEnable);
		map.put("exportAtClient", exportAtClient);
		map.put("exportAction", exportAction);
		map.put("exportShowMenuItem", exportShowMenuItem);
		if (StringTools.hasText(exportDialogMessage)) map.put("exportDialogMessage", exportDialogMessage);
		if (StringTools.hasText(exportHandler)) map.put("exportHandler", exportHandler);
		if (StringTools.hasText(exportFileName)) map.put("exportFileName", exportFileName);
		if (StringTools.hasText(chartRandType)) map.put("chartRandType", chartRandType);
		if (adaptiveSYMin) map.put("setAdaptiveSYMin", "1");
		if (adaptivePYMin) map.put("setAdaptivePYMin", "1");
		if (StringTools.hasText(sNumberSuffix)) map.put("sNumberSuffix", sNumberSuffix);
		if (StringTools.hasText(pNumberSuffix)) map.put("pNumberSuffix", pNumberSuffix);
		return map;
	}

}
