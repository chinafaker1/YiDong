package cn.com.taiji.common.manager.net.nio;

import cn.com.taiji.common.manager.net.AbstractNetHandler;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-12-24 下午05:01:50<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractNioClientHandler extends AbstractNetHandler implements
		NioClientHandler
{
	protected NioClient client;

	public NioClient getClient()
	{
		return client;
	}

	public void setClient(NioClient client)
	{
		this.client = client;
	}
}
