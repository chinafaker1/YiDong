package cn.com.taiji.common.manager.net.udp;

import java.io.IOException;

import org.xsocket.datagram.UserDatagram;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-14 上午09:53:44
 * @since 1.0
 * @version 1.0
 */
public interface UDPClient
{
	/**
	 * 发送数据，发送失败抛出异常
	 * 
	 * @param packet
	 *            欲发送的数据
	 * @throws IOException
	 *             连接获取不正常出现的异常
	 */
	public void send(UserDatagram datagram) throws IOException;

	/**
	 * 关闭连接池
	 */
	public void stop();
}
