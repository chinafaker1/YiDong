package cn.com.taiji.common.manager.net.vfs;

import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;

import cn.com.taiji.common.manager.net.ClientService;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2015年8月13日 下午6:02:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface SftpClientService extends ClientService
{
	/**
	 * 列出指定远程目录下名字符合正则表达式的文件
	 * 
	 * @param path
	 *            远程文件目录
	 * @return 文件列表
	 * @throws FileSystemException
	 */
	public List<FileObject> listFiles(String path) throws FileSystemException;

	/**
	 * 列出指定远程目录下名字符合正则表达式的文件
	 * 
	 * @param path
	 *            远程文件目录
	 * @param namePattern
	 *            名字正则
	 * @param comparator
	 *            比较器
	 * @return 文件列表
	 * @throws FileSystemException
	 * @see {@link NamePatternSelector} {@link Selectors}
	 * @see {@link VfsFileSizeComparator}{@link VfsFileNameComparator}{@link VfsFileTimeComparator}
	 */
	public List<FileObject> listFiles(String path, Pattern namePattern, Comparator<FileObject> comparator)
			throws FileSystemException;

	/**
	 * 判断远程服务器上是否有指定文件
	 * 
	 * @param pathname
	 * @return
	 * @throws FileSystemException
	 */
	public boolean hasFile(String pathname) throws FileSystemException;

	/**
	 * 创建文件夹
	 * 
	 * @param path
	 * @throws FileSystemException
	 */
	public void mkdir(String path) throws FileSystemException;

	/**
	 * 重命名远程服务器上的文件,目标文件如果存在会自动删除
	 * 
	 * @param from
	 *            原文件名
	 * @param to
	 *            修改后的文件名
	 * @return
	 * @throws FileSystemException
	 */
	public boolean rename(String from, String to) throws FileSystemException;

	/**
	 * 文件上出至sftp服务器，会自动创建必要文件夹，如果目标文件存在会先删除
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @throws FileSystemException
	 */
	public void storeFile(String remote, String local) throws FileSystemException;

	/**
	 * 文件上出至sftp服务器，会自动创建必要文件夹，如果目标文件存在会先删除
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param useSuffix
	 *            上传时是否生成以后缀结尾的临时文件
	 * @throws FileSystemException
	 */
	public void storeFile(String remote, String local, boolean useSuffix) throws FileSystemException;

	/**
	 * 文件上出至sftp服务器，会自动创建必要文件夹，如果目标文件存在会先删除
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param useSuffix
	 *            上传时是否生成以后缀结尾的临时文件
	 * @param suffix
	 *            临时文件后缀
	 * @throws FileSystemException
	 */
	public void storeFile(String remote, String local, boolean useSuffix, String suffix) throws FileSystemException;

	/**
	 * 删除sftp服务器上的文件
	 * 
	 * @param pathname
	 *            文件的目录
	 * @return 是否删除成功，不存在返回false
	 * @throws FileSystemException
	 *             由于连接的错误之类抛出FileSystemException
	 */
	public boolean deleteFile(String pathname) throws FileSystemException;

	/**
	 * 从sftp服务器上下载文件
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @throws FileSystemException
	 */
	public void downFile(String remote, String local) throws FileSystemException;

	/**
	 * 从sftp服务器上下载文件
	 * 
	 * @param remote
	 *            远程文件路径
	 * @param local
	 *            本地文件路径
	 * @param suffix
	 *            临时文件使用的后缀
	 * @return 是否下载成功
	 * @throws FileSystemException
	 */
	public void downFile(String remote, String local, String suffix) throws FileSystemException;

	public StandardFileSystemManager getManager();
}
