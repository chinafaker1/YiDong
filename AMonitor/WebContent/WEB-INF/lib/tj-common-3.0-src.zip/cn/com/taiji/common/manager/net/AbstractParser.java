package cn.com.taiji.common.manager.net;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午10:08:01
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractParser
{
	protected Logger logger = LoggerFactory.getLogger(getClass());

	protected static final String UTF8 = "UTF-8";
	protected static final String GBK = "GBK";
	protected static final String ISO8859 = "ISO8859-1";
}
