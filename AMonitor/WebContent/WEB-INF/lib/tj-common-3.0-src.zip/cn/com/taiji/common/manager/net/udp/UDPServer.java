package cn.com.taiji.common.manager.net.udp;

import java.io.IOException;

import org.xsocket.datagram.UserDatagram;

import cn.com.taiji.common.manager.LifecycleService;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-13 下午05:28:05
 * @since 1.0
 * @version 1.0
 */
public interface UDPServer extends LifecycleService
{
	public void send(UserDatagram datagram) throws IOException;
}
