/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.file.FileProtocolConstant;
import cn.com.taiji.common.model.file.FileProtocolRequest;
import cn.com.taiji.common.model.file.FileProtocolResponse;
import cn.com.taiji.common.model.file.FileProtocolSystemError;
import cn.com.taiji.common.model.file.HandleFileProtocolEvent;
import cn.com.taiji.common.pub.IPTools;
import cn.com.taiji.common.pub.NumberTools;
import cn.com.taiji.common.pub.SecurityUtil;
import cn.com.taiji.common.pub.SecurityUtil.HashType;
import cn.com.taiji.common.pub.file.FileTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午3:12:35<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractHttpFileCommHandleManager extends AbstractCommHandleManager implements
		HttpFileCommHandleManager
{
	private final List<FileCommHandleListener> listeners = new ArrayList<FileCommHandleListener>();

	@Override
	public void addListener(FileCommHandleListener listener)
	{
		if (listener != null) listeners.add(listener);
	}

	protected AbstractHttpFileCommHandleManager()
	{

	}

	@Override
	public final FileProtocolResponse handleComm(FileProtocolRequest protocol, HttpServletRequest request,
			HttpServletResponse response)
	{
		checkFileProtocol(protocol);
		InputStream binFile = protocol.getBinFile();
		File tmpFile = protocol.getTmpFile();
		HandleFileProtocolEvent event = HandleFileProtocolEvent.newInstance(protocol, request);
		long begin = System.currentTimeMillis();
		if (tmpFile != null) logger.debug("本次请求使用了文件中转，请求大小:{}", NumberTools.bytesAsHumanStr(tmpFile.length()));
		try
		{
			if (!checkAuth(protocol, request))
			{
				FileProtocolResponse rs = FileProtocolSystemError.AUTH_FAILED.newResponse();
				sendEvent(event.setResponse(rs).setExecTime(System.currentTimeMillis() - begin));
				return rs;
			}
			if (!checkRequestMd5(protocol, request))
			{
				FileProtocolResponse rs = FileProtocolSystemError.MD5_FAILED.newResponse();
				sendEvent(event.setResponse(rs).setExecTime(System.currentTimeMillis() - begin));
				return rs;
			}
			FileProtocolResponse rs = handleRequest(protocol.getFilename(), binFile, request);
			checkFileProtocol(rs);
			setResponseMd5(rs, request, response);// 设置返回的md5
			sendEvent(event.setResponse(rs).setExecTime(System.currentTimeMillis() - begin));
			File rsTmpFile = rs.getTmpFile();
			if (rsTmpFile != null)
				logger.debug("本次响应使用了文件中转，响应大小:{}", NumberTools.bytesAsHumanStr(rsTmpFile.length()));
			return rs;
		}
		catch (IOException e)
		{
			logger.error("", e);
			throw new RuntimeException(e.getMessage());
		}
		finally
		{
			if (binFile != null)
			{
				closeQuietly(binFile);
				if (protocol.needDeleteTmp() && !tmpFile.delete())
					logger.error("delete FileProtocolRequest tmpfile failed:{}", tmpFile.getAbsolutePath());
			}
		}
	}

	private void sendEvent(HandleFileProtocolEvent event) throws IOException
	{
		for (FileCommHandleListener listener : listeners)
		{
			if (event.getRequest().getTmpFile() == null) event.getRequest().getBinFile().reset();// request已经被使用
			listener.fileCommHandled(event);
			// 重置内存中的数据流为可以重新读取
			if (event.getResponse().getTmpFile() == null) event.getResponse().getBinFile().reset();
		}
	}

	private void setResponseMd5(FileProtocolResponse rs, HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		String md5 = request.getHeader(FileProtocolConstant.MD5_HEADER.getValue());
		if (!hasText(md5)) return;// 请求时没有MD5，响应也不提供MD5
		String rsMd5;
		if (rs.getTmpFile() == null)//
		{
			rsMd5 = SecurityUtil.hash(rs.getBinFile(), HashType.MD5, true);
			rs.getBinFile().reset();// 重置读取顺序
		}
		else
		{
			rsMd5 = SecurityUtil.hash(rs.getTmpFile(), HashType.MD5, true);
		}
		response.setHeader(FileProtocolConstant.MD5_HEADER.getValue(), rsMd5);
		logger.debug("set response md5:{}", rsMd5);
	}

	/**
	 * 校验请求数据的MD5值
	 * 
	 * @param protocol
	 * @param request
	 * @return
	 * @throws IOException
	 */
	private boolean checkRequestMd5(FileProtocolRequest protocol, HttpServletRequest request) throws IOException
	{
		String md5 = request.getHeader(FileProtocolConstant.MD5_HEADER.getValue());
		if (!hasText(md5)) return true;
		String localMd5;
		if (protocol.getTmpFile() == null)//
		{
			localMd5 = SecurityUtil.hash(protocol.getBinFile(), HashType.MD5, true);
			protocol.getBinFile().reset();// 重置读取顺序
		}
		else
		{
			localMd5 = SecurityUtil.hash(protocol.getTmpFile(), HashType.MD5, true);
		}
		logger.debug("remoteMd5={}\t\tlocalMd5={}", md5, localMd5);
		if (!md5.equalsIgnoreCase(localMd5))
		{
			logger.warn("remoteMd5={}\t\tlocalMd5={} not equal.", md5, localMd5);
			return false;
		}
		return true;
	}

	/**
	 * 使用UUID在临时目录下生成一个文件
	 * 
	 * @param filename
	 * @return
	 */
	protected File generateTmpFile(String filename)
	{
		File rs = new File(FileHelper.getTmpPath() + "/" + FileTools.generateUUIDName(filename));
		return rs;
	}

	/**
	 * 实现鉴权校验(鉴权信息在http header中),可以通过request取得对方IP等
	 * 
	 * @param protocol
	 * @param request
	 * @return
	 * @throws IOException
	 * @see {@link FileProtocolConstant#AUTH_HEADER} {@link IPTools#getIpAddr(HttpServletRequest)}
	 */
	protected abstract boolean checkAuth(FileProtocolRequest protocol, HttpServletRequest request) throws IOException;

	/**
	 * 
	 * @param filename
	 * @param fs
	 * @param request
	 * @return
	 */
	protected abstract FileProtocolResponse handleRequest(String filename, InputStream fs, HttpServletRequest request);
}
