package cn.com.taiji.common.pub;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ocpsoft.pretty.time.PrettyTime;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:22:38
 * @since 1.0
 * @Version 1.0
 */
public abstract class TimeTools
{
	protected static Logger logger = LoggerFactory.getLogger(TimeTools.class);
	public static final long DAYTIME = 86400000;

	/**
	 * 取得一天首尾的时间字符串。（yyyy-MM-dd HH:mm:ss）
	 * 
	 * @param year
	 *            年
	 * @param month
	 *            月（1-12）
	 * @param day
	 *            日（1-31）
	 * @return [0]放天首字符串，[1]放天尾字符串。
	 */
	public static String[] getInDay(int year, int month, int day)
	{
		checkPara(year, month, day);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String strs[] = new String[2];
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, day, 0, 0, 0);
		strs[0] = format.format(cal.getTime());
		cal.setTimeInMillis(cal.getTimeInMillis() + DAYTIME);
		strs[1] = format.format(cal.getTime());
		return strs;
	}

	public static List<Calendar> getInDay(String dayStr)
	{
		if (!StringTools.hasText(dayStr)) return null;
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<Calendar> rs = new ArrayList<Calendar>();
		Calendar begin = getCalendar(format, dayStr + " 00:00:00");
		rs.add(begin);
		Calendar end = getCalendar(format, dayStr + " 23:59:59");
		rs.add(end);
		return rs;
	}

	public static Calendar[] asBetweenDay()
	{
		return asBetweenDay(Calendar.getInstance());
	}

	/**
	 * 取得指定时间的一天内的时间
	 * 
	 * @param cal
	 * @return
	 */
	public static Calendar[] asBetweenDay(Calendar cal)
	{
		if (cal == null) return new Calendar[] { null, null };
		Calendar[] rs = new Calendar[2];
		Calendar begin = (Calendar) cal.clone();
		begin.set(Calendar.HOUR_OF_DAY, 0);
		begin.set(Calendar.MINUTE, 0);
		begin.set(Calendar.SECOND, 0);
		begin.set(Calendar.MILLISECOND, 0);
		rs[0] = begin;
		Calendar end = (Calendar) cal.clone();
		end.set(Calendar.HOUR_OF_DAY, 23);
		end.set(Calendar.MINUTE, 59);
		end.set(Calendar.SECOND, 59);
		end.set(Calendar.MILLISECOND, 999);
		rs[1] = end;
		return rs;
	}

	/**
	 * 取得一月首尾的时间字符串。（yyyy-MM-dd）
	 * 
	 * @param year
	 *            年
	 * @param month
	 *            月（1-12）
	 * @return [0]放月首字符串，[1]放月尾字符串。
	 */
	public static String[] getInMonth(int year, int month)
	{
		checkPara(year, month);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String strs[] = new String[2];
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, 1, 0, 0, 0);
		strs[0] = format.format(cal.getTime());
		cal.set(year, month, 1, 0, 0, 0);
		strs[1] = format.format(cal.getTime());
		return strs;
	}

	/**
	 * 取得一年首尾的时间字符串。（yyyy-MM）
	 * 
	 * @param year
	 *            年
	 * @return [0]放年首字符串，[1]放年尾字符串。
	 */
	public static String[] getInYear(int year)
	{
		checkPara(year);
		DateFormat format = new SimpleDateFormat("yyyy-MM");
		String strs[] = new String[2];
		Calendar cal = Calendar.getInstance();
		cal.set(year, 0, 1, 0, 0, 0);
		strs[0] = format.format(cal.getTime());
		cal.set(year + 1, 0, 1, 0, 0, 0);
		strs[1] = format.format(cal.getTime());
		return strs;
	}

	/**
	 * 取得日时间字符串。（yyyy-MM-dd）
	 * 
	 * @param year
	 *            年
	 * @param month
	 *            月（1-12）
	 * @param day
	 *            日（1-31）
	 * @return 返回指定年月日的日时间字符串。
	 */
	public static String getDayStr(int year, int month, int day)
	{
		checkPara(year, month, day);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, day, 0, 0, 0);
		return format.format(cal.getTime());
	}

	/**
	 * 取得月时间字符串。（yyyy-MM）
	 * 
	 * @param year
	 *            年
	 * @param month
	 *            月（1-12）
	 * @return 返回指定年月的月时间字符串
	 */
	public static String getMonthStr(int year, int month)
	{
		checkPara(year, month);
		DateFormat format = new SimpleDateFormat("yyyy-MM");
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, 1, 0, 0, 0);
		return format.format(cal.getTime());
	}

	/**
	 * 取得年时间字符串。（yyyy）
	 * 
	 * @param year
	 *            年
	 * @return 返回指定年的年时间字符串
	 */
	public static String getYearStr(int year)
	{
		checkPara(year);
		DateFormat format = new SimpleDateFormat("yyyy");
		Calendar cal = Calendar.getInstance();
		cal.set(year, 0, 1, 0, 0, 0);
		return format.format(cal.getTime());
	}

	/**
	 * 取得时间字符串。（yyyy-MM-dd HH:mm:ss）
	 * 
	 * @param time
	 *            时间（毫秒数）
	 * @return 指定毫秒数得到的时间字符串。
	 */
	public static String toTimeStr(long time)
	{
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(new Date(time));
	}

	public static String toTimeStr(Calendar time)
	{
		return time == null ? "" : toTimeStr(time.getTimeInMillis());
	}

	/**
	 * 取得当前时间字符串。（yyyy-MM-dd HH:mm:ss）
	 * 
	 * @return 当前的时间字符串。
	 */
	public static String toTimeStr()
	{
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(Calendar.getInstance().getTime());
	}

	public static String toTimeAllStr(long time)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(time);
		DateFormat format = new SimpleDateFormat("HH:mm:ss");
		return format.format(cal.getTime());
	}

	public static String getCnDateTimeStr(Calendar cal)
	{
		if (cal == null) return "";
		return getCnDateStr(toDayStr(cal.getTimeInMillis())) + getCnTimeStr(toTimeAllStr(cal.getTimeInMillis()));
	}

	public static String getCnDateStr(String date)
	{
		String[] dates = date.split("-");
		if (dates == null || dates.length != 3) return "0月0日";
		return dates[1] + "月" + dates[2] + "日";
	}

	public static String getCnTimeStr(String time)
	{
		String[] times = time.split(":");
		if (times == null || times.length < 2) return "0时0分";
		return times[0] + "时" + times[1] + "分";
	}

	/**
	 * 取得时间字符串。（yyyy-MM-dd HH:mm:ss） zzq (zzq98_2000@hotmail.com)
	 * 
	 * @param time
	 * @return
	 */
	public static String toDateTimeStr(Calendar cal)
	{
		return (cal == null) ? "" : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(cal.getTime());
	}

	/**
	 * 取得日时间字符串。（yyyy-MM-dd）
	 * 
	 * @param time
	 *            时间（毫秒数）
	 * @return 指定时间的日时间字符串。
	 */
	public static String toDayStr(long time)
	{
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date(time));
	}

	public static String toDayStr(Calendar time)
	{
		return time == null ? "" : toDayStr(time.getTimeInMillis());
	}

	/**
	 * 取得当前日时间字符串。（yyyy-MM-dd）
	 * 
	 * @return 当前的日时间字符串。
	 */
	public static String toDayStr()
	{
		Calendar cal = Calendar.getInstance();
		return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
	}

	/**
	 * 取得月时间字符串。（yyyy-MM）
	 * 
	 * @param time
	 *            时间（毫秒数）
	 * @return 指定时间的月时间字符串。
	 */
	public static String toMonthStr(long time)
	{
		return new SimpleDateFormat("yyyy-MM").format(new Date(time));
	}

	public static String toMonthStr(Calendar time)
	{
		return time == null ? "" : toMonthStr(time.getTimeInMillis());
	}

	/**
	 * 取得当前月时间字符串。（yyyy-MM）
	 * 
	 * @return 当前的月时间字符串。
	 */
	public static String toMonthStr()
	{
		return new SimpleDateFormat("yyyy-MM").format(Calendar.getInstance().getTime());
	}

	/**
	 * 取得年时间字符串。（yyyy）
	 * 
	 * @param time
	 *            时间（毫秒数）
	 * @return 指定时间的年时间字符串。
	 */
	public static String toYearStr(long time)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(time);
		return new SimpleDateFormat("yyyy").format(cal.getTime());
	}

	/**
	 * 取得当前年时间字符串。（yyyy）
	 * 
	 * @return 当前的年时间字符串。
	 */
	public static String toYearStr()
	{
		Calendar cal = Calendar.getInstance();
		return new SimpleDateFormat("yyyy").format(cal.getTime());
	}

	/**
	 * 由时间字符串取得对应时间的Calendar
	 * 
	 * @param format
	 *            时间字符串对应的格式
	 * @param timeStr
	 *            时间字符串
	 * @return 时间字符串对应的Calendar，如果时间字符串与格式不对应，将返回null
	 */
	public static Calendar getCalendar(DateFormat format, String timeStr)
	{
		try
		{
			Date date = format.parse(timeStr);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			return cal;
		}
		catch (Exception e)
		{
			logger.error("", e);
			return null;
		}
	}

	public static Calendar getCalendar(String timeStr)
	{
		return getCalendar(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"), timeStr);
	}

	/**
	 * 自定义日期格式，返回calendar
	 * 
	 * @param format
	 * @param timeStr
	 * @return
	 */
	public static Calendar getCalendar(String format, String timeStr)
	{
		return getCalendar(new SimpleDateFormat(format), timeStr);
	}

	/**
	 * 返回一年之间的日期.
	 * 
	 * @param year
	 * @return
	 */
	public static Calendar[] getBetweenYear(int year)
	{
		checkPara(year);
		Calendar[] result = new Calendar[] { Calendar.getInstance(), Calendar.getInstance() };
		result[0].set(Calendar.MILLISECOND, 0);
		result[1].set(Calendar.MILLISECOND, 0);
		result[0].set(year, 0, 1, 0, 0, 0);
		result[1].set(year + 1, 0, 1, 0, 0, 0);
		return result;
	}

	/**
	 * 返回一月之间的日期
	 * 
	 * @param year
	 * @param month
	 * @return
	 */
	public static Calendar[] getBetweenMonth(int year, int month)
	{
		checkPara(year, month);
		Calendar[] result = new Calendar[] { Calendar.getInstance(), Calendar.getInstance() };
		result[0].set(Calendar.MILLISECOND, 0);
		result[1].set(Calendar.MILLISECOND, 0);
		result[0].set(year, month - 1, 1, 0, 0, 0);
		result[1].set(year, month, 1, 0, 0, 0);
		return result;
	}

	public static Calendar[] getBetweenDay(int year, int month, int day)
	{
		checkPara(year, month, day);
		Calendar[] result = new Calendar[] { getOnlyDay(null), getOnlyDay(null) };
		result[0].set(year, month - 1, day, 0, 0, 0);
		result[1].set(year, month - 1, day, 23, 59, 59);
		return result;
	}

	public static List<Calendar> getCalendars(String begStr, String endStr)
	{
		List<Calendar> times = new ArrayList<Calendar>();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (StringTools.hasText(begStr) && StringTools.hasText(endStr))
		{
			times.add(TimeTools.getCalendar(format, begStr));
			times.add(TimeTools.getCalendar(format, endStr));
		}
		else if (StringTools.hasText(begStr))
		{
			times.add(TimeTools.getCalendar(format, begStr));
			times.add(Calendar.getInstance());
		}
		else if (StringTools.hasText(endStr))
		{
			times.add(Calendar.getInstance());
			times.add(TimeTools.getCalendar(format, endStr));
		}
		return times;
	}

	/**
	 * 获取指定时间到指定时间之前几天的时间间隔
	 * 
	 * @param time
	 *            指定时间
	 * @param dayBefore
	 *            几天以前
	 * @return
	 */
	public static Calendar[] getCalendars(Calendar time, int dayBefore)
	{
		if (time == null) return null;
		Calendar[] times = new Calendar[2];
		Calendar end = Calendar.getInstance();
		end.setTimeInMillis(time.getTimeInMillis());
		Calendar begin = Calendar.getInstance();
		begin.setTimeInMillis(time.getTimeInMillis());
		begin.add(Calendar.DAY_OF_MONTH, 0 - dayBefore);
		times[0] = begin;
		times[1] = end;
		return times;
	}

	/**
	 * 
	 * @param cal
	 * @return
	 * @see {@link #asBetweenDay(Calendar)}
	 */
	@Deprecated
	public static Calendar[] getBetweenDay(Calendar cal)
	{
		Calendar[] cals = new Calendar[2];
		if (cal == null) cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int date = cal.get(Calendar.DAY_OF_MONTH);
		Calendar begin = getOnlyDay(null);
		begin.set(year, month, date, 0, 0, 0);
		cals[0] = begin;
		Calendar end = getOnlyDay(null);
		end.set(year, month, date, 23, 59, 59);
		cals[1] = end;
		return cals;
	}

	/**
	 * 时间之差,END比BEG大，返回正整数，否则为负整数 Date：2007-8-22 author: ZZQ (zzq98_2000@hotmail.com)
	 * 
	 * @param beg
	 * @param end
	 * @param type
	 * @return
	 */
	public static int getCalendarBySpace(Calendar beg, Calendar end, String type)
	{
		long space = end.getTimeInMillis() - beg.getTimeInMillis();
		long time = 1000;
		long dtime = time * 60 * 60 * 24; // A day in milliseconds
		long htime = time * 60 * 60;// A hour in milliseconds
		long mtime = time * 60; // A minute in milliseconds
		int d = (int) (space / dtime);

		if ("dd".equals(type)) return d;
		if ("HH".equals(type)) return (int) (space / htime);
		if ("mm".equals(type)) return (int) (space / mtime);
		if ("ss".equals(type)) return (int) (space / time);

		return (int) (space);
	}

	/**
	 * 两个时间之间的天数差,精度到天。比如"2009-07-23 00:01:00"和"2009-07-26 11:10:11"相差3天<BR>
	 * "2009-07-23 23:59:00"和"2009-07-26 00:10:11"相差也是3天
	 * 
	 * @param begin
	 * @param end
	 * @return
	 */
	public static int getDayInterval(Calendar begin, Calendar end)
	{
		AssertUtil.notNull(begin);
		AssertUtil.notNull(end);
		if (end.before(begin)) throw new IllegalArgumentException("结束日期请晚于开始日期");
		Calendar ref = (Calendar) begin.clone();
		ref.set(Calendar.HOUR_OF_DAY, 0);
		ref.set(Calendar.MINUTE, 0);
		ref.set(Calendar.SECOND, 0);
		ref.set(Calendar.MILLISECOND, 0);
		long space = end.getTimeInMillis() - ref.getTimeInMillis();
		return Long.valueOf(space / 86400000).intValue();
	}

	public static String asHumanStr(long space)
	{
		String suffix = "";
		if (space < 0)
		{
			space = -space;
			suffix = "前";
		}
		if (space >= 0 && space < 1000) return space + "毫秒" + suffix;
		StringBuilder rs = new StringBuilder();
		int d = (int) (space / 86400000);
		if (d > 0) rs.append(d).append("天");

		int h = (int) (space / 3600000 - (d * 24));
		if (h > 0) rs.append(h).append("小时");

		int m = (int) (space / 60000 - (d * 24 * 60) - (h * 60));
		if (m > 0) rs.append(m).append("分");

		int s = (int) (space / 1000) - (d * 24 * 60 * 60) - (h * 60 * 60) - (m * 60);
		if (s > 0) rs.append(s).append("秒");

		rs.append(suffix);
		return rs.toString();
	}

	public static boolean isForward(Calendar beg, Calendar end)
	{
		if (beg == null || end == null) return false;
		if (end.getTimeInMillis() - beg.getTimeInMillis() >= 0)
			return true;
		else
			return false;
	}

	public static java.sql.Date[] getDates(Calendar[] cals)
	{
		java.sql.Date[] dates = new java.sql.Date[2];
		if (cals == null || cals.length != 2) return dates;
		dates[0] = new java.sql.Date(cals[0].getTimeInMillis());
		dates[1] = new java.sql.Date(cals[1].getTimeInMillis());
		return dates;
	}

	/**
	 * 
	 * @param year
	 * @param month
	 * @return
	 */
	public static int getTotalDayOfMonth(int year, int month)
	{
		checkPara(year, month);
		int days = 31;
		switch (month)
		{
		case 2:
			if (year % 100 == 0)
			{
				if (year % 400 == 0)
				{
					days = 29;
					break;
				}
			}
			else if (year % 4 == 0)
			{
				days = 29;
				break;
			}
			days = 28;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			days = 30;
			break;
		}
		return days;
	}

	/**
	 * <code>转换时间参数以返回长度为2且内容都不为null的Calendar[]</code>
	 * 
	 * @param times
	 * @return
	 */
	public static Calendar[] getConditionTimes(Calendar[] times)
	{
		Calendar[] myTimes = new Calendar[2];
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		if (times != null && times.length == 2)
		{
			if (times[0] == null)
				myTimes[0] = getCalendar(format, "1882-07-26");
			else
				myTimes[0] = times[0];
			if (times[1] == null)
				myTimes[1] = getCalendar(format, "2050-02-16");
			else
				myTimes[1] = times[1];
		}
		else
		{
			myTimes[0] = getCalendar(format, "1981-02-16");
			myTimes[1] = getCalendar(format, "2050-02-16");
		}
		return myTimes;
	}

	/**
	 * 只返回日期的时间
	 * 
	 * @param time
	 * @return
	 */
	public static Calendar getOnlyDay(Calendar time)
	{
		if (time == null) time = Calendar.getInstance();
		Calendar tmp = (Calendar) time.clone();
		tmp.set(Calendar.HOUR_OF_DAY, 0);
		tmp.set(Calendar.MINUTE, 0);
		tmp.set(Calendar.SECOND, 0);
		tmp.set(Calendar.MILLISECOND, 0);
		return tmp;
	}

	public static String toPrettyStr(Calendar time, String languange)
	{
		AssertUtil.notNull(time);
		String lan = StringTools.hasText(languange) ? languange : "zh";
		PrettyTime p = new PrettyTime(new Locale(lan));
		return p.format(time.getTime());
	}

	private static void checkPara(int year, int month, int day)
	{
		if (year < 1) throw new RuntimeException("年时间参数错误。");
		if (month < 1 || month > 12) throw new RuntimeException("月时间参数错误。");
		if (day < 1 || day > 31) throw new RuntimeException("日时间参数错误。");
	}

	private static void checkPara(int year, int month)
	{
		if (year < 1) throw new RuntimeException("年时间参数错误。");
		if (month < 1 || month > 12) throw new RuntimeException("月时间参数错误。");
	}

	private static void checkPara(int year)
	{
		if (year < 1) throw new RuntimeException("年时间参数错误。");
	}

}
