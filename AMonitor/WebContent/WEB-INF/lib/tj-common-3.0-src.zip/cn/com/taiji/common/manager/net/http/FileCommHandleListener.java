/*
 * Date: 2015年5月15日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import cn.com.taiji.common.model.file.HandleFileProtocolEvent;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年5月15日 上午9:01:15<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface FileCommHandleListener
{
	/**
	 * 处理监听事件
	 * 
	 * @param event
	 *            fileComm完成时触发事件
	 */
	public void fileCommHandled(HandleFileProtocolEvent event);
}
