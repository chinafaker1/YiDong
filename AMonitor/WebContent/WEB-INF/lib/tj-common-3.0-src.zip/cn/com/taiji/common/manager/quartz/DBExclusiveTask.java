package cn.com.taiji.common.manager.quartz;

import java.util.Date;
import java.util.Map;

import javax.sql.DataSource;

import cn.com.taiji.common.model.quartz.CronExclusiveTask;
import cn.com.taiji.common.pub.AssertUtil;

import com.google.common.collect.Maps;

/**
 * 通过DB中的表进行互斥的独占任务，同一时刻最多只有一个任务在运行
 * 
 * @author Peream <br>
 *         Create Time：2013-4-23 下午12:45:34<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class DBExclusiveTask extends AbstractClusterRunnableProxy implements RunnableProxy
{
	private final static Map<String, CronExclusiveTaskDao> daos = Maps.newConcurrentMap();
	private final String tableName;
	private final long maxExecuteMills;
	private final DataSource ds;

	/**
	 * 
	 * @param task
	 *            具体干活的任务
	 * @param ds
	 *            访问数据库的数据源
	 * @param taskName
	 *            任务名字（确保唯一）
	 * @param maxExecuteSeconds
	 *            任务预计最长的执行时间（设置时一般比任务实际运行时间稍长些）。<BR>
	 *            当任务异常终止时，上次开始运行时间到现在超过了定义的最长执行时间，任务也会再启动
	 */
	public DBExclusiveTask(Runnable task, DataSource ds, String taskName, int maxExecuteSeconds)
	{
		this(task, "cron_exclusive_task", ds, taskName, maxExecuteSeconds);
	}

	/**
	 * 
	 * @param task
	 *            具体干活的任务
	 * @param tableName
	 *            记录任务执行信息的表名
	 * @param ds
	 *            访问数据库的数据源
	 * @param taskName
	 *            任务名字（确保唯一）
	 * @param maxExecuteSeconds
	 *            任务预计最长的执行时间（设置时一般比任务实际运行时间稍长些）。<BR>
	 *            当任务异常终止时，上次开始运行时间到现在超过了定义的最长执行时间，任务也会再启动
	 */
	public DBExclusiveTask(Runnable task, String tableName, DataSource ds, String taskName, int maxExecuteSeconds)
	{
		this(task, tableName, ds, taskName, null, maxExecuteSeconds);
	}

	/**
	 * 
	 * @param task
	 *            具体干活的任务
	 * @param tableName
	 *            记录任务执行信息的表名
	 * @param ds
	 *            访问数据库的数据源
	 * @param taskName
	 *            任务名字（确保唯一）
	 * @param listener
	 *            任务监听器
	 * @param maxExecuteSeconds
	 *            任务预计最长的执行时间（设置时一般比任务实际运行时间稍长些）。<BR>
	 *            当任务异常终止时，上次开始运行时间到现在超过了定义的最长执行时间，任务也会再启动
	 */
	public DBExclusiveTask(Runnable task, String tableName, DataSource ds, String taskName, TaskListener listener,
			int maxExecuteSeconds)
	{
		super(task, taskName, listener);
		AssertUtil.notNull(ds);
		this.tableName = tableName;
		this.ds = ds;
		this.maxExecuteMills = 1000L * maxExecuteSeconds;
	}

	public CronExclusiveTask init()
	{
		CronExclusiveTask task = getDao().findById(taskName);
		if (task == null)
		{
			getDao().add(newCronTask());
			logger.info("task is null,init task to false first:{}", task);
		}
		task = getDao().findById(taskName);
		return task;
	}

	@Override
	public void run()
	{
		CronExclusiveTask status = init();
		if (isRunning())
		{
			logger.info("{} 任务正在运行,本次任务调用忽略.", taskName);
			return;
		}
		try
		{
			boolean rs = updateStatus(status, true);// 更新数据库中的任务运行状态
			if (rs)
			{
				taskRunning.set(true);
				super.doTask();
			}
			else
				logger.info("本节点({})请求开始任务失败,不运行任务:{}", nodeTag, taskName);
		}
		finally
		{
			if (taskRunning.get())
			{
				taskRunning.set(false);
				updateStatus(status, false);
			}
		}
	}

	private boolean updateStatus(CronExclusiveTask status, boolean running)
	{
		status.setRunning(running);
		status.setNodeTag(nodeTag);
		status.setUpdateTime(new Date());
		if (running)
		{
			return getDao().updateSync(status);
		}
		else
		{
			getDao().update(status);
			return true;
		}
	}

	public boolean isRunning()
	{
		if (taskRunning.get()) return true;
		CronExclusiveTask status = getDao().findById(taskName);
		if (status == null) return false;
		// 任务运行时间超过最大运行时间
		long interval = System.currentTimeMillis() - status.getUpdateTime().getTime();
		if (interval > maxExecuteMills) return false;// 间隔时间超过最大运行时间，说明任务因为异常情况关闭了，返回false以便下次能够运行
		return status.isRunning();
	}

	private CronExclusiveTaskDao getDao()
	{
		CronExclusiveTaskDao dao = daos.get(taskName);
		if (dao != null) return dao;
		dao = new CronExclusiveTaskDao(ds, tableName);
		daos.put(taskName, dao);
		return dao;
	}
}