package cn.com.taiji.common.web.bind.support;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import cn.com.taiji.common.pub.StringTools;


/**
 * 在客户端与服务器端自动转换Calendar日期类型
 * 
 * @author TOM Email:tomesc@msn.com
 * 
 */
public class CustomCalendarEditor extends PropertyEditorSupport
{
	private boolean onlyDate;

	public CustomCalendarEditor(boolean onlyDate)
	{
		this.onlyDate = onlyDate;
	}

	public void setAsText(String text)
	{
		if (!StringTools.hasText(text))
		{
			// Treat empty String as null value.
			setValue(null);
			return;
		}
		try
		{
			Calendar c = Calendar.getInstance();
			if (text.contains(":"))
			{
				SimpleDateFormat normalDf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				normalDf.setLenient(false);
				c.setTime(normalDf.parse(text));
			}
			else
			{
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				df.setLenient(false);
				c.setTime(df.parse(text));
			}
			setValue(c);
		}
		catch (ParseException ex)
		{
			IllegalArgumentException iae = new IllegalArgumentException("Could not parse date: "
					+ ex.getMessage());
			iae.initCause(ex);
			throw iae;
		}
	}

	public String getAsText()
	{
		Calendar value = (Calendar) getValue();
		if (value == null) return "";
		return onlyDate ? new SimpleDateFormat("yyyy-MM-dd").format(value.getTime())
				: new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(value.getTime());
	}

}
