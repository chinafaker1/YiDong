package cn.com.taiji.common.manager;

import java.io.IOException;
import java.util.Collection;

import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.pub.json.JsonTools;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2012-7-3 上午9:44:38<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class JsonManagerException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5157296594227839133L;
	private String jsonStr;

	public JsonManagerException()
	{
		super();
	}

	public JsonManagerException(String message)
	{
		super(message);
	}

	public JsonManagerException(BaseEntity entity)
	{
		this.jsonStr = entity == null ? "" : entity.toJson();
	}

	public JsonManagerException(String message, BaseEntity entity)
	{
		super(message);
		this.jsonStr = entity == null ? "" : entity.toJson();
	}

	public JsonManagerException(String message, Throwable cause, BaseEntity entity)
	{
		super(message, cause);
		this.jsonStr = entity == null ? "" : entity.toJson();
	}

	public JsonManagerException(Collection<? extends BaseEntity> collection)
	{
		this.jsonStr = collection2Json(collection);
	}

	public JsonManagerException(String message, Collection<? extends BaseEntity> collection)
	{
		super(message);
		this.jsonStr = collection2Json(collection);
	}

	public JsonManagerException(String message, Throwable cause, Collection<? extends BaseEntity> collection)
	{
		super(message, cause);
		this.jsonStr = collection2Json(collection);
	}

	public JsonManagerException(String message, Throwable cause)
	{
		super(message, cause);
	}

	private String collection2Json(Collection<? extends BaseEntity> collection)
	{
		try
		{
			return collection == null ? "" : JsonTools.toJsonStr(collection);
		}
		catch (IOException e)
		{
			return "";
		}
	}

	public String getJsonStr()
	{
		return jsonStr;
	}

}
