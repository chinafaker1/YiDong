/*
 * Date: 2013-4-23
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import cn.com.taiji.common.model.quartz.CronExclusiveTask;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-4-23 下午12:57:39<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CronExclusiveTaskDao extends JdbcDaoSupport implements RowMapper<CronExclusiveTask>
{
	private final String tableName;
	private final TransactionTemplate txTemplate;

	public CronExclusiveTaskDao(DataSource ds, String tableName)
	{
		setDataSource(ds);
		this.txTemplate = new TransactionTemplate(new DataSourceTransactionManager(ds));
		this.tableName = tableName;
	}

	/**
	 * 将最后更新时间与当前时间比较，当超过给定的秒数时，将任务中运行状态为true的任务改成false<BR>
	 * 主要是处理那些正在运行的任务因异常停止导致数据库中状态未更新的情况
	 * 
	 * @param overSeconds
	 */
	public void resetTask(int overSeconds)
	{
		String sql = "select * from " + tableName + " where running=? order by update_time asc";
		List<CronExclusiveTask> list = getJdbcTemplate().query(sql, new Object[] { true }, this);
		Calendar now = Calendar.getInstance();
		for (CronExclusiveTask task : list)
		{
			Calendar update = Calendar.getInstance();
			update.setTime(task.getUpdateTime());
			update.add(Calendar.SECOND, overSeconds);
			if (update.before(now))
			{
				task.setRunning(false);
				updateSync(task);
			}
		}
	}

	public CronExclusiveTask findById(String id)
	{
		String sql = "select * from " + tableName + " where id=?";
		List<CronExclusiveTask> list = getJdbcTemplate().query(sql, new Object[] { id }, this);
		return list.size() > 0 ? list.get(0) : null;
	}

	public void add(CronExclusiveTask task)
	{
		String sql = "insert into " + tableName + " (id,running,update_time,node_tag,md5) values (?,?,?,?,?)";
		getJdbcTemplate().update(sql, task.getId(), task.isRunning(), task.getUpdateTime(), task.getNodeTag(),
				task.genMD5());
	}

	public void update(CronExclusiveTask task)
	{
		String sql = "update " + tableName + " set running=?,update_time=?,node_tag=?,md5=? where id=?";
		getJdbcTemplate().update(sql, task.isRunning(), task.getUpdateTime(), task.getNodeTag(), task.genMD5(),
				task.getId());
	}

	public boolean updateSync(final CronExclusiveTask task)
	{
		return txTemplate.execute(new TransactionCallback<Boolean>() {
			@Override
			public Boolean doInTransaction(TransactionStatus status)
			{
				try
				{
					return doUpdateSync(task);
				}
				catch (Exception e)
				{
					status.setRollbackOnly();
					return false;
				}
			}
		});
	}

	private boolean doUpdateSync(CronExclusiveTask task)
	{
		String sql = "select * from " + tableName + " where id=? for update";
		List<CronExclusiveTask> list = getJdbcTemplate().query(sql, new Object[] { task.getId() }, this);
		CronExclusiveTask old = list.size() > 0 ? list.get(0) : null;
		if (old == null) return false;
		if (old.getMd5().equals(task.getMd5()))// 待更新的值和原来查询出来的一致，可以更新
		{
			sql = "update " + tableName + " set running=?,update_time=?,node_tag=?,md5=? where id=?";
			int count = getJdbcTemplate().update(sql, task.isRunning(), task.getUpdateTime(), task.getNodeTag(),
					task.genMD5(), task.getId());
			return count > 0;
		}
		else
		{
			return false;
		}
	}

	@Override
	public CronExclusiveTask mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		if (rs == null) return null;
		CronExclusiveTask task = new CronExclusiveTask();
		task.setId(rs.getString("id"));
		task.setNodeTag(rs.getString("node_tag"));
		task.setRunning(rs.getBoolean("running"));
		task.setUpdateTime(rs.getTimestamp("update_time"));
		task.setMd5(rs.getString("md5"));
		return task;
	}

}
