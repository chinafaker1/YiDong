package cn.com.taiji.common.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * 基于SEQUENCE的自增ID
 * 
 * @author Peream <br>
 *         Create Time：2009-9-11 上午09:56:47<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class LongSequenceIdEntity extends BaseEntity
{
	protected long id;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "SEQUENCE_STORE")
	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof LongSequenceIdEntity)) return false;
		LongSequenceIdEntity other = (LongSequenceIdEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}
}
