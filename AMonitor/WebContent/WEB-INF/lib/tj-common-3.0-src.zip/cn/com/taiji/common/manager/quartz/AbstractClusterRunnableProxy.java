/*
 * Date: 2013年10月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.util.Date;
import java.util.UUID;

import cn.com.taiji.common.model.quartz.CronExclusiveTask;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年10月12日 下午6:15:46<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractClusterRunnableProxy extends AbstractRunnableProxy
{
	protected final String nodeTag;

	protected AbstractClusterRunnableProxy(Runnable task, String taskName, TaskListener listener)
	{
		super(task, taskName, listener);
		this.nodeTag = getClass().getSimpleName() + "@" + UUID.randomUUID().toString().replace("-", "");
		logger.info("node tag:{}", nodeTag);
	}

	protected CronExclusiveTask newCronTask()
	{
		CronExclusiveTask task = new CronExclusiveTask();
		task.setId(taskName);
		task.setRunning(false);
		task.setNodeTag(nodeTag);
		task.setUpdateTime(new Date());
		return task;
	}
}
