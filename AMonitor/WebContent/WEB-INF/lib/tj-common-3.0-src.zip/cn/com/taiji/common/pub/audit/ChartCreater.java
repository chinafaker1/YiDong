package cn.com.taiji.common.pub.audit;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.text.SimpleDateFormat;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.renderer.category.StackedBarRenderer3D;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleInsets;

/**
 * 本类局限性比较大，不推荐直接调用本类的方法进行图像生成<BR>
 * 请参考本类的写法及Test的写法生成所需图像,另请参考samples.jfreechart.demo
 * 
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:50:36
 * @since 1.0
 * @Version 1.0
 */
public class ChartCreater
{
	public static final Paint LEVEL1 = Color.GREEN;
	public static final Paint LEVEL2 = Color.BLUE;
	public static final Paint LEVEL3 = Color.ORANGE;
	public static final Paint LEVEL4 = Color.RED;
	public static final Paint LEVEL5 = new Color(200, 110, 255);
	public static final Paint LEVEL6 = new Color(60, 150, 255);
	public static final Paint LEVEL7 = new Color(255, 255, 0);
	private static final PieSectionLabelGenerator labelGenerator = new StandardPieSectionLabelGenerator(
			"{0}={1}({2})");

	/**
	 * 
	 * @param dataset
	 * @param chartname
	 * @return
	 */
	public static JFreeChart creat3DPiechart(PieDataset dataset, String chartname)
	{
		JFreeChart chart = ChartFactory.createPieChart3D(chartname, // chart
				dataset, // data
				true, // include legend
				true, // tooltips
				false // urls
				);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		chart.setBackgroundPaint(Color.WHITE);
		PiePlot3D plot = (PiePlot3D) chart.getPlot();
		setPiePlot(dataset, plot);
		return chart;
	}

	public static JFreeChart creatPiechart(PieDataset dataset, String chartname)
	{
		JFreeChart chart = ChartFactory.createPieChart(chartname, // chart
				dataset, // data
				true, // include legend
				true, // tooltips
				false // urls
				);
		chart.setBackgroundPaint(Color.WHITE);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		PiePlot plot = (PiePlot) chart.getPlot();
		setPiePlot(dataset, plot);
		return chart;
	}

	private static void setPiePlot(PieDataset dataset, PiePlot plot)
	{
		plot.setCircular(true);
		int keySize = dataset.getKeys().size();
		plot.setSectionPaint(dataset.getKey(0), LEVEL1);
		if (keySize > 1) plot.setSectionPaint(dataset.getKey(1), LEVEL2);
		if (keySize > 2) plot.setSectionPaint(dataset.getKey(2), LEVEL3);
		if (keySize > 3) plot.setSectionPaint(dataset.getKey(3), LEVEL4);
		if (keySize > 4) plot.setSectionPaint(dataset.getKey(4), LEVEL5);
		if (keySize > 5) plot.setSectionPaint(dataset.getKey(5), LEVEL6);
		if (keySize > 6) plot.setSectionPaint(dataset.getKey(6), LEVEL7);
		plot.setForegroundAlpha(0.8f);
		plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
		plot.setLabelGenerator(labelGenerator);// 对应Label上输出格式
	}

	/**
	 * 
	 * @param dataset
	 * @param chartInfo
	 * @return
	 */
	public static JFreeChart creat3DBarchart(CategoryDataset dataset, ChartInfo chartInfo)
	{
		JFreeChart chart = ChartFactory.createBarChart3D(chartInfo.getChartName(), // 图表标题
				chartInfo.getNameLable(), // 目录轴的显示标签
				chartInfo.getValueLable(), // 数值轴的显示标签
				dataset, // 数据集
				chartInfo.getOrientation(), // 图表方向：水平、垂直
				true, // 是否显示图例(对于简单的柱状图必须是false)
				false, // 是否生成工具
				false // 是否生成URL链接
				);
		chart.setBackgroundPaint(Color.WHITE);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		CategoryPlot plot = chart.getCategoryPlot();

		plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
		plot.setForegroundAlpha(0.6f);

		CategoryAxis domainAxis = plot.getDomainAxis();
		if (chartInfo.isSlantNameLabel())
			domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);// 坐标逆时针45度
		// 设置X轴坐标上的文字
		domainAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置X轴的标题文字
		domainAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		plot.setDomainAxis(domainAxis);

		ValueAxis rangeAxis = plot.getRangeAxis();
		rangeAxis.setUpperMargin(0.1);
		rangeAxis.setLowerMargin(0.1);
		plot.setRangeAxis(rangeAxis);

		NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置Y轴坐标上的文字
		numberaxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置Y轴的标题文字
		numberaxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		StackedBarRenderer3D renderer = new StackedBarRenderer3D(10, 10);
		renderer.setMaximumBarWidth(0.1);// 单个柱子的最大宽度比率
		// set color,if not set,the color will definded by jfreechart.
		renderer.setBaseOutlinePaint(Color.WHITE);
		renderer.setWallPaint(Color.gray);
		renderer.setSeriesPaint(0, LEVEL1);
		renderer.setSeriesPaint(1, LEVEL2);
		renderer.setSeriesPaint(2, LEVEL3);
		renderer.setSeriesPaint(3, LEVEL4);
		renderer.setSeriesPaint(4, LEVEL5);
		renderer.setSeriesPaint(5, LEVEL6);
		renderer.setSeriesPaint(6, LEVEL7);
		renderer.setItemMargin(0.1);
		// 显示每个柱的数值，并修改该数值的字体属性
		renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		renderer.setBaseItemLabelFont(new Font("SansSerif", Font.PLAIN, 9));
		renderer.setBaseItemLabelsVisible(true);
		plot.setRenderer(renderer);

		return chart;
	}

	public static JFreeChart creat3DBarchart2(CategoryDataset dataset, ChartInfo chartInfo)
	{
		JFreeChart chart = ChartFactory.createBarChart3D(chartInfo.getChartName(), // 图表标题
				chartInfo.getNameLable(), // 目录轴的显示标签
				chartInfo.getValueLable(), // 数值轴的显示标签
				dataset, // 数据集
				chartInfo.getOrientation(), // 图表方向：水平、垂直
				true, // 是否显示图例(对于简单的柱状图必须是false)
				false, // 是否生成工具
				false // 是否生成URL链接
				);
		chart.setBackgroundPaint(Color.WHITE);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		CategoryPlot plot = chart.getCategoryPlot();
		plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
		plot.setForegroundAlpha(0.6f);

		CategoryAxis domainAxis = plot.getDomainAxis();
		if (chartInfo.isSlantNameLabel())
			domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);// 坐标逆时针45度
		// 设置X轴坐标上的文字
		domainAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置X轴的标题文字
		domainAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		plot.setDomainAxis(domainAxis);

		ValueAxis rangeAxis = plot.getRangeAxis();
		rangeAxis.setUpperMargin(0.1);
		rangeAxis.setLowerMargin(0.1);
		plot.setRangeAxis(rangeAxis);

		NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置Y轴坐标上的文字
		numberaxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置Y轴的标题文字
		numberaxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		BarRenderer3D renderer = new BarRenderer3D();
		renderer.setMaximumBarWidth(0.1);// 单个柱子的最大宽度比率
		// set color,if not set,the color will definded by jfreechart.
		renderer.setBaseOutlinePaint(Color.WHITE);
		renderer.setWallPaint(Color.gray);
		renderer.setSeriesPaint(0, LEVEL1);
		renderer.setSeriesPaint(1, LEVEL2);
		renderer.setSeriesPaint(2, LEVEL3);
		renderer.setSeriesPaint(3, LEVEL4);
		renderer.setSeriesPaint(4, LEVEL5);
		renderer.setSeriesPaint(5, LEVEL6);
		renderer.setSeriesPaint(6, LEVEL7);
		renderer.setItemMargin(0.1);
		// 显示每个柱的数值，并修改该数值的字体属性
		renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		renderer.setBaseItemLabelFont(new Font("SansSerif", Font.PLAIN, 9));
		renderer.setBaseItemLabelsVisible(true);
		plot.setRenderer(renderer);

		return chart;
	}

	/**
	 * 
	 * @param dataset
	 * @param chartInfo
	 * @return
	 */
	public static JFreeChart creatBarchart(CategoryDataset dataset, ChartInfo chartInfo)
	{
		JFreeChart chart = ChartFactory.createBarChart(chartInfo.getChartName(), // 图表标题
				chartInfo.getNameLable(), // 目录轴的显示标签
				chartInfo.getValueLable(), // 数值轴的显示标签
				dataset, // 数据集
				chartInfo.getOrientation(), // 图表方向：水平、垂直
				true, // 是否显示图例(对于简单的柱状图必须是false)
				false, // 是否生成工具
				false // 是否生成URL链接
				);
		chart.setBackgroundPaint(Color.WHITE);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		CategoryPlot plot = chart.getCategoryPlot();
		plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
		plot.setForegroundAlpha(0.8f);

		CategoryAxis domainAxis = plot.getDomainAxis();
		if (chartInfo.isSlantNameLabel())
			domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);// 坐标逆时针45度
		// 设置X轴坐标上的文字
		domainAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置X轴的标题文字
		domainAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		plot.setDomainAxis(domainAxis);

		ValueAxis rangeAxis = plot.getRangeAxis();
		rangeAxis.setUpperMargin(0.1);
		rangeAxis.setLowerMargin(0.1);
		plot.setRangeAxis(rangeAxis);

		NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置Y轴坐标上的文字
		numberaxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置Y轴的标题文字
		numberaxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		StackedBarRenderer renderer = new StackedBarRenderer();
		renderer.setMaximumBarWidth(0.1);// 单个柱子的最大宽度比率
		// set color,if not set,the color will definded by jfreechart.
		renderer.setBaseOutlinePaint(Color.WHITE);
		renderer.setSeriesPaint(0, LEVEL1);
		renderer.setSeriesPaint(1, LEVEL2);
		renderer.setSeriesPaint(2, LEVEL3);
		renderer.setSeriesPaint(3, LEVEL4);
		renderer.setSeriesPaint(4, LEVEL5);
		renderer.setSeriesPaint(5, LEVEL6);
		renderer.setSeriesPaint(6, LEVEL7);
		renderer.setItemMargin(0.1);
		// 显示每个柱的数值，并修改该数值的字体属性
		renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		renderer.setBaseItemLabelFont(new Font("SansSerif", Font.PLAIN, 9));
		renderer.setBaseItemLabelsVisible(true);
		plot.setRenderer(renderer);

		return chart;
	}

	/**
	 * 
	 * @param dataset
	 * @param chartname
	 * @param nameLable
	 * @param valueLable
	 * @return
	 */
	public static JFreeChart creatLinechart(CategoryDataset dataset, ChartInfo chartInfo)
	{
		JFreeChart chart = ChartFactory.createLineChart(chartInfo.getChartName(),
				chartInfo.getNameLable(), // domain
				// axis
				// label
				chartInfo.getValueLable(), // range axis label
				dataset, // data
				chartInfo.getOrientation(), // orientation
				true, // include legend
				true, // tooltips
				false // urls
				);
		chart.setBackgroundPaint(new Color(255, 255, 255));
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		CategoryPlot plot = chart.getCategoryPlot();
		CategoryItemRenderer renderer = plot.getRenderer();
		NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
		numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		numberaxis.setLowerBound(0);
		renderer.setBaseOutlinePaint(Color.BLACK);
		renderer.setBaseItemLabelFont(new Font("SansSerif", Font.BOLD, 24));

		renderer.setSeriesPaint(0, LEVEL1);
		renderer.setSeriesPaint(1, LEVEL2);
		renderer.setSeriesPaint(2, LEVEL3);
		renderer.setSeriesPaint(3, LEVEL4);
		renderer.setSeriesPaint(4, LEVEL5);
		renderer.setSeriesPaint(5, LEVEL6);
		renderer.setSeriesPaint(6, LEVEL7);

		CategoryAxis domainAxis = plot.getDomainAxis();
		domainAxis.setTickLabelFont(new Font("SansSerif", Font.BOLD, 9));
		// domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
		// //坐标逆时针90度
		LineAndShapeRenderer renderer1 = (LineAndShapeRenderer) plot.getRenderer();
		renderer1.setBaseItemLabelsVisible(true);
		return chart;
	}

	public static JFreeChart createXYlineChart(XYDataset dataset, ChartInfo chartInfo)
	{

		final JFreeChart chart = ChartFactory.createXYLineChart(chartInfo.getChartName(), // chart
				// title
				chartInfo.getNameLable(), // x axis label
				chartInfo.getValueLable(), // y axis label
				dataset, // data
				chartInfo.getOrientation(), true, // include legend
				true, // tooltips
				false // urls
				);

		chart.setBackgroundPaint(Color.white);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		XYPlot plot = chart.getXYPlot();
		plot.setBackgroundPaint(Color.white);
		plot.setDomainGridlinePaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		plot.setRenderer(renderer);
		renderer.setSeriesPaint(0, LEVEL1);
		renderer.setSeriesPaint(1, LEVEL2);
		renderer.setSeriesPaint(2, LEVEL3);
		renderer.setSeriesPaint(3, LEVEL4);
		renderer.setSeriesPaint(4, LEVEL5);
		renderer.setSeriesPaint(5, LEVEL6);
		renderer.setSeriesPaint(6, LEVEL7);

		NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置Y轴坐标上的文字
		rangeAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置Y轴的标题文字
		rangeAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		ValueAxis domainAxis = (ValueAxis) plot.getDomainAxis();
		domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置X轴坐标上的文字
		domainAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置X轴的标题文字
		domainAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		return chart;
	}

	public static JFreeChart createTimeSeriesChart(XYDataset dataset, ChartInfo chartInfo)
	{

		JFreeChart chart = ChartFactory.createTimeSeriesChart(chartInfo.getChartName(), // title
				chartInfo.getNameLable(), // x axis label
				chartInfo.getValueLable(), // y axis label
				dataset, // data
				true, // create legend?
				true, // generate tooltips?
				false // generate URLs?
				);

		chart.setBackgroundPaint(Color.white);
		// 设置消除字体的锯齿渲染（解决中文问题）
		chart.getRenderingHints().put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		// 设置标题字体
		chart.getTitle().setFont(new Font("sans-serif", Font.PLAIN, 20));
		// 设置legend字体
		chart.getLegend().setItemFont(new Font("sans-serif", Font.PLAIN, 12));
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.white);
		plot.setDomainGridlinePaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		XYItemRenderer r = plot.getRenderer();
		if (r instanceof XYLineAndShapeRenderer)
		{
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
		}
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setDateFormatOverride(new SimpleDateFormat("yyyy-MMM"));
		// 设置X轴坐标上的文字
		axis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置X轴的标题文字
		axis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// axis.setDateFormatOverride(new SimpleDateFormat("HH:mm"));

		NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// 设置Y轴坐标上的文字
		rangeAxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// 设置Y轴的标题文字
		rangeAxis.setLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		return chart;

	}
}
