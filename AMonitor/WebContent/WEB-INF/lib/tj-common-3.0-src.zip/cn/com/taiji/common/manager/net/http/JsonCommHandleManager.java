/*
 * Date: 2013-5-1
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-1 下午4:59:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface JsonCommHandleManager
{
	public JsonProtocol handleComm(JsonProtocol protocol) throws IOException;
}
