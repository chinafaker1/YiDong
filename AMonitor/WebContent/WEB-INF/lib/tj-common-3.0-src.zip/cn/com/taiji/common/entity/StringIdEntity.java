package cn.com.taiji.common.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 上午08:59:53
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class StringIdEntity extends BaseEntity
{
	protected String id;

	@Id
	@Column(name = "id")
	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof StringIdEntity)) return false;
		StringIdEntity other = (StringIdEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}

}
