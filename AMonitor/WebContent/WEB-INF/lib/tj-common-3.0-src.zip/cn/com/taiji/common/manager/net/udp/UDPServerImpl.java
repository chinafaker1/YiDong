package cn.com.taiji.common.manager.net.udp;

import java.io.IOException;
import java.net.InetAddress;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.xsocket.datagram.Endpoint;
import org.xsocket.datagram.IEndpoint;
import org.xsocket.datagram.UserDatagram;

import cn.com.taiji.common.manager.AbstractManager;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-13 下午05:29:00
 * @since 1.0
 * @version 1.0
 */
public class UDPServerImpl extends AbstractManager implements UDPServer
{
	private final int buffLen;

	private UDPServerHandler handler;
	private IEndpoint endpoint;
	private String hostname;
	private int port;

	public UDPServerImpl(int buffLen, UDPServerHandler handler, int port)
	{
		this(buffLen, handler, "0.0.0.0", port);
	}

	public UDPServerImpl(int buffLen, UDPServerHandler handler, String hostname, int port)
	{
		this.buffLen = buffLen;
		this.handler = handler;
		this.hostname = hostname;
		this.port = port;
	}

	@PostConstruct
	public synchronized void start() throws IOException
	{
		if (isRunning())
		{
			logger.info("UDPServer已经启动!!");
			return;
		}
		endpoint = new Endpoint(buffLen, handler, InetAddress.getByName(hostname), port);
		logger.info("UDPServer开始监听:{}", port);
	}

	public void send(UserDatagram datagram) throws IOException
	{
		if (!isRunning()) throw new IOException("server is not running");
		endpoint.send(datagram);
	}

	public boolean isRunning()
	{
		return endpoint == null ? false : endpoint.isOpen();
	}

	@PreDestroy
	public synchronized void stop()
	{
		try
		{
			if (endpoint == null) return;
			endpoint.close();
			logger.info("UDPServer停止监听:{}", port);
		}
		catch (IOException e)
		{
			logger.error("", e);
		}
		finally
		{
			endpoint = null;
		}
	}

	public void setHandler(UDPServerHandler handler)
	{
		this.handler = handler;
	}

}
