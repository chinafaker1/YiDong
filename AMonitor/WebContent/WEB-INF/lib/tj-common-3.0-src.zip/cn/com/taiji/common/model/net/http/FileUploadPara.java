/*
 * Date: 2013-3-8
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.net.http;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-3-8 上午11:06:09<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class FileUploadPara extends BaseModel
{
	private String uri;// 不带参数的uri
	private Map<String, File> files = new HashMap<String, File>();// 文件
	private String requestEncoding = "UTF-8";// 默认编码
	private List<? extends NameValuePair> params = new ArrayList<NameValuePair>();// 参数
	private String defaultResEncoding = "UTF-8";// 返回的解析编码
	private int connTimeout = -1;// 连接超时毫秒数 负数忽略
	private int soTimeout = -1;// 响应超时毫秒数 负数忽略

	public FileUploadPara()
	{

	}

	public FileUploadPara(String uri, int connTimeout, int soTimeout)
	{
		this.uri = uri;
		this.connTimeout = connTimeout;
		this.soTimeout = soTimeout;
	}

	public String getUri()
	{
		return uri;
	}

	public Map<String, File> getFiles()
	{
		return files;
	}

	public String getRequestEncoding()
	{
		return requestEncoding;
	}

	public List<? extends NameValuePair> getParams()
	{
		return params;
	}

	public String getDefaultResEncoding()
	{
		return defaultResEncoding;
	}

	public int getConnTimeout()
	{
		return connTimeout;
	}

	public int getSoTimeout()
	{
		return soTimeout;
	}

	public void setUri(String uri)
	{
		this.uri = uri;
	}

	public void setFiles(Map<String, File> files)
	{
		this.files = files;
	}

	public void setRequestEncoding(String requestEncoding)
	{
		this.requestEncoding = requestEncoding;
	}

	public void setParams(List<? extends NameValuePair> params)
	{
		this.params = params;
	}

	public void setDefaultResEncoding(String defaultResEncoding)
	{
		this.defaultResEncoding = defaultResEncoding;
	}

	public void setConnTimeout(int connTimeout)
	{
		this.connTimeout = connTimeout;
	}

	public void setSoTimeout(int soTimeout)
	{
		this.soTimeout = soTimeout;
	}
}
