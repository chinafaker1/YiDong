package cn.com.taiji.common.manager.pub;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.finals.SysFinals;
import cn.com.taiji.common.model.pub.MyFile;
import cn.com.taiji.common.pub.NumberTools;
import cn.com.taiji.common.pub.ObjectTools;
import cn.com.taiji.common.pub.ProjectEnv;
import cn.com.taiji.common.pub.file.DirectoryFilter;
import cn.com.taiji.common.pub.file.OnlyFileFilter;
import cn.com.taiji.common.pub.file.helper.FileNameComparator;
import cn.com.taiji.common.pub.file.helper.FileSizeComparator;
import cn.com.taiji.common.pub.file.helper.FileTimeComparator;


/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-26 下午07:02:22
 * @since 1.0
 * @version 1.0
 */
public class FileHelper extends AbstractManager
{
	/**
	 * 删除某个文件,文件不存在返回false.
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean deleteFile(String filePath)
	{
		if (filePath == null) throw new IllegalArgumentException("被删文件的路径名不能为空");
		File file = new File(filePath);
		if (file.exists() && file.isFile()) { return file.delete(); }
		return false;
	}

	/**
	 * 删除文件，如果删除失败抛出异常
	 * 
	 * @param file
	 *            被删除文件，null或者文件不存在，不执行操作。
	 */
	public static void deleteFile(File file)
	{
		if (file == null || !(file.exists())) return;
		if (!file.delete()) throw new RuntimeException("Delete file failed: " + file.getAbsolutePath());
	}

	/**
	 * 删除整个文件夹
	 * 
	 * @param floderPath
	 * @return
	 */
	public static boolean deleteDirectory(String floderPath)
	{
		return deleteDirectory(floderPath, true, 0);
	}

	public static boolean deleteDirectory(String floderPath, long holdTime)
	{
		if (holdTime <= 0) throw new IllegalArgumentException("hold time must > 0");
		return deleteDirectory(floderPath, false, holdTime);
	}

	/**
	 * 删除整个文件夹
	 * 
	 * @param floderPath
	 *            文件夹路径
	 * @param includeSelf
	 *            是否包含文件夹自身，如果文件保留时间>0永远不会删除自身
	 * @param holdTime
	 *            文件夹下文件的保留时间，毫秒
	 * @return
	 */
	public static boolean deleteDirectory(String floderPath, boolean includeSelf, long holdTime)
	{
		if (floderPath == null) throw new IllegalArgumentException("被删文件夹的路径名不能为空");
		File floder = new File(floderPath);
		if (!floder.isDirectory()) throw new RuntimeException("该路径不是文件夹:" + floderPath);
		File[] files = floder.listFiles();
		long currentTime = System.currentTimeMillis();
		if (!ObjectTools.isEmpty(files))
		{
			for (File file : files)
			{
				if (file.exists() && file.isFile())
				{
					if (holdTime <= 0)
					{
						if (!file.delete()) System.err.println("delete file failed:" + file.getAbsolutePath());
					}
					else
					{
						long fileTime = file.lastModified();
						long existTime = currentTime - fileTime;
						if (existTime > holdTime)
						{
							boolean rs = file.delete();
							if (!rs) System.err.println("delete file failed:" + file.getAbsolutePath());
						}
					}
				}
				else if (file.exists() && file.isDirectory())
				{
					deleteDirectory(file.getAbsolutePath(), true, holdTime);
				}
			}
		}
		if (includeSelf && (holdTime <= 0 || ObjectTools.isEmpty(files))) return floder.delete();
		return true;
	}

	/**
	 * 获取指定目录下的所有文件,(不包含目录)
	 * 
	 * @param floderPath
	 * @return
	 */
	public static List<MyFile> getOnlyFiles(String floderPath)
	{
		return getFiles(floderPath, OnlyFileFilter.getInstance(), null);
	}

	/**
	 * 获取指定目录下的所有文件,(不包含目录)
	 * 
	 * @param floderPath
	 * @param comparator
	 *            为null忽略
	 * @return 文件列表
	 * @see FileNameComparator
	 * @see FileSizeComparator
	 * @see FileTimeComparator
	 */
	public static List<MyFile> getOnlyFiles(String floderPath, Comparator<File> comparator)
	{
		return getFiles(floderPath, OnlyFileFilter.getInstance(), comparator);
	}

	/**
	 * 获取指定目录下的所有目录,(不包含文件)
	 * 
	 * @param floderPath
	 * @return
	 */
	public static List<MyFile> getDirectories(String floderPath)
	{
		return getFiles(floderPath, DirectoryFilter.getInstance(), null);
	}

	/**
	 * 获取指定目录下的所有目录,(不包含文件)
	 * 
	 * @param floderPath
	 * @param comparator
	 *            为null忽略
	 * @return 文件列表
	 * @see FileNameComparator
	 * @see FileSizeComparator
	 * @see FileTimeComparator
	 */
	public static List<MyFile> getDirectories(String floderPath, Comparator<File> comparator)
	{
		return getFiles(floderPath, DirectoryFilter.getInstance(), comparator);
	}

	/**
	 * 根据过滤器获取指定目录下的文件或目录,
	 * 
	 * @param floderPath
	 * @param fileFilter
	 *            为null时返回所有文件夹和文件.
	 * @return
	 */
	public static List<MyFile> getFiles(String floderPath, FileFilter fileFilter)
	{
		return getFiles(floderPath, fileFilter, null);
	}

	/**
	 * 根据过滤器获取指定目录下的文件或目录,
	 * 
	 * @param floderPath
	 * @param fileFilter
	 *            为null时返回所有文件夹和文件.
	 * @param comparator
	 *            为null忽略
	 * @return 文件列表
	 * @see FileNameComparator
	 * @see FileSizeComparator
	 * @see FileTimeComparator
	 */
	public static List<MyFile> getFiles(String floderPath, FileFilter fileFilter, Comparator<File> comparator)
	{
		if (floderPath == null) throw new IllegalArgumentException("路径不能为空");
		File floder = new File(floderPath);
		File[] files = floder.listFiles(fileFilter);
		List<MyFile> list = new ArrayList<MyFile>();
		if (files == null) return list;
		if (comparator != null) Arrays.sort(files, comparator);
		for (File file : files)
		{
			list.add(toMyFile(file));
		}
		return list;
	}

	/**
	 * 取得工程目录 Copyright © 2006 Thinkor.com All rights reserved. Date: 2006-12-15 author: zzq (zzq98_2000@hotmail.com)
	 * 
	 * @return
	 */
	public static String getWebappPath()
	{
		return ProjectEnv.getWebappPath();
	}

	/**
	 * 取得系统的配置目录(存放系统配置文件)
	 * 
	 * @return $WEBAPPPATH/WEB-INF/conf
	 */
	public static String getConfPath()
	{
		return ProjectEnv.getConfPath();
	}

	/**
	 * 取得系统的临时目录(用于存放临时文件)
	 * 
	 * @return $WEBAPPPATH/tmp
	 */
	public static String getTmpPath()
	{
		return ProjectEnv.getTmpPath();
	}

	/**
	 * 取得数据存放目录
	 * 
	 * @return $WEBAPPPATH/data
	 */
	public static String getDataPath()
	{
		return ProjectEnv.getDataPath();
	}

	/**
	 * 取得工具存放目录
	 * 
	 * @return $WEBAPPPATH/tool
	 */
	public static String getToolPath()
	{
		return ProjectEnv.getToolPath();
	}

	public static void mkdirs(String path)
	{
		ProjectEnv.mkdirs(path);
	}

	/**
	 * 取得指定文件对应的目录文件
	 * 
	 * @param file
	 * @return
	 */
	public static File getDirectoryFile(File file)
	{
		if (file == null || file.isDirectory()) return file;
		String path = toUnixFloder(file.getAbsolutePath(), false);
		String parent = path.substring(0, path.lastIndexOf('/') + 1);
		return new File(parent);
	}

	/**
	 * 将文件夹的格式转换为unix下文件夹的格式<BR>
	 * eg:E:\home\\\data//ccc经过转换后变为 E:/home/data/ccc/
	 * 
	 * @param floder
	 *            文件夹
	 * @param appendLast
	 *            最后是否以/结尾
	 * @return unxin下文件夹格式
	 */
	public static String toUnixFloder(String floder, boolean appendLast)
	{
		if (floder == null) return null;
		String rs = floder.replace('\\', '/');
		if (appendLast) rs = rs + "/";
		return rs.replaceAll(SysFinals.MULTI_SLASH, "/");
	}

	public static MyFile toMyFile(File file)
	{
		MyFile myfile = new MyFile();
		String path = file.getAbsolutePath().replaceAll("\\\\", "/");
		myfile.setPath(path);
		// facePath
		String webappPath = ProjectEnv.getWebappPath();
		if (webappPath.endsWith("/")) myfile.setFacePath(path.replace(webappPath, "/"));
		else myfile.setFacePath(path.replace(webappPath, ""));
		myfile.setName(file.getName());
		Calendar time = Calendar.getInstance();
		time.setTimeInMillis(file.lastModified());
		myfile.setModifyTime(time);
		myfile.setDirectory(file.isDirectory());
		long size = file.length();
		myfile.setSize(NumberTools.bytesAsHumanStr(size));
		return myfile;
	}
}
