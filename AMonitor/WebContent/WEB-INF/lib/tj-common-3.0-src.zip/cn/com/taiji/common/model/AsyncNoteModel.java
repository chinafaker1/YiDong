package cn.com.taiji.common.model;

public class AsyncNoteModel extends AbstractAsyncModel
{
	private String msg;

	public AsyncNoteModel()
	{
		this(null);
	}

	public AsyncNoteModel(String msg)
	{
		super(AsyncProcessType.NOTE);
		this.msg = msg;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

}
