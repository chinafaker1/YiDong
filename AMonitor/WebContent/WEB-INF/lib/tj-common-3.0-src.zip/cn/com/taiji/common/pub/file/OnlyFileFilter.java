package cn.com.taiji.common.pub.file;

import java.io.File;
import java.io.FileFilter;

/**
 * 
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-26 下午06:44:38
 * @since 1.0
 * @version 1.0
 */
public class OnlyFileFilter implements FileFilter
{
	private static OnlyFileFilter instance;

	public static OnlyFileFilter getInstance()
	{
		if (instance == null) instance = new OnlyFileFilter();
		return instance;
	}

	public boolean accept(File pathname)
	{
		if (pathname.isDirectory()) return false;
		return true;
	}

}
