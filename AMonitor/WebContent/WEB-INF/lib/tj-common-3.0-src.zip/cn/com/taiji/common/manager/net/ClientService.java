/*
 * Date: 2015年8月13日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net;

import cn.com.taiji.common.manager.LifecycleService;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年8月13日 下午6:13:29<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface ClientService extends LifecycleService
{
	/**
	 * 连接是否正常
	 * 
	 * @return
	 */
	public boolean isConnected();

	/**
	 * 临时文件的后缀
	 * 
	 * @return 后缀 .part
	 */
	public String getPartSuffix();

	public abstract String getServer();

	public abstract int getPort();

	public abstract String getUsername();

	public abstract String getPassword();

	public abstract String getEncoding();

	public int getConnTimeout();

	public void setConnTimeout(int connTimeout);

	public void setSoTimeout(int soTimeout);

	public int getSoTimeout();

}
