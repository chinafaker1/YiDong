/*
 * Date: 2013-4-23
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.SecurityUtil;
import cn.com.taiji.common.pub.SecurityUtil.HashType;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-4-23 下午12:55:49<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CronExclusiveTask extends BaseModel
{
	private String id;
	private Date updateTime;
	private boolean running;
	private String nodeTag;
	private String md5;

	public String getId()
	{
		return id;
	}

	public Date getUpdateTime()
	{
		return updateTime;
	}

	public boolean isRunning()
	{
		return running;
	}

	public String getNodeTag()
	{
		return nodeTag;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public void setUpdateTime(Date updateTime)
	{
		this.updateTime = updateTime;
	}

	public void setRunning(boolean running)
	{
		this.running = running;
	}

	public void setNodeTag(String nodeTag)
	{
		this.nodeTag = nodeTag;
	}

	@JsonIgnore
	public String getMd5()
	{
		return md5;
	}

	public void setMd5(String md5)
	{
		this.md5 = md5;
	}

	public String genMD5()
	{
		return SecurityUtil.encryptStr(toJson(), HashType.MD5, true);
	}
}
