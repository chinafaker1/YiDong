package cn.com.taiji.common.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.pub.DocTemplateHelper;
import cn.com.taiji.common.model.pub.DocContentInfo;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.file.FileTools;


/**
 * 会在webapp的tmp文件夹生成中间数据，请记得清理
 * 
 * @author Peream <br>
 *         Create Time：2009-7-17 上午11:43:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class BaseDocTemplateController extends BaseDownloadController
{
	private final String templateUrl;

	protected BaseDocTemplateController(String templateUrl)
	{
		AssertUtil.notNull(templateUrl);
		this.templateUrl = templateUrl;
	}

	protected void generateDoc(HttpServletRequest request, HttpServletResponse response,
			Map<String, String> texts, String displayName, Map<String, InputStream> images)
			throws IOException
	{
		AssertUtil.hasText(displayName);
		String uuidName = FileTools.generateUUIDName(displayName);
		DocContentInfo info = new DocContentInfo();
		info.setTemplateUrl(templateUrl);
		info.setFileName(uuidName);
		info.setImages(images);
		info.setTexts(texts);
		info.setAlwaysNew(false);
		File file = DocTemplateHelper.generateDoc(info);
		super.doDownLoad(request, response, new FileInputStream(file), displayName);
	}

	/**
	 * 生成word文档
	 * 
	 * @param request
	 * @param response
	 * @param displayName
	 *            下载时显示的名字
	 * @param info
	 * @throws IOException
	 */
	protected void generateDoc(HttpServletRequest request, HttpServletResponse response,
			String displayName, DocContentInfo info) throws IOException
	{
		AssertUtil.hasText(displayName);
		info.setTemplateUrl(templateUrl);
		if (!StringTools.hasText(info.getFileName()))
			info.setFileName(FileTools.generateUUIDName(displayName));
		File file = DocTemplateHelper.generateDoc(info);
		super.doDownLoad(request, response, new FileInputStream(file), displayName);
	}
}
