/*
 * Date: 2012-3-27
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-3-27 下午3:36:22<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class CommonAbstract
{
	protected Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * @see {@link StringTools#toLogString(String, Object...)}
	 */
	protected static final String toLogString(String str, Object... args)
	{
		return StringTools.toLogString(str, args);
	}

	protected static final boolean hasText(CharSequence str)
	{
		return StringTools.hasText(str);
	}

	protected static final boolean isEmpty(Object[] array)
	{
		return ObjectTools.isEmpty(array);
	}

	protected static final boolean isEmpty(Collection<?> collection)
	{
		return CollectionTools.isEmpty(collection);
	}

	protected static final boolean isEmpty(Map<?, ?> map)
	{
		return CollectionTools.isEmpty(map);
	}

	protected static final void assertAllElementsHasValue(Object... elements)
	{
		AssertUtil.allElementsHasValue(elements);
	}

	/**
	 * 
	 * @param list
	 * @return
	 * @see {@link CollectionTools#extractOne(List)}
	 */
	protected final static <T> T extractOne(List<T> list)
	{
		return CollectionTools.extractOne(list);
	}
}
