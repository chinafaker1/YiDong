/*
 * Date: 2013-5-6
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.CronTaskRunner;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.model.quartz.CronTaskConfig;
import cn.com.taiji.common.model.quartz.CronTaskQueryModel;
import cn.com.taiji.common.model.quartz.CronTaskView;
import cn.com.taiji.common.pub.AssertUtil;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-6 下午2:23:04<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class CronQuartzManagerImpl extends AbstractManager implements CronQuartzManager
{
	private Map<String, CronTaskConfig> configs = Maps.newConcurrentMap();
	private Map<String, CronTaskRunner> runners = Maps.newConcurrentMap();
	private ExecutorService executor;// executor

	@Override
	public List<CronTaskView> listAll(CronTaskQueryModel qm)
	{
		String taskName = qm.getTaskName();
		String info = qm.getInfo();
		List<CronTaskView> rs = Lists.newArrayList();
		for (String key : configs.keySet())
		{
			CronTaskView view = findOne(key);
			// 查询条件过滤
			if (hasText(taskName) && !(key.toLowerCase().contains(taskName.toLowerCase()))) continue;
			if (hasText(info) && hasText(view.getInfo()) && !(view.getInfo().contains(info))) continue;
			if (hasText(qm.getType()) && hasText(view.getType()) && !(qm.getType().equals(view.getType()))) continue;
			rs.add(view);
		}
		Collections.sort(rs);
		return rs;
	}

	@Override
	public Pagination queryPage(CronTaskQueryModel qm)
	{
		List<CronTaskView> list = listAll(qm);
		if (list.size() == 0) return Pagination.emptyInstance();
		Pagination pg = new Pagination(qm.getPageNo(), qm.getPageSize(), list.size()).compute();
		List<List<CronTaskView>> parts = Lists.partition(list, qm.getPageSize());
		pg.setResult(parts.get(pg.getCurrentPage() - 1));
		return pg;
	}

	@Override
	public List<CronTaskView> listAll()
	{
		return listAll(new CronTaskQueryModel());
	}

	@Override
	public CronTaskView findOne(String taskName)
	{
		CronTaskConfig config = configs.get(taskName);
		if (config == null) return null;
		CronTaskView rs = new CronTaskView();
		rs.setTaskName(taskName);
		rs.setCron(config.getCron());
		rs.setRunning(isRunning(taskName));
		rs.setTaskRunning(isTaskRunning(taskName));
		rs.setStopImmediate(config.isStopImmediate());
		rs.setAutoStart(config.isAutoStart());
		rs.setType(config.getType());
		rs.setInfo(config.getInfo());
		return rs;
	}

	@Override
	@Deprecated
	public void setTaskConfigs(Map<String, CronTaskConfig> configs)
	{
		AssertUtil.notNull(configs);
		for (CronTaskConfig config : configs.values())
		{
			addTaskConfig(config);
		}
	}

	@Override
	public boolean isRunning(String taskName)
	{
		CronTaskRunner runner = runners.get(taskName);
		return runner == null ? false : runner.isRunning();
	}

	@Override
	public boolean isTaskRunning(String taskName)
	{
		CronTaskRunner runner = runners.get(taskName);
		return runner == null ? false : ((RunnableProxy) runner.getTask()).isRunning();
	}

	@Override
	public void runTaskNow(String taskName) throws ManagerException
	{
		CronTaskRunner runner = runners.get(taskName);
		if (runner == null || !runner.isRunning()) throw new ManagerException(toLogString("任务调度器({})未运行", taskName));
		RunnableProxy task = (RunnableProxy) runner.getTask();
		if (task.isRunning()) throw new ManagerException(toLogString("任务({})正在执行", taskName));
		executor.execute(task);
	}

	@Override
	public void addTaskConfig(CronTaskConfig config)
	{
		RunnableProxy task = config.getTask();
		if (task == null) throw new IllegalArgumentException("任务不能为null");
		CronTaskConfig old = configs.get(task.getTaskName());
		if (old != null) throw new IllegalArgumentException(toLogString("已经存在名字为({})的任务", task.getTaskName()));
		configs.put(task.getTaskName(), config);
	}

	@Override
	public void removeTaskConfig(String taskName)
	{
		stop(taskName);
		configs.remove(taskName);
	}

	@Override
	public void updateTaskCron(String taskName, String cron)
	{
		CronTaskConfig config = configs.get(taskName);
		if (config == null)
		{
			logger.warn("不存在名字为({})的任务", taskName);
			return;
		}
		config.setCron(cron);
		logger.info("更新({})任务的cron为:{}", taskName, cron);
	}

	@Override
	public void start(String taskName) throws Exception
	{
		CronTaskRunner runner = getRunner(taskName);
		runner.start();
		logger.info("启动任务({})成功:{}", taskName, runner.isRunning());
	}

	private CronTaskRunner getRunner(String taskName) throws ManagerException
	{
		CronTaskRunner runner = runners.get(taskName);
		if (runner != null)
		{
			logger.info("{}'s runner is not null,return directly.", taskName);
			return runner;
		}
		CronTaskConfig config = configs.get(taskName);
		if (config == null) throw new ManagerException(toLogString("找不到({})任务的配置", taskName));
		RunnableProxy task = config.getTask();
		runner = new CronTaskRunner(task, task.getTaskName(), config.isStopImmediate(), config.getCron(),
				config.isInvokeTaskAfterStart());
		if (config.getErrorHandler() != null) runner.setErrorHandler(config.getErrorHandler());
		runners.put(taskName, runner);
		return runners.get(taskName);
	}

	@Override
	public void stop(String taskName)
	{
		CronTaskRunner runner = runners.remove(taskName);
		if (runner != null)
		{
			runner.stop();
			logger.info("停止任务({})成功", taskName);
		}
	}

	@Override
	public synchronized void init() throws Exception
	{
		destory();
		executor = Executors.newCachedThreadPool();
		for (String taskName : configs.keySet())
		{
			if (getConfig(taskName).isAutoStart()) start(taskName);
		}
	}

	private CronTaskConfig getConfig(String taskName) throws ManagerException
	{
		CronTaskConfig config = configs.get(taskName);
		if (config == null) throw new ManagerException(toLogString("找不到({})任务的配置", taskName));
		return config;
	}

	@Override
	public synchronized void destory()
	{
		for (String taskName : runners.keySet())
		{
			try
			{
				stop(taskName);
			}
			catch (Exception e)
			{
				logger.error("", e);
			}
		}
		runners.clear();
		if (executor != null)
		{
			executor.shutdownNow();
			executor = null;
		}
	}

}
