/*
 * Date: 2014年9月28日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import cn.com.taiji.common.model.quartz.CronExclusiveTask;
import cn.com.taiji.common.pub.FileCopyTools;

/**
 * 通过文件锁对运行任务进行互斥
 * 
 * @author Peream <br>
 *         Create Time：2014年9月28日 下午2:15:17<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class FileExclusiveTask extends AbstractClusterRunnableProxy implements RunnableProxy
{
	private final File taskFile;

	/**
	 * 
	 * @param task
	 *            真正运行的任务
	 * @param savePath
	 *            任务标识文件的存储路径（集群节点时指向同一个磁盘或者nfs的挂载点）
	 * @param taskName
	 *            任务名称（需要唯一）
	 */
	public FileExclusiveTask(Runnable task, String savePath, String taskName)
	{
		this(task, savePath, null, taskName);
	}

	/**
	 * 
	 * @param task
	 *            真正运行的任务
	 * @param savePath
	 *            任务标识文件的存储路径（集群节点时指向同一个磁盘或者nfs的挂载点）
	 * @param listener
	 *            任务监听器
	 * @param taskName
	 *            任务名称（需要唯一）
	 */
	public FileExclusiveTask(Runnable task, String savePath, TaskListener listener, String taskName)
	{
		super(task, taskName, listener);
		taskFile = new File(savePath + "/" + taskName);
		if (!taskFile.exists())// 文件不存在时创建一个新文件
		{
			try
			{
				if (!taskFile.createNewFile()) logger.warn("文件已经建立:{}", taskFile.getAbsolutePath());
				CronExclusiveTask cronTask = newCronTask();
				FileCopyTools.copy(cronTask.toJson().getBytes(), taskFile);
			}
			catch (IOException e)
			{
				logger.error("", e);
				throw new RuntimeException("无法创建任务文件:" + taskFile.getAbsolutePath());
			}
		}
	}

	private FileLock lockTaskFile(FileOutputStream out)
	{
		try
		{
			FileChannel channel = out.getChannel();
			return channel.tryLock();
		}
		catch (Exception e)
		{
			logger.error("无法锁定文件", e);
			return null;
		}
	}

	@Override
	public void run()
	{
		if (isRunning())
		{
			logger.info("{} 任务正在运行,本次任务调用忽略.", taskName);
			return;
		}
		FileOutputStream out = null;
		FileLock lock = null;
		try
		{
			out = new FileOutputStream(taskFile);
			lock = lockTaskFile(out);
			if (lock == null)
			{
				logger.info("本节点({})请求开始任务失败,不运行任务:{}", nodeTag, taskName);
				return;
			}
			taskRunning.set(true);
			CronExclusiveTask cronTask = newCronTask();
			cronTask.setRunning(true);
			out.write(cronTask.toJson().getBytes());
			out.flush();
			super.doTask();
		}
		catch (IOException e)
		{
			logger.error("", e);
		}
		finally
		{
			closeQuiely(out, lock);
			if (taskRunning.get()) taskRunning.set(false);
		}
	}

	@Override
	public boolean isRunning()
	{
		if (taskRunning.get()) return true;
		FileOutputStream out = null;
		FileLock lock = null;
		try
		{
			out = new FileOutputStream(taskFile);
			lock = lockTaskFile(out);
			return lock == null;// 不能获得文件锁，表示正在执行
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
		finally
		{
			closeQuiely(out, lock);
		}
		return false;
	}

	private void closeQuiely(FileOutputStream out, FileLock lock)
	{
		try
		{
			if (lock != null) lock.release();
			if (out != null) out.close();
		}
		catch (Exception e)
		{
			logger.error("", e);
		}
	}
}
