package cn.com.taiji.common.model.net;

/**
 * 执行telnet命令的Target
 * 
 * @author Peream <br>
 *         Create Time：2009-7-27 下午01:13:50<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class TelnetExecTarget extends ExecTarget
{
	private String tag = " $";

	public String getTag()
	{
		return tag;
	}

	public void setTag(String tag)
	{
		this.tag = tag;
	}
}
