package cn.com.taiji.common.model.acl;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-28 下午03:51:46
 * @since 1.0
 * @version 1.0
 */
public class AccessCtrl extends BaseModel
{
	private String requestUri;
	private String roleId;
	private boolean permit = false;
	private String reason;
	private String returnUri = "/index.htm";

	public boolean isPermit()
	{
		return permit;
	}

	public void setPermit(boolean permit)
	{
		this.permit = permit;
	}

	public String getReason()
	{
		return reason;
	}

	public void setReason(String reason)
	{
		this.reason = reason;
	}

	public String getRoleId()
	{
		return roleId;
	}

	public void setRoleId(String roleId)
	{
		this.roleId = roleId;
	}

	public String getRequestUri()
	{
		return requestUri;
	}

	public void setRequestUri(String target)
	{
		this.requestUri = target;
	}

	public String getReturnUri()
	{
		return returnUri;
	}

	public void setReturnUri(String returnUri)
	{
		this.returnUri = returnUri;
	}
}
