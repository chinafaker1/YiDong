package cn.com.taiji.common.manager.net;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.pub.StringTools;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-2-20 下午04:03:16
 * @since 1.0
 * @version 1.0
 */
public class HostStateHelper
{
	protected static Logger logger = LoggerFactory.getLogger(HostStateHelper.class);

	public static boolean isReachable(String ip, int port)
	{
		return isReachable(ip, port, 5000);
	}

	/**
	 * 判断目标主机是否可以连通
	 * 
	 * @param ip
	 *            目标主机
	 * @param port
	 *            目标主机的服务端口，如果端口为0，用ping方式确定；<br>
	 *            端口不为0时，用telnet目标端口的方式确定
	 * @param timeout
	 *            超时时间
	 * @return
	 */
	public static boolean isReachable(String ip, int port, int timeout)
	{
		int myTimeout = timeout <= 0 ? 5000 : timeout;
		if (port == 0) return isHostReachable(ip, myTimeout);
		return canTelnet(ip, port, myTimeout);
	}

	public static boolean canTelnet(String ip, int port)
	{
		return canTelnet(ip, port, 0);
	}

	public static boolean canTelnet(String ip, int port, int timeout)
	{
		if (!StringTools.hasText(ip)) return false;
		if (port <= 0) throw new IllegalArgumentException("port must greater than 0");
		try
		{
			Socket socket = new Socket();
			SocketAddress address = new InetSocketAddress(ip, port);
			socket.connect(address, timeout);
			try
			{
				socket.close();
			}
			catch (IOException e)
			{
			}
		}
		catch (IOException e)
		{
			logger.warn(e.getMessage());
			return false;
		}
		return true;
	}

	private static boolean isHostReachable(String ip, int timeout)
	{
		if (!StringTools.hasText(ip)) return false;
		try
		{
			InetAddress inet = InetAddress.getByName(ip);
			return inet.isReachable(timeout);
		}
		catch (UnknownHostException e)
		{
			logger.error(e.getMessage());
			return false;
		}
		catch (IOException e)
		{
			logger.error(e.getMessage());
			return false;
		}
	}
}
