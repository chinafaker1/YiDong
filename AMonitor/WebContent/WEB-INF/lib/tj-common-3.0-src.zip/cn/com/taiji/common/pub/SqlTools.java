package cn.com.taiji.common.pub;

import java.util.List;

/**
 * 
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-8-17 上午08:47:53
 * @since 1.0
 * @version 1.1
 */
public abstract class SqlTools
{

	public static String getStringInStr(List<String> conditions)
	{
		if (conditions == null || conditions.size() < 1)
			throw new IllegalArgumentException("参数错误");
		return getStringInStr(conditions.toArray(new String[0]));
	}

	public static String getNumberInStr(Number... conditions)
	{
		if (conditions == null || conditions.length < 1)
			throw new IllegalArgumentException("参数错误");
		StringBuilder sb = new StringBuilder("(");
		int size = conditions.length;
		if (size > 1)
		{
			for (int i = 0; i < size - 1; i++)
			{
				sb.append(conditions[i]);
				sb.append(",");
			}
		}
		sb.append(conditions[size - 1]);
		sb.append(")");
		return sb.toString();
	}

	public static String getStringInStr(String... conditions)
	{
		if (conditions == null || conditions.length < 1)
			throw new IllegalArgumentException("参数错误");
		StringBuilder sb = new StringBuilder("(");
		int size = conditions.length;
		if (size > 1)
		{
			for (int i = 0; i < size - 1; i++)
			{
				sb.append("'");
				sb.append(conditions[i]);
				sb.append("',");
			}
		}
		sb.append("'");
		sb.append(conditions[size - 1]);
		sb.append("')");
		return sb.toString();
	}

	/**
	 * 适用于数据库中是用数字作为映射的情况
	 * 
	 * @param conditions
	 * @return
	 * @since 1.1 {@link #getEnumNameInStr(Enum...)}
	 */
	public static String getEnumInStr(Enum<?>... conditions)
	{
		if (conditions == null || conditions.length < 1)
			throw new IllegalArgumentException("参数错误");
		StringBuilder sb = new StringBuilder("(");
		int size = conditions.length;
		if (size > 1)
		{
			for (int i = 0; i < size - 1; i++)
			{
				sb.append(conditions[i].ordinal());
				sb.append(",");
			}
		}
		sb.append(conditions[size - 1].ordinal());
		sb.append(")");
		return sb.toString();
	}

	/**
	 * 适用于数据库中是用字符作为映射的情况
	 * 
	 * @param conditions
	 * @return
	 * @since 1.1 {@link #getEnumInStr(Enum...)}
	 */
	public static String getEnumNameInStr(Enum<?>... conditions)
	{
		if (conditions == null || conditions.length < 1)
			throw new IllegalArgumentException("参数错误");
		StringBuilder sb = new StringBuilder("(");
		int size = conditions.length;
		if (size > 1)
		{
			for (int i = 0; i < size - 1; i++)
			{
				sb.append("'");
				sb.append(conditions[i].name());
				sb.append("',");
			}
		}
		sb.append("'");
		sb.append(conditions[size - 1]);
		sb.append("')");
		return sb.toString();
	}
}
