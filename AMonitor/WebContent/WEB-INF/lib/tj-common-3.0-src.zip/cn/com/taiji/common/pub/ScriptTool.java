package cn.com.taiji.common.pub;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.pub.handler.DefaultScriptInputHandler;
import cn.com.taiji.common.pub.handler.ScriptInputHandler;
import cn.com.taiji.common.pub.handler.CmdEcho2ResultHandler;
import cn.com.taiji.common.pub.handler.ScriptOutputHandler;

/**
 * 执行sh或bat脚本
 * 
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:17:21
 * @since 1.0
 * @version 1.1
 */
public abstract class ScriptTool
{
	protected static Logger logger = LoggerFactory.getLogger(ScriptTool.class);

	/**
	 * 执行bash脚本
	 * 
	 * @param shFile
	 *            bash脚本的绝对路径
	 * @param paras
	 *            参数
	 * @return 是否执行成功
	 */
	public static boolean executeSh(String shFile, String[] paras)
	{
		return executeSh(shFile, paras, null, null, null);
	}

	/**
	 * 执行bash脚本
	 * 
	 * @param shFile
	 *            bash脚本的绝对路径
	 * @param paras
	 *            参数
	 * @param inputHandler
	 *            脚本执行正常输出的处理器（会在新线程中执行处理方法）
	 * @param outHandler
	 *            脚本执行后的输入流处理器（会在新线程中执行处理方法）
	 * @param errorHandler
	 *            脚本执行错误输出的处理器（会在新线程中执行处理方法）
	 * @return 是否执行成功
	 */
	public static boolean executeSh(String shFile, String[] paras, ScriptInputHandler inputHandler,
			ScriptOutputHandler outHandler, ScriptInputHandler errorHandler)
	{
		if (!StringTools.hasText(shFile)) throw new IllegalArgumentException("sh脚本路径不能为空");
		try
		{
			StringBuilder cmd = new StringBuilder("/bin/sh ");
			cmd.append(shFile);
			if (paras != null)
			{
				for (String para : paras)
					cmd.append(" ").append(para);
			}
			if (logger.isDebugEnabled()) logger.debug("cmd = " + cmd.toString());
			Process process = Runtime.getRuntime().exec(cmd.toString());
			handleInput(process.getInputStream(), inputHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle inputStream.");
			handleInput(process.getErrorStream(), errorHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle errorInput.");
			handleOutput(process.getOutputStream(), outHandler);
			if (process.waitFor() == 0) return true;
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		return false;
	}

	private static void handleInput(final InputStream input, final ScriptInputHandler handler)
	{
		final ScriptInputHandler myHandler = handler == null ? new DefaultScriptInputHandler() : handler;
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			public void run()
			{
				myHandler.handle(input);
			}
		});
		executor.shutdown();
	}

	private static void handleOutput(final OutputStream output, final ScriptOutputHandler handler)
	{
		if (handler == null) return;
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			public void run()
			{
				handler.handle(output);
			}
		});
		executor.shutdown();
	}

	/**
	 * 执行bat脚本
	 * 
	 * @param batFile
	 *            bat脚本的绝对路径
	 * @param paras
	 *            参数
	 * @return 是否执行成功
	 */
	public static boolean executeBat(String batFile, String[] paras)
	{
		return executeBat(batFile, paras, null, null, null);
	}

	/**
	 * 执行bat脚本
	 * 
	 * @param batFile
	 *            bat脚本的绝对路径
	 * @param paras
	 *            参数
	 * @param inputHandler
	 *            脚本执行正常输出的处理器（会在新线程中执行处理方法）
	 * @param outHandler
	 *            脚本执行后的输入流处理器（会在新线程中执行处理方法）
	 * @param errorHandler
	 *            脚本执行错误输出的处理器（会在新线程中执行处理方法）
	 * @return 是否执行成功
	 */
	public static boolean executeBat(String batFile, String[] paras, ScriptInputHandler inputHandler,
			ScriptOutputHandler outHandler, ScriptInputHandler errorHandler)
	{
		if (!StringTools.hasText(batFile)) throw new IllegalArgumentException("bat脚本路径不能为空");
		try
		{
			StringBuilder cmd = new StringBuilder("cmd /c ");
			cmd.append(batFile);
			if (paras != null)
			{
				for (String para : paras)
					cmd.append(" ").append(para);
			}
			if (logger.isDebugEnabled()) logger.debug("cmd = {}", cmd.toString());
			Process process = Runtime.getRuntime().exec(cmd.toString());
			handleInput(process.getInputStream(), inputHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle inputStream.");
			handleInput(process.getErrorStream(), errorHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle errorInput.");
			handleOutput(process.getOutputStream(), outHandler);
			return (process.waitFor() == 0) ? true : false;
		}
		catch (Exception e)
		{
			logger.error("", e);
			return false;
		}
	}

	/**
	 * 用ProcessBuilder的方式执行外部命令
	 * 
	 * @param pb
	 *            外部命令构造器
	 * @see {@link ProcessBuilder}
	 * @return 是否执行成功
	 */
	public static boolean processCommand(ProcessBuilder pb)
	{
		return processCommand(pb, (ScriptInputHandler) null, null, null);
	}

	/**
	 * 用ProcessBuilder的方式执行外部命令
	 * 
	 * @param pb
	 *            外部命令构造器
	 * @see {@link ProcessBuilder}
	 * @param inputHandler
	 *            脚本执行正常输出的处理器（会在新线程中执行处理方法）
	 * @param outHandler
	 *            脚本执行后的输入流处理器（会在新线程中执行处理方法）
	 * @param errorHandler
	 *            脚本执行错误输出的处理器（会在新线程中执行处理方法）
	 * @return 是否执行成功
	 */
	public static boolean processCommand(ProcessBuilder pb, ScriptInputHandler inputHandler,
			ScriptOutputHandler outHandler, ScriptInputHandler errorHandler)
	{
		if (pb == null) throw new IllegalArgumentException("ProcessBuilder不能为空");
		try
		{
			Process process = pb.start();
			handleInput(process.getInputStream(), inputHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle inputStream.");
			handleInput(process.getErrorStream(), errorHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle errorInput.");
			handleOutput(process.getOutputStream(), outHandler);
			return (process.waitFor() == 0) ? true : false;
		}
		catch (Exception e)
		{
			logger.error("", e);
			return false;
		}
	}

	/**
	 * 用ProcessBuilder的方式执行外部命令
	 * 
	 * @param pb
	 *            外部命令构造器
	 * @see {@link ProcessBuilder}
	 * @param inputHandler
	 *            脚本执行正常输出的处理器,结果做好（会在新线程中执行处理方法）
	 * @param outHandler
	 *            脚本执行后的输入流处理器（会在新线程中执行处理方法）
	 * @param errorHandler
	 *            脚本执行错误输出的处理器（会在新线程中执行处理方法）
	 * @return 执行结果，如果执行失败返回null
	 */
	public static <T> T processCmd(ProcessBuilder pb, CmdEcho2ResultHandler<T> inputHandler,
			ScriptOutputHandler outHandler, ScriptInputHandler errorHandler)
	{
		if (pb == null) throw new IllegalArgumentException("ProcessBuilder不能为空");
		if (inputHandler == null) throw new IllegalArgumentException("inputHandler不能为空");
		try
		{
			Process process = pb.start();
			String encoding = SystemTools.IS_OS_WINDOWS ? "GBK" : "UTF-8";
			String str = FileCopyTools.copyToStr(process.getInputStream(), encoding);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle inputStream.");
			handleInput(process.getErrorStream(), errorHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle errorInput.");
			handleOutput(process.getOutputStream(), outHandler);
			return process.waitFor() == 0 ? inputHandler.getResult(str) : null;
		}
		catch (Exception e)
		{
			logger.error("", e);
			return null;
		}
	}

	/**
	 * 用ProcessBuilder的方式执行外部命令
	 * 
	 * @param pb
	 *            外部命令构造器
	 * @see {@link ProcessBuilder}
	 * @param inputHandler
	 *            脚本执行正常输出的处理器（会在新线程中执行处理方法）
	 * @param outHandler
	 *            脚本执行后的输入流处理器（会在新线程中执行处理方法）
	 * @throws ScriptExecuteException
	 *             命令执行失败后会抛出该异常，错误信息见异常信息
	 */
	public static void executeCommand(ProcessBuilder pb, ScriptInputHandler inputHandler,
			ScriptOutputHandler outputHandler) throws ScriptExecuteException
	{
		if (pb == null) throw new IllegalArgumentException("ProcessBuilder不能为空");
		try
		{
			Process process = pb.start();
			handleInput(process.getInputStream(), inputHandler);
			if (logger.isDebugEnabled()) logger.debug("start new thread to handle inputStream.");
			handleOutput(process.getOutputStream(), outputHandler);
			String cs = (SystemTools.IS_OS_WINDOWS) ? "GBK" : "UTF-8";
			String error = FileCopyTools.copyToString(new InputStreamReader(process.getErrorStream(), cs));
			if (process.waitFor() != 0) throw new ScriptExecuteException("execute command failed:" + error);
		}
		catch (IOException e)
		{
			throw new ScriptExecuteException("execute command failed", e);
		}
		catch (InterruptedException e)
		{
			throw new ScriptExecuteException("execute command failed", e);
		}
	}
}
