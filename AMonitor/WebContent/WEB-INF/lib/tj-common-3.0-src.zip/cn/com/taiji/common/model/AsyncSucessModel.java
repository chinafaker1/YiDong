package cn.com.taiji.common.model;

import java.util.Calendar;

public class AsyncSucessModel<E> extends AbstractAsyncModel
{
	private E result;
	private String msg;
	private Calendar time;

	public AsyncSucessModel()
	{
		super(AsyncProcessType.SUCCESS);
	}

	public E getResult()
	{
		return result;
	}

	public void setResult(E result)
	{
		this.result = result;
	}

	public String getMsg()
	{
		return msg;
	}

	public void setMsg(String msg)
	{
		this.msg = msg;
	}

	public Calendar getTime()
	{
		return time;
	}

	public void setTime(Calendar time)
	{
		this.time = time;
	}
}
