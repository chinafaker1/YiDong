/*
 * Date: 2013-5-1
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import org.apache.http.message.BasicNameValuePair;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.model.json.AbstractProtocol;
import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-1 下午4:45:48<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @deprecated
 * @see {@link AbstractJsonCommManager}
 */
public abstract class JsonCommManager extends AbstractManager
{
	protected final <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request) throws IOException
	{
		return JsonCommHelper.httpPost(clazz, url, connTimeout, request);
	}

	protected final <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request, JsonProtocolPreHandler handler, BasicNameValuePair... additionalParams)
			throws IOException
	{
		return JsonCommHelper.httpPost(clazz, url, connTimeout, request, -1, handler, additionalParams);
	}

	protected final <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol request) throws IOException
	{
		return JsonCommHelper.httpPost(clazz, url, connTimeout, request);
	}

	protected final <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol request, JsonProtocolPreHandler handler, BasicNameValuePair... additionalParams)
			throws IOException
	{
		return JsonCommHelper.httpPost(clazz, url, connTimeout, request, -1, handler, additionalParams);
	}
}
