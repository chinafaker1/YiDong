/*
 * Date: 2013年10月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.quartz;

import cn.com.taiji.common.model.quartz.TaskEvent;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年10月12日 下午5:28:49<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface TaskListener
{
	public void taskBegin(TaskEvent event);

	public void taskFinish(TaskEvent event);
}
