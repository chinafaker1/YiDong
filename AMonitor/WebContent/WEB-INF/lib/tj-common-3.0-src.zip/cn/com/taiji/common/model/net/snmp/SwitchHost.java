package cn.com.taiji.common.model.net.snmp;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:35:14
 * @since 1.0
 * @version 1.0
 */
public class SwitchHost extends BaseModel
{
	private String ip;

	private String mac;

	private String gateway;

	private boolean online;

	public String getGateway()
	{
		return gateway;
	}

	public void setGateway(String gateway)
	{
		this.gateway = gateway;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getMac()
	{
		return mac;
	}

	public void setMac(String mac)
	{
		this.mac = mac;
	}

	public boolean isOnline()
	{
		return online;
	}

	public void setOnline(boolean online)
	{
		this.online = online;
	}

}
