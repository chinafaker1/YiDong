/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;
import cn.com.taiji.common.pub.file.FileTools;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午4:19:54<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class HttpFileProtocolModel extends BaseModel
{
	private String filename;
	private transient MultipartFile binFile;

	public String getFilename()
	{
		return filename;
	}

	@JsonIgnore
	public MultipartFile getBinFile()
	{
		return binFile;
	}

	public void setFilename(String filename)
	{
		this.filename = filename;
	}

	public void setBinFile(MultipartFile binFile)
	{
		this.binFile = binFile;
	}

	/**
	 * 将Http的请求变成协议的请求,{@link #IN_MEM_MAX_SIZE}以内的文件会直接在内存中缓存
	 * 
	 * @return
	 * @throws IOException
	 * @see {@link #IN_MEM_MAX_SIZE}
	 */
	public FileProtocolRequest toFileProtocolRequest() throws IOException
	{
		FileProtocolRequest request = new FileProtocolRequest();
		request.setFilename(filename);
		if (!StringTools.hasText(filename))
		{
			System.err.println("filename is not set,use the OriginalFilename instead.");
			request.setFilename(binFile.getOriginalFilename());
		}
		long size = binFile.getSize();
		if (size > 0 && size < FileProtocolConstant.IN_MEM_MAXSIZE.getSize())
		{
			request.setBinFile(new ByteArrayInputStream(binFile.getBytes()));
		}
		else
		{
			File file = new File(FileHelper.getTmpPath() + "/" + FileTools.generateUUIDName(null));
			binFile.transferTo(file);
			request.setBinFile(new FileInputStream(file));
			request.setTmpFile(file);// 设置缓存文件
		}
		return request;
	}
}
