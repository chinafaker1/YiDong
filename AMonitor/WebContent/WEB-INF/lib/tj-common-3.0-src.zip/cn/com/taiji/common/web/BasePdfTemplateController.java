/*
 * Date: 2011-6-15
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.File;
import java.io.FileInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.pub.PdfTemplateHelper;
import cn.com.taiji.common.model.pub.PdfContentInfo;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.file.FileTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-15 下午02:49:07<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class BasePdfTemplateController extends BaseDownloadController
{
	private final String templateUrl;
	private static String rootUrl;

	protected BasePdfTemplateController(String templateUrl)
	{
		AssertUtil.notNull(templateUrl);
		this.templateUrl = templateUrl;
	}

	protected void generatePdf(HttpServletRequest request, HttpServletResponse response, String displayName,
			PdfContentInfo info) throws Exception
	{
		AssertUtil.notNull(info);
		AssertUtil.hasText(displayName);
		info.setTemplateUrl(templateUrl);
		if (!hasText(info.getFileName())) info.setFileName(FileTools.generateUUIDName(displayName));
		File file = PdfTemplateHelper.generatePdf(info);
		super.doDownLoad(request, response, new FileInputStream(file), displayName);
	}

	protected String getRootUrl(HttpServletRequest request)
	{
		if (hasText(rootUrl)) return rootUrl;
		synchronized (request)
		{
			StringBuffer reURL = request.getRequestURL();
			rootUrl = reURL.substring(0, reURL.length() - request.getServletPath().length());
			rootUrl = rootUrl + "/";
		}
		return rootUrl;
	}
}
