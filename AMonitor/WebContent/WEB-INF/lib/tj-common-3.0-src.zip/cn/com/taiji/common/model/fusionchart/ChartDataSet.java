package cn.com.taiji.common.model.fusionchart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;

public class ChartDataSet extends BaseModel
{
	private String seriesName;
	private String color;
	private String renderAs;
	private String showValues = "0";
	private String parentYAxis;
	private List<ChartData> data;

	public List<ChartData> getData()
	{
		return data;
	}

	public ChartDataSet setData(List<ChartData> data)
	{
		this.data = data;
		return this;
	}

	public String getSeriesName()
	{
		return seriesName;
	}

	public ChartDataSet setSeriesName(String seriesName)
	{
		this.seriesName = seriesName;
		return this;
	}

	public String getColor()
	{
		return color;
	}

	public ChartDataSet setColor(String color)
	{
		this.color = color;
		return this;
	}

	public String getRenderAs()
	{
		return renderAs;
	}

	public ChartDataSet setRenderAs(String renderAs)
	{
		this.renderAs = renderAs;
		return this;
	}

	public String getShowValues()
	{
		return showValues;
	}

	public ChartDataSet setShowValues(String showValues)
	{
		this.showValues = showValues;
		return this;
	}

	public String getParentYAxis()
	{
		return parentYAxis;
	}

	public ChartDataSet setParentYAxis(String parentYAxis)
	{
		this.parentYAxis = parentYAxis;
		return this;
	}

	public static ChartDataSet newInstance(String seriesName, String color, List<ChartData> data)
	{
		ChartDataSet chartDataSet = new ChartDataSet();
		chartDataSet.setSeriesName(seriesName);
		chartDataSet.setColor(color);
		chartDataSet.setData(data);
		return chartDataSet;
	}

	public static ChartDataSet newInstance(String seriesName, String color, List<ChartData> data, String renderAs,
			String parentYAxis)
	{
		ChartDataSet chartDataSet = new ChartDataSet();
		chartDataSet.setSeriesName(seriesName);
		chartDataSet.setColor(color);
		chartDataSet.setData(data);
		chartDataSet.setRenderAs(renderAs);
		chartDataSet.setParentYAxis(parentYAxis);
		return chartDataSet;
	}

	public Map<String, Object> getDataSetMap(List<String> labelList)
	{
		Map<String, Object> map = new HashMap<String, Object>();
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		List<ChartData> dataAfterDeal = dealDataList(labelList, data);
		for (ChartData vo : dataAfterDeal)
		{
			dataList.add(vo.toChartDataMap());
		}
		if (StringTools.hasText(seriesName)) map.put("seriesName", seriesName);
		if (StringTools.hasText(color)) map.put("color", color);
		map.put("showValues", showValues);
		if (StringTools.hasText(renderAs)) map.put("renderAs", renderAs);
		map.put("data", dataList);
		if (StringTools.hasText(parentYAxis))
		{
			map.put("parentYAxis", parentYAxis);
		}
		return map;
	}

	private List<ChartData> dealDataList(List<String> labelList, List<ChartData> dataListTemp)
	{
		Map<String, ChartData> map = new HashMap<String, ChartData>();
		List<ChartData> rs = new ArrayList<ChartData>();
		for (ChartData vo : dataListTemp)
		{
			map.put(vo.getLabel(), vo);
		}
		for (String label : labelList)
		{
			if (map.get(label) != null)
			{
				rs.add(map.get(label));
			}
			else
			{
				rs.add(ChartData.newInstance(label, ""));
			}
		}
		return rs;
	}
}
