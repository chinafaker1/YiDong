package cn.com.taiji.common.model;

import java.io.Serializable;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-4-4 下午04:54:35
 * @since 1.0
 * @version 1.0
 */
public class Coordinate extends BaseModel implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -9083363483353244515L;
	private double x;
	private double y;

	public Coordinate()
	{

	}

	public Coordinate(double x, double y)
	{
		this.x = x;
		this.y = y;
	}

	public double getX()
	{
		return x;
	}

	public void setX(double x)
	{
		this.x = x;
	}

	public double getY()
	{
		return y;
	}

	public void setY(double y)
	{
		this.y = y;
	}

}
