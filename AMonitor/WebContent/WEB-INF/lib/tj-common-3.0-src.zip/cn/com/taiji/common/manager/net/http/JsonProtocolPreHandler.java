/*
 * Date: 2013-6-17
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-6-17 下午5:25:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface JsonProtocolPreHandler
{
	/**
	 * 转换成正式的返回前的拦截处理，如果返回不符合预期，抛出异常
	 * 
	 * @param protocol
	 * @throws IOException
	 */
	public void preHandle(final JsonProtocol protocol) throws IOException;
}
