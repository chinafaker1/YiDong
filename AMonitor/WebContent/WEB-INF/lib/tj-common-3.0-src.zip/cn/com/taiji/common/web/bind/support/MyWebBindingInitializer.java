package cn.com.taiji.common.web.bind.support;

import java.beans.PropertyEditor;
import java.util.Calendar;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.support.WebBindingInitializer;
import org.springframework.web.context.request.WebRequest;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-3-5 下午05:45:51
 * @since 1.0
 * @version 1.0
 */
public class MyWebBindingInitializer implements WebBindingInitializer
{
	public void initBinder(WebDataBinder binder, WebRequest request)
	{
		binder.registerCustomEditor(Calendar.class, new CustomCalendarEditor(false));
		// trim string
		PropertyEditor strEditor = new StringTrimmerEditor(true);
		binder.registerCustomEditor(String.class, strEditor);
	}

}
