/*
 * Date: 2011-12-20
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.format;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.springframework.core.convert.converter.Converter;

import cn.com.taiji.common.pub.StringTools;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-20 下午3:15:28<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class StringToCalendarConverter implements Converter<String, Calendar>
{
	@Override
	public Calendar convert(String source)
	{
		if (!StringTools.hasText(source)) return null;
		try
		{
			Calendar c = Calendar.getInstance();
			SimpleDateFormat normalDf = source.contains(":") ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
					: new SimpleDateFormat("yyyy-MM-dd");
			normalDf.setLenient(false);
			c.setTime(normalDf.parse(source));
			return c;
		}
		catch (ParseException ex)
		{
			IllegalArgumentException iae = new IllegalArgumentException("Could not parse date: " + ex.getMessage());
			iae.initCause(ex);
			throw iae;
		}
	}
}
