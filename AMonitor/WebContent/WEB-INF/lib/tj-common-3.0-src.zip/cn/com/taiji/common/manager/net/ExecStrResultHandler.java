package cn.com.taiji.common.manager.net;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-11-10 下午04:04:53<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface ExecStrResultHandler
{
	public void handle(String rs);
}
