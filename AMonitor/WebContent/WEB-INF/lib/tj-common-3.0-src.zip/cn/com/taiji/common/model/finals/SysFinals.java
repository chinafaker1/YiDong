package cn.com.taiji.common.model.finals;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-29 上午09:13:06
 * @since 1.0
 * @version 1.0
 */
public abstract class SysFinals
{
	public static final String SEPORATOR_WHITE = "\\s{1,}";

	public static final String SLASH = "/";
	public static final String MULTI_SLASH = "/{2,}";

	public static final int DEFAULT_PAGE_NUM = 1;
	public static int DEFAULT_PAGE_SIZE = 16;

	public static final String PART_FILE_SUFFIX = ".part";
}
