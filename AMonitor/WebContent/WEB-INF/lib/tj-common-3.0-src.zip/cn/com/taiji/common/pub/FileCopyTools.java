package cn.com.taiji.common.pub;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.pub.FileHelper;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-9 下午05:33:27
 * @since 1.0
 * @version 1.1
 * @see {@link FileUtils}
 */
public abstract class FileCopyTools extends FileCopyUtils
{
	public static void moveToDirectory(File src, File destDir, boolean createDestDir) throws IOException
	{
		FileUtils.moveToDirectory(src, destDir, createDestDir);
	}

	public static void moveFileToDirectory(File srcFile, File destDir, boolean createDestDir) throws IOException
	{
		FileUtils.moveFileToDirectory(srcFile, destDir, createDestDir);
	}

	public static void moveDirectory(File srcDir, File destDir) throws IOException
	{
		FileUtils.moveDirectory(srcDir, destDir);
	}

	public static void moveDirectoryToDirectory(File src, File destDir, boolean createDestDir) throws IOException
	{
		FileUtils.moveDirectoryToDirectory(src, destDir, createDestDir);
	}

	/**
	 * 
	 * @param srcFile
	 * @param destFile
	 * @throws IOException
	 * @see {@link FileUtils#moveFile(File, File)}
	 */
	public static void moveFile(File srcFile, File destFile) throws IOException
	{
		FileUtils.moveFile(srcFile, destFile);
	}

	public static void moveFile(File srcFile, String bakSuffix, File destFile, int maxCount) throws IOException
	{
		File myDest = getNonExistFile(destFile, bakSuffix, maxCount);
		FileUtils.moveFile(srcFile, myDest);
	}

	private static File getNonExistFile(File destFile, String bakSuffix, int maxCount) throws IOException
	{
		if (!destFile.exists()) return destFile;
		String path = destFile.getAbsolutePath();
		for (int i = 1; i <= maxCount; i++)
		{
			File rs = new File(path + bakSuffix + i);
			if (!rs.exists()) return rs;
		}
		throw new IOException("You are not a lucky guy,the bak files more than " + maxCount);
	}

	public static void writeLines(OutputStream stream, List<String> lines, String encoding) throws IOException
	{
		AssertUtil.allElementsHasValue(stream, lines);
		String myEncoding = StringTools.hasText(encoding) ? encoding : "UTF-8";
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new OutputStreamWriter(stream, myEncoding));
			for (String line : lines)
			{
				writer.write(line);
				writer.newLine();
			}
			writer.flush();
		}
		finally
		{
			if (writer != null) writer.close();
			stream.close();
		}
	}

	public static List<String> copyToLines(File file, boolean ingoreEmptyLine) throws IOException
	{
		return copyToLines(file, "UTF-8", ingoreEmptyLine);
	}

	public static List<String> copyToLines(File file, String encoding) throws IOException
	{
		return copyToLines(file, encoding, false);
	}

	/**
	 * 将文件的内容按行拷贝出来
	 * 
	 * @param file
	 *            文件
	 * @param encoding
	 *            文件编码方式
	 * @param ingoreEmptyLine
	 *            是否忽略空行
	 * @param startLine
	 *            开始拷贝的行数,&lt;=1时从头开始(含起始行)
	 * @param maxLine
	 *            最多拷贝多少行,&lt;1时全部拷贝
	 * @return
	 * @throws IOException
	 */
	public static List<String> copyToLines(File file, String encoding, boolean ingoreEmptyLine, int startLine,
			int maxLine) throws IOException
	{
		List<String> rs = new ArrayList<String>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), encoding));
		try
		{
			String line = null;
			int lineNum = 0;
			if (startLine < 1) startLine = 1;
			while ((line = reader.readLine()) != null)
			{
				lineNum++;
				if (startLine > 0 && lineNum < startLine) continue;// 小于起始行，忽略
				if (maxLine > 0 && (lineNum - startLine) >= maxLine) break;
				if (ingoreEmptyLine && !StringTools.hasText(line)) continue;
				rs.add(line);
			}
		}
		finally
		{
			if (reader != null) reader.close();
		}
		return rs;
	}

	public static List<String> copyToLines(File file, String encoding, boolean ingoreEmptyLine) throws IOException
	{
		return copyToLines(file, encoding, ingoreEmptyLine, -1, -1);
	}

	public static String copyToStr(File file) throws IOException
	{
		return copyToStr(new FileInputStream(file), "UTF-8");
	}

	public static String copyToStr(File file, String encoding) throws IOException
	{
		return copyToStr(new FileInputStream(file), encoding);
	}

	public static String copyToStr(InputStream input, String encoding) throws IOException
	{
		AssertUtil.notNull(input);
		StringBuilder rs = new StringBuilder();
		BufferedReader reader = new BufferedReader(new InputStreamReader(input, encoding));
		try
		{
			char[] buff = new char[40960];
			int read = -1;
			while ((read = reader.read(buff)) != -1)
			{
				rs.append(buff, 0, read);
			}
		}
		finally
		{
			if (reader != null) reader.close();
		}
		return rs.toString();
	}

	/**
	 * 拷贝流的内容直到匹配pattern给定的字符串,不会关闭Input
	 * 
	 * @param encoding
	 *            流的编码
	 * @param in
	 * @param pattern
	 *            以非中文字符结尾
	 * @return
	 * @throws IOException
	 */
	public static String copyUntil(String encoding, InputStream in, String pattern) throws IOException
	{
		AssertUtil.allElementsHasValue(in, pattern);
		String charset = StringTools.hasText(encoding) ? encoding : "UTF-8";
		char lastByte = pattern.charAt(pattern.length() - 1);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int read = -1;
		while ((read = in.read()) != -1)
		{
			out.write(read);
			if (read == lastByte)
			{
				String rs = new String(out.toByteArray(), charset);
				if (rs.endsWith(pattern))
				{
					out.close();
					return rs;
				}
			}
		}
		out.close();
		throw new RuntimeException("Can not find the String with pattern :" + pattern);
	}

	/**
	 * 文件夹拷贝
	 * 
	 * @param srcFloder
	 *            源文件夹
	 * @param filter
	 *            文件夹过滤器，递归适用，null忽略
	 * @param destFloder
	 *            目地文件夹
	 * @param overwrite
	 *            是否覆盖
	 * @throws IOException
	 *             拷贝异常时抛出
	 */
	public static void copyFloder(File srcFloder, FileFilter filter, File destFloder, boolean overwrite)
			throws IOException
	{
		AssertUtil.allElementsHasValue(srcFloder, destFloder);
		if (!srcFloder.isDirectory()) throw new IOException("src floder is not a directory.");
		if (!destFloder.isDirectory()) throw new IOException("dest floder is not a directory.");
		String destDirectory = FileHelper.toUnixFloder(destFloder.getAbsolutePath(), true);
		recrusiveCopy(srcFloder, filter, destDirectory, overwrite, "");
	}

	private static void recrusiveCopy(File srcFloder, FileFilter filter, String destFloder, boolean overwrite,
			String appendPath) throws IOException
	{
		File[] files = srcFloder.listFiles(filter);
		if (ObjectTools.isEmpty(files)) return;
		for (File file : files)
		{
			if (file.isDirectory())
			{
				recrusiveCopy(file, filter, destFloder, overwrite, appendPath + "/" + file.getName());
				continue;
			}
			File destFile = new File(destFloder + appendPath + "/" + file.getName());
			if (!overwrite && destFile.isFile()) continue;
			destFile.getParentFile().mkdirs();
			if (!destFile.isFile() && !destFile.createNewFile())
				throw new IOException(StringTools.toLogString("创建文件({})失败", destFile.getAbsolutePath()));
			copy(file, destFile);
		}
	}

}
