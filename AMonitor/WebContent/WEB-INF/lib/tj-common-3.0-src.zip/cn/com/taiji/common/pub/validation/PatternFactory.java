package cn.com.taiji.common.pub.validation;

import java.util.Calendar;
import java.util.regex.Pattern;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.pub.StringTools;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-21 上午10:36:44
 * @since 1.0
 * @version 1.0
 */
public abstract class PatternFactory extends AbstractManager
{
	// 身份证号码正则，详细校验见方法
	public static final String idCodeRegexp = "^[1-9]{1}[0-9]{14}$|^[1-9]{1}[0-9]{17}$|^[1-9]{1}[0-9]{16}X$|^[1-9]{1}[0-9]{16}x$";
	// 手机号码正则
	public static final String mobileRegexp = "^13[0-9]{9}|14[0-9]{9}|15[0-9]{9}|17[0-9]{9}|18[0-9]{9}$";
	// 电话号码正则
	public static final String phoneRegexp = "^0[1-9][0-9]{1,2}[\\-]?[1-9][0-9]{6,7}$|^[1-9][0-9]{6,7}$|^0[1-9][0-9]{1,2}[\\-]?[1-9][0-9]{6,7}\\-[0-9]{1,4}$|^[1-9][0-9]{6,7}\\-[0-9]{1,4}$|^0{0,1}13[0-9]{9}$|^0{0,1}15[0-9]{9}$|^0{0,1}18[0-9]{9}$";
	// 邮编正则
	public static final String zipRegexp = "^\\d{6}$";
	// 驾档编号正则
	public static final String driverIdRegexp = "^[1-9]{1}[0-9]{11}$|^[1-9]{1}[0-9]{9}$";
	// 邮箱正则
	public static final String emailRegexp = "^((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-zA-Z]|\\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|\\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\\d|-|\\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|\\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\\.)+(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\\d|-|\\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\\.?$";
	// 中文名字正则
	public static final String chineseNameRegexp = "^[\u4e00-\u9fa5·]+$";
	// 非中文字符正则
	public static final String noChineseRegexp = "^[^\u4e00-\u9fa5]+$";
	// 组织机构代码正则，详细见校验方法
	public static final String orgCodeRegexp = "^[0-9A-Z]{9}$";
	// 台湾往来大陆通行证
	public static final String twCnIdCodeRegexp = "^(\\d{8}|\\d{10})$";
	// 地税号 为数字+大写字母，9-25位 并且后9为是 组织机构代码
	public static final String localTaxCodeRegexp = "^[0-9A-Z]{9}[0-9A-Z]{0,16}$";
	// 整数正则
	public static final String intRegexp = "^(\\-)?[0-9]{1,19}$";
	// 密码8-20位，字母+数字
	public static final String passwordRegexp = "^(?![0-9]+$)(?![a-zA-Z]+$)(?![!@#$%^&*()_.']+$)[0-9A-Za-z!@#$%^&*()_.']{8,20}$";
	// 港澳往来内地通行证
	public static final String gaCnIdCodeRegexp = "^[H,M]\\d{10}$";
	// URL
	public static final String urlRegexp = "^[a-zA-z]+://(\\w+(-\\w+)*)(\\.(\\w+(-\\w+)*))*(\\?\\S*)?$";
	// MAC地址
	public static final String macRegexp = "^(([0-9a-fA-F]{2})(-[0-9a-fA-F]{2}){5})|(([0-9a-fA-F]{2})(:[0-9a-fA-F]{2}){5})|(([0-9a-fA-F]{2})([0-9a-fA-F]{2}){5})$";

	private static final Pattern idCodePattern = Pattern.compile(idCodeRegexp);
	public static final Pattern mobilePattern = Pattern.compile(mobileRegexp);
	public static final Pattern phonePattern = Pattern.compile(phoneRegexp);
	public static final Pattern zipCodePattern = Pattern.compile(zipRegexp);
	public static final Pattern driverIdPattern = Pattern.compile(driverIdRegexp);
	public static final Pattern emailPattern = Pattern.compile(emailRegexp);
	public static final Pattern chineseNamePattern = Pattern.compile(chineseNameRegexp);
	public static final Pattern noChinesePattern = Pattern.compile(noChineseRegexp);
	private static final Pattern orgCodePattern = Pattern.compile(orgCodeRegexp);
	public static final Pattern twCnIdCodePattern = Pattern.compile(twCnIdCodeRegexp);
	public static final Pattern localTaxCodePattern = Pattern.compile(localTaxCodeRegexp);
	public static final Pattern intPattern = Pattern.compile(intRegexp);
	public static final Pattern passwordPattern = Pattern.compile(passwordRegexp);// 密码8-20位
	public static final Pattern gaCnIdCodePattern = Pattern.compile(gaCnIdCodeRegexp);
	public static final Pattern urlPattern = Pattern.compile(urlRegexp);
	public static final Pattern macPattern = Pattern.compile(macRegexp);

	/**
	 * 检查字符串中是否有全角字符
	 * 
	 * @param str
	 * @return 含有全角字符时返回true
	 */
	public static boolean hasQuanJiao(String str)
	{
		int length = str.length();
		int bytLength = str.getBytes().length;
		// 都是半角的情况
		if (bytLength == length) return false;
		// 都是全角的情况
		if (bytLength == 2 * length) return true;
		// 有全角有半角
		return true;
	}

	private static final int[] idWeight = { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 };
	private static final String[] idLastCode = { "1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2" };

	/**
	 * 检测身份证号码格式
	 * 
	 * @param idCode
	 * @throws ManagerException
	 */
	public static boolean isIdCodeValid(String idCode)
	{
		if (!StringTools.hasText(idCode)) return false;
		boolean b = idCodePattern.matcher(idCode).matches();
		if (!b) return false;
		String inYear = (idCode.length() == 18) ? idCode.substring(6, 10) : "19" + idCode.substring(6, 8);
		String inMonth = (idCode.length() == 18) ? idCode.substring(10, 12) : idCode.substring(8, 10);
		String inDay = (idCode.length() == 18) ? idCode.substring(12, 14) : idCode.substring(10, 12);
		Calendar idCodeTime = Calendar.getInstance();
		idCodeTime.set(Integer.parseInt(inYear), Integer.parseInt(inMonth) - 1, Integer.parseInt(inDay));
		Calendar now = Calendar.getInstance();
		int year = idCodeTime.get(Calendar.YEAR);
		int month = idCodeTime.get(Calendar.MONTH) + 1;
		int day = idCodeTime.get(Calendar.DAY_OF_MONTH);
		if (!(Integer.parseInt(inYear) == year) || !(Integer.parseInt(inMonth) == month)
				|| !(Integer.parseInt(inDay) == day) || idCodeTime.after(now) || year < 1900) return false;
		if (idCode.length() == 15) return true;
		int sum = 0;
		for (int i = 0; i < 17; i++)
		{
			sum += Integer.parseInt(idCode.substring(i, i + 1)) * idWeight[i];
		}
		int idIndex = sum % 11;
		return idLastCode[idIndex].equals(idCode.toUpperCase().substring(17));
	}

	private static final String symbol = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int[] orgWeight = { 3, 7, 9, 10, 5, 8, 4, 2 };
	private static final String[] orgLastCode = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "X", "0" };

	public static boolean isOrgCodeFormat(String orgCode)
	{
		if (!hasText(orgCode)) return false;
		boolean b = orgCodePattern.matcher(orgCode).matches();
		if (!b) return false;
		int sum = 0;
		for (int i = 0; i < 8; i++)
		{
			String temp = orgCode.substring(i, i + 1);
			sum += symbol.indexOf(temp) * orgWeight[i];
		}
		int idIndex = 11 - (sum % 11);
		return orgLastCode[idIndex].equals(orgCode.substring(8));
	}
}
