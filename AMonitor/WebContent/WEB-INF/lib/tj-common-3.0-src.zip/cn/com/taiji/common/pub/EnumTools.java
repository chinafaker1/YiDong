/*
 * Date: 2014年4月14日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub;

import org.apache.commons.lang3.EnumUtils;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年4月14日 下午7:51:31<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class EnumTools extends EnumUtils
{
	/**
	 * 判断所指定的名字是否是指定枚举数组中的一个
	 * 
	 * @param enumClass
	 *            指定的枚举类型
	 * @param enumName
	 *            枚举的名字
	 * @param enums
	 *            枚举数组
	 * @return
	 */
	public static <E extends Enum<E>> boolean isInEnums(final Class<E> enumClass, final String enumName, E... enums)
	{
		if (enums == null || enumName == null) return false;
		E e = getEnum(enumClass, enumName);
		if (e == null) return false;
		for (Enum<E> en : enums)
		{
			if (en == e) return true;
		}
		return false;
	}
}
