package cn.com.taiji.common.model.pub;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2010-1-19 下午11:01:30<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.5
 * @version 1.0
 */
public class IPLocation extends BaseModel
{
	private String country;
	private String area;

	public IPLocation()
	{
		country = area = "";
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getArea()
	{
		return area;
	}

	public void setArea(String area)
	{
		this.area = area;
	}
}