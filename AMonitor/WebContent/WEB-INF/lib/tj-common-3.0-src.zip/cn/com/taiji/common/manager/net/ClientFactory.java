package cn.com.taiji.common.manager.net;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.snmp4j.Snmp;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.security.UsmUser;
import org.snmp4j.smi.OctetString;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.xsocket.datagram.ConnectedEndpoint;
import org.xsocket.datagram.IConnectedEndpoint;

import cn.com.taiji.common.model.net.BaseTarget;
import cn.com.taiji.common.model.net.snmp.SnmpV3Target;

import com.google.common.collect.Maps;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:15:10
 * @since 1.0
 * @version 1.0
 */
public class ClientFactory
{
	protected static Logger logger = LoggerFactory.getLogger(ClientFactory.class);
	private static Map<String, IConnectedEndpoint> udpClients = Maps.newConcurrentMap();
	private static Map<String, Snmp> snmpClients = Maps.newConcurrentMap();
	private static Map<String, Snmp> snmpV3Clients = Maps.newConcurrentMap();

	public static IConnectedEndpoint getUDPClient(String hostname, int port) throws IOException
	{
		String key = hostname + ":" + port;
		IConnectedEndpoint client = udpClients.get(key);
		if (client != null) return client;
		client = new ConnectedEndpoint(hostname, port);
		if (udpClients.size() > 10)
		{
			Set<String> keys = udpClients.keySet();
			IConnectedEndpoint tmp = udpClients.remove(keys.iterator().next());
			try
			{
				tmp.close();
			}
			catch (IOException e)
			{
				logger.error("connection is already broken.", e);
			}
			udpClients.put(key, client);
			logger.info("生成新UDP连接:{}", key);
		}
		return client;
	}

	public static void stopUDPClients()
	{
		try
		{
			for (IConnectedEndpoint client : udpClients.values())
			{
				try
				{
					client.close();
				}
				catch (IOException e)
				{
					logger.error("", e);
				}
			}
			logger.info("关闭UDP连接池成功");
		}
		finally
		{
			udpClients.clear();
		}
	}

	public static void removeUDPClient(String hostname, int port)
	{
		String key = hostname + ":" + port;
		IConnectedEndpoint client = udpClients.remove(key);
		try
		{
			client.close();
		}
		catch (IOException e)
		{
			logger.warn("close client error.");
		}
	}

	public static Snmp getSnmpClient(BaseTarget target) throws IOException
	{
		String key = getKey(target);
		Snmp client = snmpClients.get(key);
		if (client != null) return client;
		client = new Snmp(new DefaultUdpTransportMapping());
		client.listen();
		if (snmpClients.size() > 10)
		{
			Set<String> keys = snmpClients.keySet();
			Snmp tmp = snmpClients.remove(keys.iterator().next());
			tmp.close();
		}
		snmpClients.put(key, client);
		logger.info("生成新Snmp连接:{}", key);
		return client;
	}

	public static Snmp getSnmpV3Client(SnmpV3Target target) throws IOException
	{
		String key = getKey(target);
		Snmp client = snmpV3Clients.get(key);
		if (client != null) return client;
		client = new Snmp(new DefaultUdpTransportMapping());

		USM usm = new USM(SecurityProtocols.getInstance(), new OctetString(MPv3.createLocalEngineID()), 0);
		SecurityModels.getInstance().addSecurityModel(usm);
		UsmUser user = new UsmUser(new OctetString(target.getSecurityName()), target.getAuthOid(), new OctetString(
				target.getAuthPass()), target.getPriOid(), new OctetString(target.getPriPass()));
		client.getUSM().addUser(new OctetString(target.getSecurityName()), user);

		client.listen();
		if (snmpV3Clients.size() > 10)
		{
			Set<String> keys = snmpV3Clients.keySet();
			Snmp tmp = snmpV3Clients.remove(keys.iterator().next());
			tmp.close();
		}
		snmpV3Clients.put(key, client);
		logger.info("生成新Snmp V3连接:" + key);
		return client;
	}

	public static void stopSnmpClients()
	{
		try
		{
			for (Snmp snmp : snmpClients.values())
			{
				try
				{
					snmp.close();
				}
				catch (IOException e)
				{
					logger.error("", e);
				}
			}
			logger.info("关闭snmp连接池成功");
		}
		finally
		{
			snmpClients.clear();
		}
	}

	public static void stopSnmpV3Clients()
	{
		try
		{
			for (Snmp snmp : snmpV3Clients.values())
			{
				try
				{
					snmp.close();
				}
				catch (IOException e)
				{
					logger.error(e.getMessage(), e);
				}
			}
			logger.info("关闭snmp V3连接池成功");
		}
		finally
		{
			snmpV3Clients.clear();
		}
	}

	public static void removeSnmpClient(BaseTarget target)
	{
		String key = getKey(target);
		snmpClients.remove(key);
	}

	public static void removeSnmpV3Client(SnmpV3Target target)
	{
		String key = getKey(target);
		snmpV3Clients.remove(key);
	}

	private static String getKey(BaseTarget target)
	{
		String ip = target.getIp();
		if (ip == null) throw new RuntimeException("BaseTarget ip can not be null.");
		String key = new StringBuilder(ip).append("+").append(target.getPort()).toString();
		return key;
	}
}
