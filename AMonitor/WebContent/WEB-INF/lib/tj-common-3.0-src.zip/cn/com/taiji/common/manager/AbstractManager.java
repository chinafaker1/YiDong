package cn.com.taiji.common.manager;

import java.io.Closeable;
import java.io.IOException;

import cn.com.taiji.common.pub.CommonAbstract;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2008-2-22 上午10:29:41
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractManager extends CommonAbstract
{
	public static void closeQuietly(Closeable closeable)
	{
		try
		{
			if (closeable != null) closeable.close();
		}
		catch (IOException ioe)
		{
			// ignore
		}
	}
}
