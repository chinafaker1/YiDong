/*
 * Date: 2013-6-13
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.manager.net.http.HttpClientInterceptor;
import cn.com.taiji.common.manager.net.http.HttpResponseHandler;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-6-13 下午5:20:47<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractHttpHelper extends AbstractHelper
{
	protected static int DEFAULT_CONN_TIMEOUT = 5000;
	protected static int DEFAULT_BUFFER_SIZE = 4096;
	protected static String DEFAULT_ENCODING = "UTF-8";
	protected static SSLConnectionSocketFactory ssf;

	static
	{
		X509TrustManager tm = new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers()
			{
				return null;
			}

			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
			{}

			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
			{}
		};
		HostnameVerifier verifier = new HostnameVerifier() {
			@Override
			public boolean verify(String string, SSLSession ssls)
			{
				return true;
			}
		};
		try
		{
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { tm }, null);
			ssf = new SSLConnectionSocketFactory(ctx, verifier);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	protected static URI getURI(String uriStr, HttpServletRequest request) throws URISyntaxException
	{
		URI uri = new URI(uriStr);
		List<NameValuePair> params = params2List(request);
		String schema = uri.getScheme();
		schema = hasText(schema) ? schema : "http";
		URI rsUri = new URIBuilder().setScheme(schema).setHost(uri.getHost()).setPort(uri.getPort())
				.setPath(uri.getPath()).setParameters(params).build();
		return rsUri;
	}

	protected static List<NameValuePair> params2List(HttpServletRequest request)
	{
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		Map<String, String[]> paramMap = request.getParameterMap();
		for (Entry<String, String[]> en : paramMap.entrySet())
		{
			String name = en.getKey();
			String[] values = en.getValue();
			if (isEmpty(values)) continue;
			for (String value : values)
			{
				if (hasText(value)) params.add(new BasicNameValuePair(name, value));
			}
		}
		return params;
	}

	public static String getFilename(Header header)
	{
		if (header == null || header.getElements() == null || header.getElements().length == 0) return null;
		for (HeaderElement ele : header.getElements())
		{
			if (isEmpty(ele.getParameters())) continue;
			for (NameValuePair nv : ele.getParameters())
			{
				if (nv.getName() != null && nv.getName().toLowerCase().contains("filename")) return nv.getValue();
			}
		}
		return null;
	}

	public static <T> T httpRequest(HttpUriRequest request, int connTimeout, HttpResponseHandler<T> handler,
			int soTimeout) throws IOException
	{
		return httpRequest(request, false, connTimeout, handler, soTimeout);
	}

	public static boolean isContentGziped(HttpResponse response)
	{
		Header header = response.getFirstHeader(HTTP.CONTENT_ENCODING);
		if (header == null) return false;
		String str = header.getValue();
		return str == null ? false : str.toLowerCase().indexOf("gzip") != -1;
	}

	public static <T> T httpRequest(HttpUriRequest request, boolean enableGzip, int connTimeout,
			HttpResponseHandler<T> handler, int soTimeout) throws IOException
	{
		return httpRequest(request, enableGzip, connTimeout, handler, soTimeout, null);
	}

	/**
	 * http请求
	 * 
	 * @param request
	 *            请求
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param enableGzip
	 *            是否要求服务端启用gzip压缩
	 * @param handler
	 *            返回内容处理的回调接口
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param interceptor
	 *            请求拦截器
	 * @return 处理结果
	 * @throws IOException
	 */
	public static <T> T httpRequest(HttpUriRequest request, boolean enableGzip, int connTimeout,
			HttpResponseHandler<T> handler, int soTimeout, HttpClientInterceptor interceptor) throws IOException
	{
		AssertUtil.notNull(handler);
		HttpClientBuilder builder = prepareClientBuilder(connTimeout, request, soTimeout, enableGzip);
		if (interceptor != null) interceptor.process(builder, request);
		CloseableHttpClient client = builder.build();
		try
		{
			HttpResponse response = client.execute(request);
			return handler.handle(response);
		}
		finally
		{
			if (client != null) client.close();
		}
	}

	protected static HttpClientBuilder prepareClientBuilder(int connTimeout, HttpUriRequest request, int soTimeout,
			boolean enableGzip)
	{
		HttpClientBuilder builder = HttpClientBuilder.create();
		RequestConfig.Builder configBuilder = RequestConfig.custom();
		if (connTimeout > 0) configBuilder.build();
		if (soTimeout > 0) configBuilder.setSocketTimeout(soTimeout);
		builder.setDefaultRequestConfig(configBuilder.build());
		String schema = request.getURI().getScheme();
		boolean https = "https".equalsIgnoreCase(schema);
		if (https) builder.setSSLSocketFactory(ssf);// 使用ssl配置
		// 4.3以后会自动在interceptor中实现启用压缩和自动解压，所以不需要gzip的时候需要指定一下
		if (!enableGzip) builder.disableContentCompression();
		// 增加interceptor 显示压缩情况
		builder.addInterceptorFirst(MyHttpResponseInterceptor.instance);
		return builder;
	}

	private static class MyHttpResponseInterceptor extends AbstractManager implements HttpResponseInterceptor
	{
		public static final MyHttpResponseInterceptor instance = new MyHttpResponseInterceptor();

		@Override
		public void process(HttpResponse response, HttpContext context) throws HttpException, IOException
		{
			boolean gzip = isContentGziped(response);
			HttpEntity entity = response.getEntity();
			long length = entity == null ? 0 : entity.getContentLength();
			logger.debug("content gziped:{}\t entity length:{}", gzip, length);
		}
	}
}
