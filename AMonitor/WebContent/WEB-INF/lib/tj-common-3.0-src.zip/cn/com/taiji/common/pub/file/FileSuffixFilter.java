package cn.com.taiji.common.pub.file;

import java.io.File;
import java.io.FileFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-2-26 下午06:44:47
 * @since 1.0
 * @version 1.0
 */
public class FileSuffixFilter implements FileFilter
{
	protected Logger logger = LoggerFactory.getLogger(getClass());

	private final String suffix;
	private boolean onleyFile;

	public FileSuffixFilter(String suffix)
	{
		this(suffix, true);
	}

	public FileSuffixFilter(String suffix, boolean onlyFile)
	{
		this.suffix = (suffix == null) ? null : suffix.toLowerCase();
		this.onleyFile = onlyFile;
	}

	public boolean accept(File pathname)
	{
		if (pathname.isDirectory() && onleyFile) return false;
		String fileName = pathname.getName().toLowerCase();
		if (suffix == null || fileName.endsWith(suffix)) return true;
		return false;
	}

}
