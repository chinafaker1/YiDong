package cn.com.taiji.common.model.net.snmp;

import org.snmp4j.PDUv1;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-6 下午04:47:32
 * @since 1.0
 * @version 1.0
 */
public interface V1Trap
{
	public PDUv1 getV1Trap();
}
