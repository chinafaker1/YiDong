package cn.com.taiji.common.pub.handler;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import cn.com.taiji.common.manager.AbstractManager;
import cn.com.taiji.common.pub.SystemTools;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-1 上午09:52:59
 * @since 1.0
 * @version 1.0
 */
public class DefaultScriptInputHandler extends AbstractManager implements ScriptInputHandler
{
	private final String encoding;

	public DefaultScriptInputHandler(String encodeing)
	{
		this.encoding = encodeing;
	}

	public DefaultScriptInputHandler()
	{
		this.encoding = SystemTools.IS_OS_WINDOWS ? "GBK" : "UTF-8";
	}

	public void handle(final InputStream input)
	{
		if (input == null)
		{
			logger.debug("Input is null.");
			return;
		}
		BufferedInputStream in = new BufferedInputStream(input);
		try
		{
			byte[] buff = new byte[10240];
			int read = 0;
			while ((read = in.read(buff)) >= 0)
			{
				if (logger.isDebugEnabled())
				{
					System.out.print(new String(buff, 0, read, encoding));
				}
			}
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(), e);
		}
		finally
		{
			try
			{
				if (in != null) in.close();
			}
			catch (IOException e)
			{
			}
		}
	}

}
