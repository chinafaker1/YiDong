/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.util.EntityUtils;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.file.FileProtocolConstant;
import cn.com.taiji.common.model.file.FileProtocolRequest;
import cn.com.taiji.common.model.file.FileProtocolResponse;
import cn.com.taiji.common.model.file.HttpFileProtocolModel;
import cn.com.taiji.common.pub.FileCopyTools;
import cn.com.taiji.common.pub.SecurityUtil;
import cn.com.taiji.common.pub.SecurityUtil.HashType;
import cn.com.taiji.common.pub.file.FileTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午5:22:16<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link HttpFileProtocolModel}
 */
public abstract class FileCommHelper extends HttpClientHelper
{

	public static FileProtocolResponse filePost(String url, FileProtocolRequest fileRequest) throws IOException
	{
		return filePost(url, DEFAULT_CONN_TIMEOUT, fileRequest, -1);
	}

	/**
	 * 通过HTTP发送二进制请求
	 * 
	 * @param url
	 *            服务端URL
	 * @param connTimeout
	 *            连接超时毫秒数，-1不超时
	 * @param fileRequest
	 *            请求的属性，见其属性注释
	 * @param soTimeout
	 * @return
	 * @throws IOException
	 */
	public static FileProtocolResponse filePost(String url, int connTimeout, FileProtocolRequest fileRequest,
			int soTimeout) throws IOException
	{
		final HttpPost post = new HttpPost(url);
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		addHeaders(post, fileRequest);
		String filename = fileRequest.getFilename();
		builder.addBinaryBody("binFile", fileRequest.getBinFile(), ContentType.DEFAULT_BINARY, filename);// 文件
		builder.addTextBody("filename", filename, ContentType.create(ContentType.DEFAULT_TEXT.getMimeType(), "UTF-8"));
		post.setEntity(builder.build());
		return httpRequest(post, fileRequest.isEnableGzip(), connTimeout, new FileCommResponseHandler(post), soTimeout);
	}

	private static void addHeaders(HttpPost post, FileProtocolRequest fileRequest) throws IOException
	{
		String md5 = fileRequest.getMd5();
		if (hasText(md5)) post.addHeader(FileProtocolConstant.MD5_HEADER.getValue(), md5);
		String auth = fileRequest.getAuthStr();
		if (hasText(auth)) post.addHeader(FileProtocolConstant.AUTH_HEADER.getValue(), auth);
		if (fileRequest.isEnableGzip()) post.addHeader(FileProtocolConstant.GZIP_HEADER.getValue(), "true");
	}

	static class FileCommResponseHandler implements HttpResponseHandler<FileProtocolResponse>
	{
		private final HttpPost post;

		private FileCommResponseHandler(HttpPost post)
		{
			this.post = post;
		}

		@Override
		public FileProtocolResponse handle(HttpResponse response) throws IOException
		{
			HttpEntity entity = response.getEntity();
			if (entity == null) throw new IOException(toLogString("No response:{}", post.getURI().toString()));
			StatusLine sl = response.getStatusLine();
			int code = sl.getStatusCode();
			if (code >= FileProtocolResponse.MIN_ERROR_CODE)// 出现自定义错误，先返回
			{
				String errorMsg = EntityUtils.toString(entity, "UTF-8");
				return new FileProtocolResponse(code, errorMsg);
			}
			if (code >= 400) // http的其他错误，抛异常
				throw new IOException(toLogString("Request Error:{}\t{}", code, post.getURI().toString()));
			FileProtocolResponse rs = new FileProtocolResponse(code, null);
			String filename = getFilename(response.getFirstHeader("Content-Disposition"));
			if (!hasText(filename)) throw new IOException("返回的结果中没有指定文件名.");
			rs.setFilename(filename);
			long size = entity.getContentLength();
			if (size > 0 && size < FileProtocolConstant.IN_MEM_MAXSIZE.getSize())
			{
				byte[] bytes = EntityUtils.toByteArray(entity);
				rs.setBinFile(new ByteArrayInputStream(bytes));
			}
			else
			{
				File tmpFile = new File(FileHelper.getTmpPath() + "/" + FileTools.generateUUIDName(filename));
				FileCopyTools.copy(entity.getContent(), new FileOutputStream(tmpFile));
				rs.setBinFile(new FileInputStream(tmpFile));
				rs.setTmpFile(tmpFile);// 将响应结果存入文件缓存。
			}
			// 校验返回的md5值与收到的流是否一致
			checkMd5(rs, response);
			return rs;
		}

		private void checkMd5(FileProtocolResponse protocol, HttpResponse response) throws IOException
		{
			Header header = response.getFirstHeader(FileProtocolConstant.MD5_HEADER.getValue());
			String md5 = header == null ? null : header.getValue();
			if (!hasText(md5)) return;
			String localMd5;
			if (protocol.getTmpFile() == null)//
			{
				localMd5 = SecurityUtil.hash(protocol.getBinFile(), HashType.MD5, true);
				protocol.getBinFile().reset();// 重置读取顺序
			}
			else
			{
				localMd5 = SecurityUtil.hash(protocol.getTmpFile(), HashType.MD5, true);
			}
			logger.debug("response remoteMd5={}\t\tlocalMd5={}", md5, localMd5);
			if (!md5.equalsIgnoreCase(localMd5))
				throw new IOException(toLogString("收到内容的MD5校验不通过,远程MD5({}),本地校验MD5({})", md5, localMd5));
		}
	}

}
