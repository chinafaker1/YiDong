/*
 * Date: 2011-8-18
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager;

import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.MethodInvokingRunnable;
import org.springframework.util.Assert;
import org.springframework.util.ErrorHandler;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.ReflectionUtils.MethodCallback;

import cn.com.taiji.common.manager.quartz.DBExclusiveTask;
import cn.com.taiji.common.manager.quartz.ExclusiveTask;
import cn.com.taiji.common.manager.quartz.FileExclusiveTask;
import cn.com.taiji.common.manager.quartz.MemcachedExclusiveTask;
import cn.com.taiji.common.manager.quartz.RunnableProxy;
import cn.com.taiji.common.model.annotation.StartScheduler;
import cn.com.taiji.common.model.annotation.StopScheduler;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-8-18 下午3:29:50<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link StartScheduler} {@link StopScheduler}
 * @see {@link ExclusiveTask} {@link MemcachedExclusiveTask} {@link DBExclusiveTask}
 *      {@link FileExclusiveTask}
 */
public final class CronTaskRunner extends AbstractManager implements LifecycleService
{
	private AtomicBoolean running = new AtomicBoolean(false);
	private ThreadPoolTaskScheduler scheduler;
	private final Runnable task;
	private final Runnable realTask;// 有些任务会被重新封装，比如ExclusiveTask等
	private final String name;
	private final CronTrigger cron;
	private final boolean stopImmediate;
	private final boolean invokeTaskAfterStart;// 是否在scheduler启动后立即调用一次任务
	private volatile ErrorHandler errorHandler;

	public CronTaskRunner(Runnable task, boolean stopImmediate, String cron)
	{
		this(task, null, stopImmediate, cron);
	}

	public CronTaskRunner(Runnable task, String name, boolean stopImmediate, String cron)
	{
		this(task, name, stopImmediate, cron, false);
	}

	public CronTaskRunner(Runnable task, String name, boolean stopImmediate, String cron, boolean invokeTaskAfterStart)
	{
		AssertUtil.notNull(task);
		this.task = task;
		this.realTask = (task instanceof RunnableProxy) ? ((RunnableProxy) task).getTask() : task;
		if (hasText(name))
			this.name = name;
		else
			this.name = (task instanceof RunnableProxy) ? ((RunnableProxy) task).getTaskName() : task.toString();
		this.stopImmediate = stopImmediate;
		this.cron = new CronTrigger(cron);
		this.invokeTaskAfterStart = invokeTaskAfterStart;
		if (task instanceof RunnableProxy) ((RunnableProxy) task).setTaskRunner(this);
	}

	public Runnable getTask()
	{
		return task;
	}

	public boolean isRunning()
	{
		return running.get();
	}

	private void invokeStartScheduler(final boolean beforeStart)
	{
		ReflectionUtils.doWithMethods(realTask.getClass(), new MethodCallback() {
			public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException
			{
				StartScheduler annotation = AnnotationUtils.getAnnotation(method, StartScheduler.class);
				if (annotation == null || beforeStart != annotation.beforeStart()) return;
				methodInvoke(method, "@StartScheduler");
			}
		});
	}

	private void invokeStopScheduler(final boolean beforeStop)
	{
		ReflectionUtils.doWithMethods(realTask.getClass(), new MethodCallback() {
			public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException
			{
				StopScheduler annotation = AnnotationUtils.getAnnotation(method, StopScheduler.class);
				if (annotation == null || beforeStop != annotation.beforeStop()) return;
				methodInvoke(method, "@StopScheduler");
			}
		});
	}

	private void methodInvoke(Method method, String msg)
	{
		Assert.isTrue(void.class.equals(method.getReturnType()), "Only void-returning methods may be annotated with "
				+ msg);
		Assert.isTrue(method.getParameterTypes().length == 0, "Only no-arg methods may be annotated with " + msg);
		MethodInvokingRunnable runnable = new MethodInvokingRunnable();
		runnable.setTargetObject(realTask);
		runnable.setTargetMethod(method.getName());
		runnable.setArguments(new Object[0]);
		try
		{
			runnable.prepare();
			runnable.invoke();
		}
		catch (Exception ex)
		{
			throw new IllegalStateException("failed to prepare/invoke task", ex);
		}
	}

	private void initTask()
	{
		if (task instanceof RunnableProxy)
		{
			((RunnableProxy) task).init();
		}
	}

	private void invokeNow()
	{
		ExecutorService executor = Executors.newSingleThreadExecutor();
		try
		{
			executor.execute(task);
		}
		finally
		{
			executor.shutdown();
		}
		logger.info("调度线程({})启动后立即调用任务成功.", name);
	}

	public synchronized void start() throws Exception
	{
		if (running.get())
		{
			logger.info("调度线程({})已经启动.", name);
			return;
		}
		try
		{
			invokeStartScheduler(true);
			initScheduler();
			scheduler.schedule(task, cron);
			logger.info("开启调度线程({})成功", name);
			running.set(true);
			invokeStartScheduler(false);
			initTask();
			// 启用新线程立即调用一次Task
			if (invokeTaskAfterStart) invokeNow();
		}
		finally
		{
			if (running.get() || scheduler == null) return;
			try
			{
				scheduler.shutdown();
				logger.error("由于调用@StartScheduler标注的方法失败,停止调度线程({})", name);
			}
			finally
			{
				scheduler = null;
			}
		}
	}

	public synchronized void stop()
	{
		if (scheduler == null) return;
		try
		{
			invokeStopScheduler(true);
			scheduler.shutdown();
			logger.info("停止调度线程({})成功", name);
			invokeStopScheduler(false);
		}
		finally
		{
			scheduler = null;
			running.set(false);
		}
	}

	public String getName()
	{
		return name;
	}

	public CronTrigger getCron()
	{
		return cron;
	}

	public void setErrorHandler(ErrorHandler errorHandler)
	{
		this.errorHandler = errorHandler;
	}

	private void initScheduler()
	{
		scheduler = new ThreadPoolTaskScheduler();
		scheduler.setWaitForTasksToCompleteOnShutdown(!stopImmediate);
		scheduler.setPoolSize(1);
		scheduler.setBeanName(name);
		if (errorHandler != null) scheduler.setErrorHandler(errorHandler);
		scheduler.initialize();
	}

}
