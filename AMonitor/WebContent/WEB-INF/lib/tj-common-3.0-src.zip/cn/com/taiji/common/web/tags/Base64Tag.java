/*
 * Date: 2014年1月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web.tags;

import cn.com.taiji.common.pub.EncodeTool;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年1月12日 下午1:53:16<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class Base64Tag
{
	public static String base64(String value, String enc)
	{
		return EncodeTool.encodeBase64(value, enc);
	}
}
