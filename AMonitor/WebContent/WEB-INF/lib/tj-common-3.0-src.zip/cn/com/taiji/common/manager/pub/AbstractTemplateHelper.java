/*
 * Date: 2011-11-7
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import cn.com.taiji.common.model.pub.AbstractContentInfo;
import cn.com.taiji.common.pub.file.FileTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-11-7 下午2:23:55<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractTemplateHelper extends AbstractHelper
{
	protected static Resource getResource(AbstractContentInfo info)
	{
		return new DefaultResourceLoader().getResource(info.getTemplateUrl());
	}

	protected static String getFileName(AbstractContentInfo info)
	{
		return (hasText(info.getFileName())) ? info.getFileName() : FileTools.generateUUIDName(null);
	}

	protected static String getSavePath(AbstractContentInfo info)
	{
		return hasText(info.getSavePath()) ? info.getSavePath() : FileHelper.getTmpPath();
	}

}
