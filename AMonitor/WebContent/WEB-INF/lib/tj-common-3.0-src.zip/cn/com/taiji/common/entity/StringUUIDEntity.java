package cn.com.taiji.common.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 上午09:12:11
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class StringUUIDEntity extends BaseEntity
{
	protected String id;

	@Id
	@Column(name = "id", length = 32)
	public String getId()
	{
		if (id == null) id = UUID.randomUUID().toString().replace("-", "");
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof StringUUIDEntity)) return false;
		StringUUIDEntity other = (StringUUIDEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}
}
