/*
 * Date: 2015年5月15日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.file;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年5月15日 上午8:59:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class HandleFileProtocolEvent extends BaseModel
{
	private FileProtocolRequest request;
	private FileProtocolResponse response;
	private Calendar startTime;
	private long execTime;
	private HttpServletRequest httpRequest;

	public HttpServletRequest getHttpRequest()
	{
		return httpRequest;
	}

	public HandleFileProtocolEvent setHttpRequest(HttpServletRequest httpRequest)
	{
		this.httpRequest = httpRequest;
		return this;
	}

	public FileProtocolRequest getRequest()
	{
		return request;
	}

	public FileProtocolResponse getResponse()
	{
		return response;
	}

	public Calendar getStartTime()
	{
		return startTime;
	}

	public long getExecTime()
	{
		return execTime;
	}

	public void setRequest(FileProtocolRequest request)
	{
		this.request = request;
	}

	public HandleFileProtocolEvent setResponse(FileProtocolResponse response)
	{
		this.response = response;
		return this;
	}

	public void setStartTime(Calendar startTime)
	{
		this.startTime = startTime;
	}

	public HandleFileProtocolEvent setExecTime(long execTime)
	{
		this.execTime = execTime;
		return this;
	}

	public static HandleFileProtocolEvent newInstance(FileProtocolRequest request, HttpServletRequest httpRequest)
	{
		HandleFileProtocolEvent rs = new HandleFileProtocolEvent();
		rs.setStartTime(Calendar.getInstance());
		rs.setRequest(request);
		rs.setHttpRequest(httpRequest);
		return rs;
	}
}
