/*
 * Date: 2013-3-8
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.util.EntityUtils;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-3-8 上午10:32:32<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class Response2StringHandler extends AbstractResponseHandler implements HttpResponseHandler<String>
{
	private final String defaultResEncoding;

	public Response2StringHandler(String defaultResEncoding)
	{
		this.defaultResEncoding = defaultResEncoding;
	}

	@Override
	public String handle(HttpResponse response) throws IOException
	{
		HttpEntity entity = response.getEntity();
		if (entity == null)
		{
			logger.info("Http response's entity is null.");
			return "";
		}
		StatusLine sl = response.getStatusLine();
		int code = sl.getStatusCode();
		boolean gzip = isContentGziped(response);
		HttpEntity resEntity = gzip ? new GzipDecompressingEntity(entity) : entity;
		String res = EntityUtils.toString(resEntity, defaultResEncoding);
		int rawLen = res == null ? 0 : res.length();
		logger.debug("response entity length:{}", rawLen);
		if (code >= 400) throw new IOException(toLogString("Request Error:{}\n{}", sl, res));
		return res;
	}

}
