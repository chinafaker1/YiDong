package cn.com.taiji.common.pub;

import java.util.Collection;
import java.util.Map;

import org.springframework.util.Assert;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:21:58
 * @since 1.0
 * @version 1.1
 */
public abstract class AssertUtil extends Assert
{
	/**
	 * 确认每个元素都必须有值，<BR>
	 * 如果是字符串，必需hasText<BR>
	 * 如果是Collection或者Map必需notEmpty
	 * 
	 * @param objs
	 */
	public static void allElementsHasValue(Object... objs)
	{
		if (objs == null) return;
		int i = 1;
		for (Object obj : objs)
		{
			if (obj == null) throw new IllegalArgumentException("第" + i + "个元素不能为null");
			if (obj instanceof Collection<?> && CollectionTools.isEmpty((Collection<?>) obj))
				throw new IllegalArgumentException("第" + i + "个Collection元素不能为empty");
			if (obj instanceof Map<?, ?> && CollectionTools.isEmpty((Map<?, ?>) obj))
				throw new IllegalArgumentException("第" + i + "个Map元素不能为empty");
			if (obj instanceof CharSequence && !StringTools.hasText((CharSequence) obj))
				throw new IllegalArgumentException("第" + i + "个字符串元素不能为空");
			i++;
		}
	}

	public static void has2Elements(Object[] arrays)
	{
		has2Elements(arrays, "arrays must has 2 elements.");
	}

	public static void has2Elements(Object[] arrays, String message)
	{
		if (arrays == null || arrays.length != 2) throw new IllegalArgumentException(message);
	}

	public static void hasNElements(int n, Object[] arrays)
	{
		hasNElements(n, arrays, "arrays must has " + n + " elements.");
	}

	public static void hasNElements(int n, Object[] arrays, String message)
	{
		if (arrays == null || arrays.length != n) throw new IllegalArgumentException(message);
	}

	public static void hasNBytes(int n, byte[] bytes)
	{
		hasNBytes(n, bytes, "bytes must has " + n + " byte.");
	}

	public static void hasNBytes(int n, byte[] bytes, String message)
	{
		if (bytes == null || bytes.length != n) throw new IllegalArgumentException(message);
	}

}
