package cn.com.taiji.common.manager;

import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.util.ErrorHandler;

import cn.com.taiji.common.pub.AssertUtil;


/**
 * cron方式启动器的抽象类，如果想使用组合的方式来启动cron启动器，请参见
 * {@link CronTaskRunner}
 * 
 * @author Peream <br>
 *         Create Time：2010-10-26 下午01:02:32<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractCronScheduler extends AbstractManager implements LifecycleService, Runnable
{
	private AtomicBoolean running = new AtomicBoolean(false);
	private ThreadPoolTaskScheduler scheduler;
	private final String beanName;
	private final CronTrigger cron;
	private final boolean stopImmediate;
	private volatile ErrorHandler errorHandler;

	/**
	 * 
	 * @param beanName
	 *            该调度线程的名字
	 * @param cron
	 *            cron表达式
	 */
	protected AbstractCronScheduler(String beanName, String cron)
	{
		this(beanName, true, cron);
	}

	protected AbstractCronScheduler(String beanName, boolean stopImmediate, String cron)
	{
		AssertUtil.notNull(beanName);
		this.beanName = beanName;
		this.stopImmediate = stopImmediate;
		this.cron = new CronTrigger(cron);
	}

	public boolean isRunning()
	{
		return running.get();
	}

	public final synchronized void start() throws Exception
	{
		if (running.get())
		{
			logger.info("调度线程({})已经启动.", beanName);
			return;
		}
		initScheduler();
		running.set(true);
		scheduler.schedule(this, cron);
		afterStart();
		logger.info("开启调度线程({})成功", beanName);
	}

	/**
	 * 覆盖本方法实现调度线程启动前执行相关操作
	 */
	protected void afterStart()
	{

	}

	/**
	 * 覆盖本方法实现调度线程停止前执行相关操作
	 */
	protected void beforeStop()
	{

	}

	public final synchronized void stop()
	{
		if (scheduler == null) return;
		try
		{
			beforeStop();
			scheduler.shutdown();
			logger.info("停止调度线程({})成功", beanName);
		}
		finally
		{
			scheduler = null;
			running.set(false);
		}
	}

	public final void setErrorHandler(ErrorHandler errorHandler)
	{
		this.errorHandler = errorHandler;
	}

	private void initScheduler()
	{
		scheduler = new ThreadPoolTaskScheduler();
		scheduler.setWaitForTasksToCompleteOnShutdown(!stopImmediate);
		scheduler.setPoolSize(1);
		scheduler.setBeanName(beanName);
		if (errorHandler != null) scheduler.setErrorHandler(errorHandler);
		scheduler.initialize();
	}
}
