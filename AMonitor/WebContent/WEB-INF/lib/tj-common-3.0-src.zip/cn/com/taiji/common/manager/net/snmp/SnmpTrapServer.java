package cn.com.taiji.common.manager.net.snmp;

import java.io.IOException;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-10 下午05:44:19
 * @since 1.0
 * @version 1.0
 */
public interface SnmpTrapServer
{
	/**
	 * 启动SNMP的Trap接收Server
	 * 
	 * @throws IOException
	 */
	public void start() throws IOException;

	/**
	 * Server是否在运行
	 * 
	 * @return
	 */
	public boolean isRunning();

	/**
	 * 停止SNMP的Trap接收Server
	 * 
	 * @throws IOException
	 */
	public void stop() throws IOException;
}
