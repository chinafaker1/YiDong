/*
 * Date: 2012-6-14
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.json;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.com.taiji.common.entity.BaseEntity;
import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.model.dao.Pagination;
import cn.com.taiji.common.pub.json.JsonTools;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-6-14 下午1:20:49<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractProtocol extends BaseModel
{
	protected final String type;

	protected AbstractProtocol(String type)
	{
		this.type = type;
	}

	@JsonIgnore
	public String getType()
	{
		return type;
	}

	public final JsonProtocol toJsonProtocol()
	{
		return new JsonProtocol(type, this.toJson());
	}

	protected <E extends BaseEntity> Pagination extractPagn(String json, Class<E> resultEleClass)
	{
		try
		{
			return JsonTools.json2Pagn(json, resultEleClass);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return Pagination.emptyInstance();
		}
	}

	protected <E extends BaseEntity> List<E> extractList(String json, Class<E> eleClazz)
	{
		try
		{
			return JsonTools.json2List(json, eleClazz);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return new ArrayList<E>();
		}
	}

	protected <K, V> Map<K, V> extractMap(String json, Class<K> keyClass, Class<V> valueClass)
	{
		try
		{
			return JsonTools.json2Map(json, keyClass, valueClass);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return new HashMap<K, V>();
		}
	}

	public static <T extends AbstractProtocol> T newInstance(Class<T> clazz, String jsonStr)
	{
		return fromJson(jsonStr, clazz);
	}
}
