/*
 * Date: 2014年8月19日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub.handler;


/**
 * 
 * @author Peream <br>
 *         Create Time：2014年8月19日 上午9:25:23<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface CmdEcho2ResultHandler<T> 
{
	public T getResult(String str);
}
