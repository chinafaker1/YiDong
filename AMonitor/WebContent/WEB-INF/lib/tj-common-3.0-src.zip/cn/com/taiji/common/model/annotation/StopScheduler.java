/*
 * Date: 2011-8-18
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import cn.com.taiji.common.manager.CronTaskRunner;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-8-18 上午9:04:54<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link CronTaskRunner}
 * @see {@link StartScheduler}
 */
@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface StopScheduler
{
	boolean beforeStop() default true;
}
