package cn.com.taiji.common.model.pub;

import cn.com.taiji.common.model.BaseModel;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-7-25 下午04:31:03
 * @since 1.0
 * @Version 1.0
 */
public class MyEth extends BaseModel
{
	private String name;

	private String ip;

	public MyEth()
	{
		super();
	}

	public MyEth(String name, String ip)
	{
		super();
		this.name = name;
		this.ip = ip;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
