package cn.com.taiji.common.pub.file.helper;

import java.io.File;
import java.io.Serializable;
import java.util.Comparator;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-1 上午10:07:26
 * @since 1.0
 * @version 1.0
 */
public class FileNameComparator implements Comparator<File>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8505046298970687401L;
	private boolean desc;

	public FileNameComparator()
	{
		this.desc = false;
	}

	public FileNameComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(File o1, File o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null || o1.getName() == null) return desc ? 1 : -1;
		if (o2 == null || o2.getName() == null) return desc ? -1 : 1;
		if (desc) return o2.getName().compareToIgnoreCase(o1.getName());
		return o1.getName().compareToIgnoreCase(o2.getName());
	}
}
