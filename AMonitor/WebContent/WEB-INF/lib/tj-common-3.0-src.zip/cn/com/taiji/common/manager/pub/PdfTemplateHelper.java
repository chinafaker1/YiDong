/*
 * Date: 2011-6-15
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.pub;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.core.io.Resource;
import org.w3c.dom.Document;
import org.xhtmlrenderer.pdf.ITextFontResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import cn.com.taiji.common.model.pub.PdfContentInfo;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.CollectionTools;

import com.lowagie.text.pdf.BaseFont;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.Template;
import freemarker.template.Version;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-6-15 下午03:51:29<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class PdfTemplateHelper extends AbstractTemplateHelper
{
	public static File generatePdf(PdfContentInfo info) throws Exception
	{
		AssertUtil.notNull(info);
		File file = new File(getSavePath(info) + "/" + getFileName(info));
		// 文件存在，不重新生成，直接返回
		if (!info.isAlwaysNew() && file.exists()) return file;
		Resource resource = getResource(info);
		Configuration cfg = getCfg(info.getTemplateEncoding(), resource.getFile());
		Template t = cfg.getTemplate(resource.getFile().getName(), info.getTemplateEncoding());
		t.setOutputEncoding("UTF-8");
		StringWriter out = new StringWriter();
		t.process(info.getContents(), out);
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = builder.parse(new ByteArrayInputStream(out.toString().getBytes("UTF-8")));
		ITextRenderer renderer = new ITextRenderer();
		// 解决中文支持问题
		if (!CollectionTools.isEmpty(info.getFonts()))
		{
			ITextFontResolver fontResolver = renderer.getFontResolver();
			for (String fontPath : info.getFonts())
			{
				fontResolver.addFont(fontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			}
		}
		renderer.setDocument(doc, null);
		FileOutputStream output = new FileOutputStream(file);
		try
		{
			renderer.layout();
			renderer.createPDF(output);
		}
		finally
		{
			closeQuietly(output);
		}
		return file;
	}

	private static Configuration getCfg(String templateEncoding, File templateFile) throws IOException
	{
		Version version = Configuration.VERSION_2_3_23;
		Configuration cfg = new Configuration(version);
		cfg.setDirectoryForTemplateLoading(FileHelper.getDirectoryFile(templateFile));
		cfg.setClassicCompatible(true);// 空值默认转换成空字符串""
		cfg.setTemplateUpdateDelayMilliseconds(10000L);
		cfg.setObjectWrapper(new DefaultObjectWrapperBuilder(version).build());
		cfg.setDefaultEncoding(templateEncoding);
		cfg.setOutputEncoding("UTF-8");
		cfg.setLocale(Locale.CHINA);
		return cfg;
	}
}
