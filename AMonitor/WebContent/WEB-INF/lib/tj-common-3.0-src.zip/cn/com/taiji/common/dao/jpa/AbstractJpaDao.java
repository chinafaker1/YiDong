/*
 * Date: 2011-12-16
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.dao.jpa;

import java.io.Serializable;

import cn.com.taiji.common.dao.AbstractDao;
import cn.com.taiji.common.entity.BaseEntity;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-16 下午4:05:21<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface AbstractJpaDao<E extends BaseEntity> extends AbstractDao<E>
{
	/**
	 * 保存当前实体
	 * 
	 * @param entity
	 */
	public void persist(E entity);

	/**
	 * 保存实体，不执行flush
	 * 
	 * @param entity
	 */
	public void persistOnly(E entity);

	/**
	 * 
	 * @param entity
	 * @see {@link #saveOrUpdate(BaseEntity)}
	 */
	public void merge(E entity);

	/**
	 * 不执行flush
	 * 
	 * @param entity
	 * @see {@link #saveOrUpdate(BaseEntity)}
	 */
	public void mergeOnly(E entity);

	/**
	 * 删除一个实体
	 * 
	 * @param entity
	 * @see {@link #delete(BaseEntity)}
	 */
	public void remove(E entity);

	/**
	 * 删除一个实体
	 * 
	 * @param entity
	 * @see {@link #delete(BaseEntity)}
	 */
	public void removeOnly(E entity);

	public void deleteOnly(E entity);

	public void updateOnly(E obj);

	/**
	 * JPA的保存没有返回值
	 * 
	 * @param entity
	 *            待保存的实体
	 * @see {@link #persist(BaseEntity)}
	 */
	@Deprecated
	public Serializable save(E entity);
}
