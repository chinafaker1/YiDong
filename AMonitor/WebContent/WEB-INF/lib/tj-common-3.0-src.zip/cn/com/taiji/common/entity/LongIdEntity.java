package cn.com.taiji.common.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 上午09:00:25
 * @since 1.0
 * @version 1.0
 */
@MappedSuperclass
public abstract class LongIdEntity extends BaseEntity
{
	protected long id;

	@Id
	@Column(name = "id")
	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof LongIdEntity)) return false;
		LongIdEntity other = (LongIdEntity) obj;
		return super.equals(id, other.getId());
	}

	@Override
	public int hashCode()
	{
		return super.hashCode(id);
	}

}
