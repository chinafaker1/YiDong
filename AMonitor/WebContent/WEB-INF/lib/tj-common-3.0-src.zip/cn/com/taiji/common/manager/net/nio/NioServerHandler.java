package cn.com.taiji.common.manager.net.nio;

import org.xsocket.connection.IConnectHandler;
import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.IDisconnectHandler;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-15 下午02:02:31
 * @since 1.0
 * @version 1.0
 */
public interface NioServerHandler extends IDataHandler, IConnectHandler, IDisconnectHandler
{
	
}
