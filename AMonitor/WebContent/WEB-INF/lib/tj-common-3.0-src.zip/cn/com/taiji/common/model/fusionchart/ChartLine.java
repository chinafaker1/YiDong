package cn.com.taiji.common.model.fusionchart;

import java.util.HashMap;
import java.util.Map;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.StringTools;

public class ChartLine extends BaseModel
{
	private String startValue = "0";
	private String endValue;
	private String color;
	private boolean isTrendZone = false;
	private boolean isDashed = true;
	private boolean isValueOnRight = true;
	private String tickness;
	private String displayValue;

	public String getStartValue()
	{
		return startValue;
	}

	public ChartLine setStartValue(String startValue)
	{
		this.startValue = startValue;
		return this;
	}

	public String getEndValue()
	{
		return endValue;
	}

	public ChartLine setEndValue(String endValue)
	{
		this.endValue = endValue;
		return this;
	}

	public String getColor()
	{
		return color;
	}

	public ChartLine setColor(String color)
	{
		this.color = color;
		return this;
	}

	public boolean isTrendZone()
	{
		return isTrendZone;
	}

	public ChartLine setTrendZone(boolean isTrendZone)
	{
		this.isTrendZone = isTrendZone;
		return this;
	}

	public boolean isDashed()
	{
		return isDashed;
	}

	public ChartLine setDashed(boolean isDashed)
	{
		this.isDashed = isDashed;
		return this;
	}

	public boolean isValueOnRight()
	{
		return isValueOnRight;
	}

	public ChartLine setValueOnRight(boolean isValueOnRight)
	{
		this.isValueOnRight = isValueOnRight;
		return this;
	}

	public String getTickness()
	{
		return tickness;
	}

	public ChartLine setTickness(String tickness)
	{
		this.tickness = tickness;
		return this;
	}

	public String getDisplayValue()
	{
		return displayValue;
	}

	public ChartLine setDisplayValue(String displayValue)
	{
		this.displayValue = displayValue;
		return this;
	}

	public static ChartLine newInstance(String startValue, String color, String displayValue)
	{
		ChartLine line = new ChartLine();
		line.setColor(color).setDisplayValue(displayValue).setStartValue(startValue);
		return line;
	}

	public Map<String, String> toLineMap()
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("startValue", startValue);
		if (StringTools.hasText(startValue)) map.put("endValue", endValue);
		if (StringTools.hasText(color)) map.put("color", color);
		if (isTrendZone)
		{
			map.put("isTrendZone", "1");
		}
		else
		{
			map.put("isTrendZone", "0");
		}

		if (isDashed)
		{
			map.put("dashed", "1");
		}
		else
		{
			map.put("dashed", "0");
		}

		if (isValueOnRight)
		{
			map.put("valueOnRight", "1");
		}
		else
		{
			map.put("valueOnRight", "0");
		}
		if (StringTools.hasText(tickness)) map.put("tickness", tickness);
		if (StringTools.hasText(displayValue)) map.put("displayvalue", displayValue);
		return map;
	}

}
