/*
 * Date: 2012-2-14
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.ws;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.namespace.QName;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-2-14 下午4:58:04<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public enum WsClientBuilder
{
	INSTANCE;
	private Map<String, Object> clients = new ConcurrentHashMap<String, Object>();

	/**
	 * 移除指定wsdlURL的Webservice客户端
	 * 
	 * @param clazz
	 * @param wsdlURL
	 * @return
	 */
	public <T> T removeClient(Class<T> clazz, String wsdlURL)
	{
		return clazz.cast(clients.remove(wsdlURL));
	}

	/**
	 * 
	 * @param wsdlURL
	 * @param clazz
	 * @param namespaceURI
	 *            wsdl文件中的targetNamespace
	 * @param serviceName
	 *            wsdl文件中的service name
	 * @param portName
	 *            wsdl文件中的port name
	 * @return
	 */
	public <T> T getClient(String wsdlURL, Class<T> clazz, String namespaceURI, String serviceName, String portName)
	{
		T client = clazz.cast(clients.get(wsdlURL));
		if (client != null) return client;
		synchronized (this)
		{
			try
			{
				QName sName = new QName(namespaceURI, serviceName);
				javax.xml.ws.Service service = javax.xml.ws.Service.create(new URL(wsdlURL), sName);
				QName pName = new QName(namespaceURI, portName);
				client = service.getPort(pName, clazz);
				clients.put(wsdlURL, client);
				return client;
			}
			catch (IOException e)
			{
				throw new RuntimeException(e);
			}
		}

	}
}
