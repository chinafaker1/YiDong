package cn.com.taiji.common.model.net;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-17 下午03:13:09
 * @since 1.0
 * @version 1.0
 */
public class ExecTarget extends BaseTarget
{
	private String user;
	private String pass;
	private int timeout;// 命令执行超时时间（毫秒）,>0时有效

	public String getUser()
	{
		return user;
	}

	public void setUser(String user)
	{
		this.user = user;
	}

	public String getPass()
	{
		return pass;
	}

	public void setPass(String pass)
	{
		this.pass = pass;
	}

	public int getTimeout()
	{
		return timeout;
	}

	public void setTimeout(int timeout)
	{
		this.timeout = timeout;
	}

}
