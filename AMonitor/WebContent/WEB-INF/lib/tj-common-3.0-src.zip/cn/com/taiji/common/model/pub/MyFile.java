package cn.com.taiji.common.model.pub;

import java.io.File;
import java.util.Calendar;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.pub.NumberTools;

/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-7-25 下午04:31:13
 * @since 1.0
 * @Version 1.0
 */
public class MyFile extends BaseModel
{
	private String name;
	private String path;
	// 相对工程目录
	private String facePath;
	// 33Bytes 或 22KB 或 44MB.
	private String size;
	private Calendar modifyTime;
	private boolean directory = false;

	public Calendar getModifyTime()
	{
		return modifyTime;
	}

	public void setModifyTime(Calendar modifyTime)
	{
		this.modifyTime = modifyTime;
	}

	public String getPath()
	{
		return path;
	}

	public void setPath(String path)
	{
		this.path = path;
	}

	public String getSize()
	{
		return size;
	}

	public void setSize(String size)
	{
		this.size = size;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public boolean isDirectory()
	{
		return directory;
	}

	public void setDirectory(boolean directory)
	{
		this.directory = directory;
	}

	public String getFacePath()
	{
		return facePath;
	}

	public void setFacePath(String facePath)
	{
		this.facePath = facePath;
	}

	public static MyFile newInstance(File file)
	{
		if (file == null) return null;
		MyFile rs = new MyFile();
		Calendar time = Calendar.getInstance();
		time.setTimeInMillis(file.lastModified());
		rs.setModifyTime(time);
		rs.setDirectory(file.isDirectory());
		rs.setName(file.getName());
		rs.setPath(file.getAbsolutePath());
		rs.setSize(NumberTools.bytesAsHumanStr(file.length()));
		return rs;
	}
}
