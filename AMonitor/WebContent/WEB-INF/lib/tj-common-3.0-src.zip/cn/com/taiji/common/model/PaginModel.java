package cn.com.taiji.common.model;

import cn.com.taiji.common.model.finals.SysFinals;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-13 下午05:46:48
 * @since 1.0
 * @version 1.0
 */
public class PaginModel extends BaseModel
{
	private int pageNo = SysFinals.DEFAULT_PAGE_NUM;
	private int pageSize = SysFinals.DEFAULT_PAGE_SIZE;

	public PaginModel()
	{

	}

	public PaginModel(int pageSize)
	{
		this.pageSize = pageSize;
	}

	public int getPageNo()
	{
		return pageNo;
	}

	public void setPageNo(int pageNo)
	{
		this.pageNo = pageNo;
	}

	public int getPageSize()
	{
		return pageSize;
	}

	public void setPageSize(int pageSize)
	{
		this.pageSize = pageSize;
	}

}
