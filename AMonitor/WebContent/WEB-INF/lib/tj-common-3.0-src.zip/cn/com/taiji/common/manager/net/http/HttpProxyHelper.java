/*
 * Date: 2011-7-22
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.ContentType;
import org.apache.http.protocol.HTTP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.manager.pub.AbstractHttpHelper;

/**
 * 
 * @author Peream <br>
 *         Create Time：2011-7-22 下午3:24:57<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class HttpProxyHelper extends AbstractHttpHelper
{
	protected static Logger logger = LoggerFactory.getLogger(HttpProxyHelper.class);

	/**
	 * 代理GET方法请求
	 * 
	 * @param uri
	 *            真正请求的URI
	 * @param request
	 * @param response
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public static boolean proxyGet(String uri, HttpServletRequest request, HttpServletResponse response)
			throws URISyntaxException, IOException
	{
		return proxyGet(uri, request, DEFAULT_CONN_TIMEOUT, response, -1);
	}

	public static boolean proxyGet(String uri, HttpServletRequest request, int connTimeout,
			HttpServletResponse response, int soTimeout) throws URISyntaxException, IOException
	{
		HttpGet httpGet = new HttpGet(getURI(uri, request));
		wrapRequest(httpGet, request);
		return wrapResponse(httpGet, connTimeout, response, soTimeout);
	}

	/**
	 * 代理POST方法请求
	 * 
	 * @param uri
	 *            真正请求的URI
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static boolean proxyPost(String uri, HttpServletRequest request, HttpServletResponse response)
			throws IOException
	{
		return proxyPost(uri, request, DEFAULT_CONN_TIMEOUT, response, -1);
	}

	public static boolean proxyPost(String uri, HttpServletRequest request, int connTimeout,
			HttpServletResponse response, int soTimeout) throws IOException
	{
		HttpPost post = createPost(uri, request);
		return wrapResponse(post, connTimeout, response, soTimeout);
	}

	private static HttpPost createPost(String uri, HttpServletRequest request) throws UnsupportedEncodingException
	{
		String encoding = request.getCharacterEncoding();
		if (!hasText(encoding)) encoding = DEFAULT_ENCODING;
		List<NameValuePair> params = params2List(request);
		HttpPost post = new HttpPost(uri);
		UrlEncodedFormEntity reqEntity = new UrlEncodedFormEntity(params, encoding);
		post.setEntity(reqEntity);
		// gzip
		String headEncoding = request.getHeader("Accept-Encoding");
		if (hasText(headEncoding)) post.setHeader("Accept-Encoding", headEncoding);
		return post;
	}

	private static boolean wrapResponse(HttpUriRequest request, int connTimeout, final HttpServletResponse response,
			int soTimeout) throws IOException
	{
		return httpRequest(request, connTimeout, new HttpResponseHandler<Boolean>() {
			@Override
			public Boolean handle(HttpResponse httpResponse) throws IOException
			{
				StatusLine sl = httpResponse.getStatusLine();
				response.setStatus(sl.getStatusCode());
				// content
				HttpEntity entity = httpResponse.getEntity();
				if (entity == null) return true;
				boolean gziped = isContentGziped(httpResponse);
				long contentLength = entity.getContentLength();
				logger.debug("proxy wrap response,entity gziped({}) length({})\tstatus line:{}", new Object[] { gziped,
						contentLength, sl });
				String encoding = ContentType.getOrDefault(entity).getCharset().name();
				if (!hasText(encoding)) encoding = DEFAULT_ENCODING;
				response.setCharacterEncoding(encoding);
				if (gziped) response.setHeader(HTTP.CONTENT_ENCODING, "gzip");
				if (contentLength > 0) response.setContentLength(Long.valueOf(contentLength).intValue());
				String contentType = httpResponse.getFirstHeader(HTTP.CONTENT_TYPE).getValue();
				if (hasText(contentType)) response.setContentType(contentType);
				InputStream in = entity.getContent();
				if (in == null) return true;
				OutputStream out = response.getOutputStream();
				try
				{
					byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
					int bytesRead = -1;
					while ((bytesRead = in.read(buffer)) != -1)
					{
						out.write(buffer, 0, bytesRead);
					}
					out.flush();
				}
				finally
				{
					closeQuietly(in);
				}
				return true;
			}
		}, soTimeout);
	}

	private static void wrapRequest(HttpUriRequest uriRequest, HttpServletRequest request)
	{
		// headers
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements())
		{
			String name = headerNames.nextElement();
			uriRequest.setHeader(name, request.getHeader(name));
		}
	}
}
