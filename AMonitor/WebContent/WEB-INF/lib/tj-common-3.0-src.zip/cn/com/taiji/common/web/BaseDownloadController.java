package cn.com.taiji.common.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.manager.net.http.HttpMimeResponseHelper;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 下载专用controller
 * 
 * @author Peream <br>
 *         Create Time：2009-6-30 上午11:45:40<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.1
 * @version 1.1
 * @see {@link HttpMimeResponseHelper}
 */
public abstract class BaseDownloadController extends BaseController
{
	protected void doShowPic(HttpServletResponse response, File file) throws IOException
	{
		AssertUtil.notNull(file);
		FileInputStream in = new FileInputStream(file);
		doShowPic(response, in);
	}

	protected void doShowPic(HttpServletResponse response, Blob blob) throws IOException, SQLException
	{
		AssertUtil.notNull(blob);
		doShowPic(response, blob.getBinaryStream());
	}

	protected void doShowPic(HttpServletResponse response, final InputStream in) throws IOException
	{
		HttpMimeResponseHelper.doShowPic(response, in);
	}

	protected void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final InputStream stream, String displayName) throws IOException
	{
		HttpMimeResponseHelper.doDownLoad(request, response, stream, displayName);
	}

	protected void doDownLoad(final HttpServletRequest request, final HttpServletResponse response,
			final String content, String displayName) throws IOException
	{
		HttpMimeResponseHelper.doDownLoad(request, response, content, displayName);
	}

	protected void doDownLoad(final HttpServletRequest request, final HttpServletResponse response, final File file,
			String displayName) throws IOException
	{
		HttpMimeResponseHelper.doDownLoad(request, response, file, displayName);
	}

}
