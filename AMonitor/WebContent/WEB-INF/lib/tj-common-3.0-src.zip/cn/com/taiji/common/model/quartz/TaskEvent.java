/*
 * Date: 2013年10月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import java.util.Calendar;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年10月12日 下午6:33:06<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public final class TaskEvent extends BaseModel
{
	private final Calendar beginTime;
	private final String taskName;
	private final boolean bySystem;
	private final String currentCron;
	private Calendar finishTime;

	public TaskEvent(Calendar beginTime, String taskName, boolean bySystem, String currentCron)
	{
		this.beginTime = beginTime;
		this.taskName = taskName;
		this.bySystem = bySystem;
		this.currentCron = currentCron;
	}

	public boolean isBySystem()
	{
		return bySystem;
	}

	public String getCurrentCron()
	{
		return currentCron;
	}

	public Calendar getBeginTime()
	{
		return beginTime;
	}

	public String getTaskName()
	{
		return taskName;
	}

	public Calendar getFinishTime()
	{
		return finishTime;
	}

	public void setFinishTime(Calendar finishTime)
	{
		this.finishTime = finishTime;
	}

}
