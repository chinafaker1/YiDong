/*
 * Date: 2012-1-30
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

import org.apache.http.Header;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-1-30 下午3:53:39<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface FileDownloadHandler<T>
{
	/**
	 * 文件下载的回调接口
	 * 
	 * @param is
	 *            返回的流信息
	 * @param fileName
	 *            文件名
	 * @param headers
	 *            HTTP Header
	 * @param uri
	 *            本次请求的
	 * @return 下载完成返回的信息
	 * @throws IOException
	 */
	public T handle(InputStream is, String fileName, Header[] headers, URI uri) throws IOException;
}
