/*
 * Date: 2014年5月14日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import cn.com.taiji.common.model.json.JsonProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2014年5月14日 上午11:18:13<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface HttpJsonCommHandleManager
{
	/**
	 * 处理JsonProtocol格式的请求
	 * @param protocol 请求
	 * @param request  
	 * @return 
	 * @throws IOException
	 */
	public JsonProtocol handleComm(final JsonProtocol protocol, final HttpServletRequest request) throws IOException;
}
