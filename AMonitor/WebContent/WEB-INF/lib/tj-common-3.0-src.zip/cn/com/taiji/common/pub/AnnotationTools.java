package cn.com.taiji.common.pub;

import org.springframework.core.annotation.AnnotationUtils;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-25 下午01:57:48
 * @since 1.0
 * @version 1.0
 */
public abstract class AnnotationTools extends AnnotationUtils
{

}
