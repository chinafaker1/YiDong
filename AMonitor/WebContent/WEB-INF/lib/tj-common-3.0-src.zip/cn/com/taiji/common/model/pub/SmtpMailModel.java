package cn.com.taiji.common.model.pub;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.com.taiji.common.model.BaseModel;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-11 下午02:00:37
 * @since 1.0
 * @version 1.0
 */
public class SmtpMailModel extends BaseModel
{
	private String mailServer;// 邮件服务器ex:smtp.163.com
	private int port = 25;// 端口
	private boolean stmpAuth = true;// smtp是否需要校验用户
	private String user;// 用户ex:peream@163.com
	private String pass;// 密码：

	private String from;//
	private String personal;// 发送人名字
	private String[] to;// 收件人
	private String[] cc;// 转发

	private String encoding = "UTF-8";// 邮件编码
	private String subject;// 标题
	private String text;
	private boolean html = true;// 是否html格式
	private List<File> attachs = new ArrayList<File>();

	public String getMailServer()
	{
		return mailServer;
	}

	public void setMailServer(String mailServer)
	{
		this.mailServer = mailServer;
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public boolean isStmpAuth()
	{
		return stmpAuth;
	}

	public void setStmpAuth(boolean stmpAuth)
	{
		this.stmpAuth = stmpAuth;
	}

	public String getUser()
	{
		return user;
	}

	public void setUser(String user)
	{
		this.user = user;
	}

	public String getPass()
	{
		return pass;
	}

	public void setPass(String pass)
	{
		this.pass = pass;
	}

	public String getFrom()
	{
		return from;
	}

	public void setFrom(String from)
	{
		this.from = from;
	}

	public String getPersonal()
	{
		return personal;
	}

	public void setPersonal(String personal)
	{
		this.personal = personal;
	}

	public String[] getTo()
	{
		return to;
	}

	public void setTo(String[] to)
	{
		this.to = to;
	}

	public String[] getCc()
	{
		return cc;
	}

	public void setCc(String[] cc)
	{
		this.cc = cc;
	}

	public String getEncoding()
	{
		return encoding;
	}

	public void setEncoding(String encoding)
	{
		this.encoding = encoding;
	}

	public String getSubject()
	{
		return subject;
	}

	public void setSubject(String subject)
	{
		this.subject = subject;
	}

	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}

	public boolean isHtml()
	{
		return html;
	}

	public void setHtml(boolean html)
	{
		this.html = html;
	}

	public List<File> getAttachs()
	{
		return attachs;
	}

	public void setAttachs(List<File> attachs)
	{
		this.attachs = attachs;
	}

}
