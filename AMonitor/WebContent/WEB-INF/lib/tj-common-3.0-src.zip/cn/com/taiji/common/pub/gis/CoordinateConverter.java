package cn.com.taiji.common.pub.gis;

import cn.com.taiji.common.model.Coordinate;

/**
 * @author Sunny mail:sunoke@126.com
 * 
 *         2008-4-4 下午04:46:52
 * @since 1.0
 * @version 1.1
 */
public class CoordinateConverter
{
	private static final double CEN_WD = 35;// 中点纬度
	private static final double CEN_JD = 105;// 中点经度
	private static final double CEN_X = 0;
	private static final double CEN_Y = 0;
	private static final double A1 = 6371000000.00;// 地球半径RADIUS
	private static final double PII = Math.PI / 180;
	// 2007年11月25日 add 墨卡托投影
	// 墨卡托投影正解公式：（B,L）→(X,Y)，标准纬度B0，原点纬度 0，原点经度L0
	private static final double B0 = 35 * PII;// 标准纬度B0 0
	private static final double L0 = 105 * PII;// 原点经度L0

	private static final double a = 6378140;// a -- 椭球体长半轴
	private static final double b = 6356755.2882;// b -- 椭球体短半轴
	// e 第一偏心率 e1=(1-(b/a)*(b/a)) 的开方
	private static final double e1 = Math.sqrt(1 - Math.pow((b / a), 2));
	// e’ 第二偏心率 e2= ((a/b)*(a/b)-1) 的开方
	private static final double e2 = Math.sqrt(Math.pow((a / b), 2) - 1);
	// private static final double mk = Nb0*Math.cos(B0);
	private static final double mk = Math.pow(a, 2) / b * Math.cos(B0)
			/ Math.sqrt(1 + Math.pow(e2 * Math.cos(B0), 2));

	private static final double k = (Math.log(Math.sin(25 * PII)) - Math.log(Math.sin(47 * PII)))
			/ (Math.log(Math.tan(30 / 2.00 * PII)));

	// 其中stanw1 30和stanw2 60为标准纬度 中国地区部分资料是 25 47
	// 中央经线1050000，原点纬度180000；比例尺分母：5000000

	/**
	 * 投影转换对外接口
	 * 
	 * @param latidude
	 *            纬度
	 * @param longitude
	 *            经度
	 */
	public static Coordinate convert(double latidude, double longitude, Projection projection)
	{
		switch (projection)
		{
		case MERCATOR:// 1、墨卡托投影
			return mkt2xy(latidude, longitude);
		case LAMBERT:// 2、兰伯特投影算法
			return lambert2xy(latidude, longitude);
		case LINEAR:// 3、Linear 经纬度线性投影
			return linear2xy(latidude, longitude);
		case STEREOGRAM_N:// 4、Stereogram projection 北半球极射赤面
			return stereogram_N2xy(latidude, longitude);
		case STEREOGRAM_S:// 5、南半球极射赤面
			return stereogram_S2xy(latidude, longitude);
		default:// 默认用兰伯特投影算法
			return lambert2xy(latidude, longitude);
		}
	}

	/**
	 * 经纬度分转换为小数度
	 * 
	 * @param fen
	 * @return
	 */
	public static double fen2Du(double fen)
	{
		double n = 5.0 / 3.0;
		int fenZ = (int) fen;
		double fenX = fen - fenZ;
		double fenN = fenX * n;
		double fenD = fenZ + fenN;
		return fenD;
	}

	/**
	 * 兰伯特投影算法
	 * 
	 * @param latitude
	 * @param longitude
	 * @return
	 */
	public static Coordinate lambert2xy(double latitude, double longitude)
	{
		double fai = latitude;
		double lamda = longitude;
		double a2 = 5000000;// 比例尺6000000
		// double a2 = 60000000;// 比例尺
		double xa = A1 / (2 * a2 * k);
		double a1 = 15 * PII;
		a1 = Math.tan(a1);
		a1 = Math.pow(a1, k);
		double l1 = xa / a1;
		a1 = (45.00 - fai / 2.00) * PII;
		a1 = Math.tan(a1);
		a1 = Math.pow(a1, k);
		double a3 = xa * Math.pow(Math.tan((45 - 30 / 2) * PII) / Math.tan(CEN_WD / 2.00 * PII), k);

		double xx = CEN_X + (l1 * a1 * Math.sin(k * (lamda - CEN_JD) * PII)) * 1.000;
		double yy = CEN_Y + (a3 - l1 * a1 * Math.cos(k * (lamda - CEN_JD) * PII)) * 1.0;
		// 符合svg坐标
		yy = 0 - yy;
		xx = xx + 530; // 中点坐标移动485
		yy = yy + 360; // 中点坐标移动 经测试420 300是中国地图合适的位置
		return new Coordinate(xx, yy);
	}

	// 墨卡托投影 转换公式 纬度 经度
	private static Coordinate mkt2xy(double latitude, double longitude)
	{
		// B -- 纬度，L -- 经度，单位弧度(RAD) B0=0时 mk=a 6378140 L0=0
		// Xn -- 纵直角坐标, Ye -- 横直角坐标，单位米(M)
		double scale = 6000;// 比例尺6000000
		double offsetx = 500;// 比例尺6000000
		double offsety = 1000;// 比例尺6000000
		// double scale = PII*mk;// 比例尺6000000
		// double scalex = 1;// 比例尺6000000
		double B = latitude * PII;
		double L = longitude * PII;
		// 纵坐标
		double Xn = mk
				* Math.log(Math.tan(Math.PI / 4 + B / 2)
						* Math.pow((1 - e1 * Math.sin(B)) / (1 + e1 * Math.sin(B)), e1 / 2))
				/ scale;
		// 横坐标
		double Ye = mk * (L - L0) / scale;
		return new Coordinate(offsetx + Ye, offsety - Xn);
	}

	// Linear 线性投影
	private static Coordinate linear2xy(double latitude, double longitude)
	{
		double scale_x = 20;// x方向比例尺15.5
		double scale_y = 20;// y方向比例尺19
		double offsetx = -1125;// x偏移 -1125
		double offsety = 1050;// y偏移 1050
		// 纵坐标
		double Xn = latitude * scale_y;
		// 横坐标
		double Ye = longitude * scale_x;
		return new Coordinate(offsetx + Ye, offsety - Xn);
	}

	/**
	 * 北半球极射赤面
	 * 
	 * @param latitude
	 *            纬度
	 * @param longitude
	 *            经度
	 * @return
	 */
	private static Coordinate stereogram_N2xy(double latitude, double longitude)
	{
		double lon = 105;// 标准经度
		double scale = 800;// 比例尺1000
		double offsetx = 500;// 比例尺6000000
		double offsety = 400;// 比例尺6000000

		double radianLat = Math.toRadians(latitude);// 纬度弧度
		double deltaLon = Math.toRadians(longitude - lon);// 经度弧度

		double k = scale * Math.cos(radianLat) / (1.0 + Math.sin(radianLat));
		double x = k * Math.sin(deltaLon);
		double y = -k * Math.cos(deltaLon);
		return new Coordinate(offsetx + x, offsety - y);
	}

	// 南半球极射赤面
	private static Coordinate stereogram_S2xy(double latitude, double longitude)
	{
		double lon = 0;// 标准经度
		double scale = 800;// 比例尺1000
		double offsetx = 500;//
		double offsety = 400;//

		double radianLat = Math.toRadians(latitude);// 纬度弧度
		double deltaLon = Math.toRadians(longitude - lon);// 经度弧度
		double k = scale * Math.cos(radianLat) / (1.0 - Math.sin(radianLat));
		double x = k * Math.sin(deltaLon);
		double y = k * Math.cos(deltaLon);
		return new Coordinate(offsetx + x, offsety - y);
	}

	public static enum Projection
	{
		MERCATOR("墨卡托圆柱投影法") {},
		LAMBERT("兰伯特投影法") {},
		LINEAR("线性投影法") {},
		STEREOGRAM_N("北半球极射赤面投影法") {},
		STEREOGRAM_S("南半球半球极射赤面投影法") {};
		private String value;

		private Projection(String value)
		{
			this.value = value;
		}

		public String getValue()
		{
			return value;
		}
	}

}
