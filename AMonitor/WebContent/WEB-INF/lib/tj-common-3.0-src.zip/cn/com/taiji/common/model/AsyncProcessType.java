package cn.com.taiji.common.model;

public enum AsyncProcessType
{
	NOTE("提示") {},
	PROCESS("进行中") {},
	SUCCESS("成功") {},
	FAILED("失败") {},
	;
	private String value;

	public String getValue()
	{
		return value;
	}

	private AsyncProcessType(String value)
	{
		this.value = value;
	}

}
