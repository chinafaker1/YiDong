package cn.com.taiji.common.manager.net.snmp;

import java.io.UnsupportedEncodingException;

import org.snmp4j.smi.OctetString;

import cn.com.taiji.common.manager.net.AbstractParser;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午10:10:19
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractTrapParser extends AbstractParser implements
		SnmpTrapParser
{
	protected static String decodeOctetString(OctetString octetString,
			String charset) throws UnsupportedEncodingException
	{
		byte[] values = octetString.getValue();
		return new String(values, charset);
	}
}
