package cn.com.taiji.common.web.util;

import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.util.WebUtils;

import cn.com.taiji.common.model.finals.SysFinals;
import cn.com.taiji.common.pub.ObjectTools;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-8 下午12:48:15
 * @since 1.0
 * @version 1.0
 */
public abstract class WebTools extends WebUtils
{
	public static final String WEB_APP_ROOT_PATH_PARAM = "webAppRootPath";
	private static final String ROOT_CONTEXT = "/";
	private static String contextPath;

	/**
	 * 取得不包含context的uri,ex:/ad/index.do(/ad为context)则返回/index.do
	 * 
	 * @param request
	 * @return
	 */
	public static String getUri(HttpServletRequest request)
	{
		return getUri(request, false);
	}

	public static String getUri(HttpServletRequest request, boolean withParams)
	{
		if (contextPath == null) contextPath = "" + request.getContextPath();
		String uri = request.getRequestURI();
		if (!(contextPath.equals(ROOT_CONTEXT))) uri = uri.replaceFirst(contextPath, "");
		uri = uri.replaceAll(SysFinals.MULTI_SLASH, SysFinals.SLASH);
		if (!withParams) return uri;
		StringBuilder sb = new StringBuilder(uri).append("?");
		Map<String, String[]> params = request.getParameterMap();
		for (Entry<String, String[]> en : params.entrySet())
		{
			String[] values = en.getValue();
			if (ObjectTools.isEmpty(values)) continue;
			for (String value : values)
				sb.append(en.getKey()).append("=").append(value).append("&");
		}
		return sb.toString();
	}
}
