/*
 * Date: 2013年10月12日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import cn.com.taiji.common.model.PaginModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013年10月12日 上午10:57:34<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CronTaskQueryModel extends PaginModel
{
	private String taskName;
	private String type;
	private String info;

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getTaskName()
	{
		return taskName;
	}

	public String getInfo()
	{
		return info;
	}

	public void setTaskName(String taskName)
	{
		this.taskName = taskName;
	}

	public void setInfo(String info)
	{
		this.info = info;
	}

}
