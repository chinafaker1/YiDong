package cn.com.taiji.common.manager.net.snmp;

import java.io.IOException;

import cn.com.taiji.common.model.net.snmp.AlertTrap;
import cn.com.taiji.common.model.net.snmp.BaseSnmpTarget;
import cn.com.taiji.common.model.net.snmp.SnmpV3Target;
import cn.com.taiji.common.model.net.snmp.V1Trap;
import cn.com.taiji.common.model.net.snmp.V2Trap;
import cn.com.taiji.common.model.net.snmp.V3Trap;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:18:34
 * @since 1.0
 * @version 1.0
 */
public interface SnmpClient
{
	public void trapV1(V1Trap trap, BaseSnmpTarget target) throws IOException;

	public void trapV2(V2Trap trap, BaseSnmpTarget target) throws IOException;

	public void trapV3(V3Trap trap, SnmpV3Target target, int securityLevel) throws IOException;

	/**
	 * 发送请求给交换机以获取主机信息
	 * 
	 * @param target
	 *            交换机及请求的信息
	 * @throws IOException
	 */
	public void searchHost(BaseSnmpTarget target) throws IOException;

	/**
	 * 发送请求给阿尔卡特交换机以获取主机信息
	 * 
	 * @param target
	 *            交换机及请求的信息
	 * @throws IOException
	 */
	public void searchAlcatelSwitch(BaseSnmpTarget target) throws IOException;

	/**
	 * 将报警以Trap的形式发送出去
	 * 
	 * @param alertTrap
	 *            报警数据
	 * @param target
	 *            Trap接收方的信息及trap的版本等信息
	 * @throws IOException
	 */
	public void trapAlert(AlertTrap alertTrap, BaseSnmpTarget target) throws IOException;

	/**
	 * 将报警以Trap的形式发送出去
	 * 
	 * @param alertTrap
	 *            报警数据
	 * @param target
	 *            Trap接收方的信息及trap的版本等信息
	 * @throws IOException
	 */
	public void trapV3Alert(AlertTrap alertTrap, SnmpV3Target target, int securityLevel)
			throws IOException;

	/**
	 * 停止客户端
	 * 
	 */
	public void stop();
}
