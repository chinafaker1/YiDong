/*
 * Date: 2013-2-4
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.pub;

import javax.servlet.http.HttpServletRequest;

import cn.com.taiji.common.manager.pub.AbstractHelper;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-2-4 下午3:58:59<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class IPTools extends AbstractHelper
{
	/**
	 * 获取客户端的IP地址
	 * 
	 * @param request
	 * @return
	 */
	public static String getIpAddr(HttpServletRequest request)
	{
		String ip = request.getHeader(" x-forwarded-for ");
		if (ip == null || ip.length() == 0 || " unknown ".equalsIgnoreCase(ip))
		{
			ip = request.getHeader(" Proxy-Client-IP ");
		}
		if (ip == null || ip.length() == 0 || " unknown ".equalsIgnoreCase(ip))
		{
			ip = request.getHeader(" WL-Proxy-Client-IP ");
		}
		if (ip == null || ip.length() == 0 || " unknown ".equalsIgnoreCase(ip))
		{
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	// 十进制ip地址转化为长整型（59.225.0.0-->1004601344L）
	public static long ip2Long(String ip)
	{
		String[] ips = ip.split("\\.");
		long num = 16777216L * Long.parseLong(ips[0]) + 65536L * Long.parseLong(ips[1]) + 256 * Long.parseLong(ips[2])
				+ Long.parseLong(ips[3]);
		return num;
	}

	// 长整型转化为十进制ip地址（1004601344L-->59.225.0.0）
	public static String long2IP(long ipLong)
	{
		long mask[] = { 0x000000FF, 0x0000FF00, 0x00FF0000, 0xFF000000 };
		long num = 0;
		StringBuffer ipInfo = new StringBuffer();
		for (int i = 0; i < 4; i++)
		{
			num = (ipLong & mask[i]) >> (i * 8);
			if (i > 0) ipInfo.insert(0, ".");
			ipInfo.insert(0, Long.toString(num, 10));
		}
		return ipInfo.toString();
	}

	// 根据IP和子网掩码获取IP网段
	public static long[] getIPStartAndEnd(String ip, String mask)
	{
		long s1 = ip2Long(ip);
		long s2 = ip2Long(mask);
		String erj = Long.toBinaryString(s2);
		long s3 = s1 & s2;
		long start = ip2Long(long2IP(s3));
		String wl = Long.toBinaryString(s3);
		if (wl.length() < 32)
		{
			int le = 32 - wl.length();
			for (int i = 0; i < le; i++)
			{
				wl = "0" + wl;
			}
		}
		String gbl = wl.substring(0, erj.indexOf("0")) + wl.substring(erj.indexOf("0"), wl.length()).replace("0", "1");
		long s4 = Long.parseLong(gbl, 2);
		long end = ip2Long(long2IP(s4));
		return new long[] { start, end };
	}

}
