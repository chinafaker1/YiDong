package cn.com.taiji.common.manager.net.snmp;

import java.util.Map;

import cn.com.taiji.common.model.net.snmp.SwitchIp;


/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-7-11 上午11:30:28
 * @since 1.0
 * @version 1.0
 */
public interface SnmpClientHandler
{
	/**
	 * 
	 * @param gwIfMap
	 * @param switchIp
	 */
	public void handleSwitchIp(final Map<String, String> gwIfMap, final SwitchIp switchIp);
}
