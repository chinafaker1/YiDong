package cn.com.taiji.common.pub;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-19 下午02:30:52
 * @since 1.0
 * @version 1.0
 */
public class ByteUtil extends CommonAbstract
{
	private static final String END_STR = "\0";

	public static final String UTF8 = "UTF-8";

	/**
	 * 将字符串转换为指定长度的byte[]数组
	 * 
	 * @param str
	 * @param length
	 * @return
	 */
	public static byte[] toBytes(String str, int length)
	{
		try
		{
			if (length <= 0) return new byte[0];
			if (str == null) return new byte[length];
			byte[] result = new byte[length];
			byte[] strBytes = str.getBytes(UTF8);
			if (length >= strBytes.length)
			{
				for (int i = 0; i < strBytes.length; i++)
					result[i] = strBytes[i];
			}
			else
			{
				for (int i = 0; i < length; i++)
					result[i] = strBytes[i];
			}
			return result;
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage(), e.getCause());
		}
	}

	/**
	 * 按长度补齐字符串,长度超过部分用\0补齐
	 * 
	 * @param str
	 * @param length
	 * @return
	 */
	public static String getByteStr(String str, int length)
	{
		try
		{
			byte[] bytes = toBytes(str, length);
			return new String(bytes, 0, length, UTF8);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e.getMessage(), e.getCause());
		}
	}

	/**
	 * 在第一个\0处切断字符串
	 * 
	 * @param str
	 * @return 返回\0以前的字符串,没有\0返回原字符串.
	 */
	public static String subStr(String str)
	{
		if (str == null || str.indexOf(END_STR) < 0) return str;
		return str.substring(0, str.indexOf(END_STR));
	}
}
