package cn.com.taiji.common.manager.net.exec;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

import cn.com.taiji.common.manager.net.ExecResultHandler;
import cn.com.taiji.common.manager.net.ExecStrResultHandler;
import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.model.net.ExecTarget;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.StringTools;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-11-17 下午03:59:36
 * @since 1.0
 * @version 1.0
 */
public abstract class SshExecHelper
{
	protected static Logger logger = LoggerFactory.getLogger(SshExecHelper.class);

	protected static JSch jsch = new JSch();

	// TOM修改与20121018，因为在Linux机器上的时候，gssapi-with-mic之后，服务器断开连接了，我们
	// 目前使用的多的是 password方式，所以把password放在了最前面
	static
	{
		JSch.setConfig("PreferredAuthentications", "password,gssapi-with-mic,publickey,keyboard-interactive");
	}
	protected static final UserInfo defaultUserInfo = new MyUserInfo();

	public static void execCmd(ExecTarget target, String cmd, ExecResultHandler handler) throws IOException
	{
		execCmd(target, cmd, handler, null);
	}

	public static void execCmd(ExecTarget target, String cmd, ExecStrResultHandler handler) throws IOException
	{
		execCmd(target, cmd, handler, null);
	}

	/**
	 * 通过ssh远程执行命令
	 * 
	 * @param target
	 *            目标
	 * @param cmd
	 *            命令
	 * @param handler
	 *            执行结果的处理器
	 * @param rsEncoding
	 *            错误信息的字符集，为空默认为UTF-8
	 * @throws IOException
	 *             连接或执行命令错误抛出异常，原因在e.getMessage()
	 */
	public static void execCmd(ExecTarget target, String cmd, ExecResultHandler handler, String rsEncoding)
			throws IOException
	{
		executeCmd(target, cmd, handler, rsEncoding);
	}

	/**
	 * 通过ssh远程执行命令
	 * 
	 * @param target
	 *            目标
	 * @param cmd
	 *            命令
	 * @param handler
	 *            执行结果的处理器
	 * @param rsEncoding
	 *            错误信息的字符集，为空默认为UTF-8
	 * @throws IOException
	 *             连接或执行命令错误抛出异常，原因在e.getMessage()
	 */
	public static void execCmd(ExecTarget target, String cmd, ExecStrResultHandler handler, String rsEncoding)
			throws IOException
	{
		executeCmd(target, cmd, handler, rsEncoding);
	}

	private static void executeCmd(ExecTarget target, String cmd, Object handler, String rsEncoding) throws IOException
	{
		AssertUtil.notNull(target, "SshTarget can not be null.");
		AssertUtil.hasText(cmd, "ssh cmd must has text.");
		String charset = StringTools.hasText(rsEncoding) ? rsEncoding : "UTF-8";
		Session session = null;
		Channel channel = null;
		try
		{
			session = newSession(target);
			channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(cmd);

			// 接收错误信息
			PipedOutputStream errOut = new PipedOutputStream();
			PipedInputStream errIn = new PipedInputStream(errOut);
			((ChannelExec) channel).setErrStream(errOut);
			// 接收结果信息
			InputStream in = channel.getInputStream();
			channel.connect();
			// 接收结果信息
			File file = null;
			String rs = null;
			if (handler instanceof ExecResultHandler)
			{
				String uid = UUID.randomUUID().toString();
				file = new File(FileHelper.getTmpPath() + "/sshRs-" + uid + ".txt");
				FileOutputStream fos = new FileOutputStream(file);
				FileCopyUtils.copy(in, fos);// 将结果存放至文件
			}
			else
			{
				byte[] bytes = FileCopyUtils.copyToByteArray(in);
				rs = new String(bytes, charset);
			}
			// 判断是否正常退出
			exitChannel(channel, errIn, charset);
			errOut.close();
			if (handler instanceof ExecResultHandler)
			{
				((ExecResultHandler) handler).handle(file);
			}
			else if (handler instanceof ExecStrResultHandler)
			{
				((ExecStrResultHandler) handler).handle(rs);
			}
		}
		catch (JSchException e)
		{
			throw new IOException(e.getMessage());
		}
		catch (InterruptedException e)
		{
			logger.error("", e);
		}
		finally
		{
			if (channel != null) channel.disconnect();
			if (session != null) session.disconnect();
		}
	}

	private static Session newSession(ExecTarget target) throws JSchException
	{
		Session session = jsch.getSession(target.getUser(), target.getIp(), target.getPort());
		session.setPassword(target.getPass());
		session.setUserInfo(defaultUserInfo);
		if (target.getTimeout() > 0) session.setTimeout(target.getTimeout());
		session.connect();
		return session;
	}

	private static void exitChannel(Channel channel, InputStream errIn, String encoding) throws InterruptedException,
			IOException
	{
		while (true)
		{
			if (!channel.isClosed())
			{
				Thread.sleep(50);
				continue;
			}
			int exitStatus = channel.getExitStatus();
			logger.debug("exitStatus={}", exitStatus);
			if (exitStatus != 0)
			{
				byte[] bytes = (errIn == null) ? null : FileCopyUtils.copyToByteArray(errIn);
				if (bytes == null || bytes.length == 0) throw new IOException("命令执行错误exit-status:" + exitStatus);
				throw new IOException(new String(bytes, encoding));
			}
			break;
		}
	}

	/**
	 * 通过shell模拟执行命令，将shell执行命令后的输出结果全部保存， <BR>
	 * 不推荐用此方法执行命令,除非 {@link #execCmd(ExecTarget, String, ExecResultHandler, String)}无法满足要求
	 * 
	 * @param target
	 *            目标
	 * @param cmd
	 *            命令
	 * @param handler
	 *            执行结果的处理器
	 * @throws IOException
	 *             连接或执行命令错误抛出异常，原因在e.getMessage()
	 */
	public static void execShellCmd(ExecTarget target, String cmd, ExecResultHandler handler) throws IOException
	{
		AssertUtil.notNull(target, "SshTarget不能为空.");
		AssertUtil.hasText(cmd, "ssh命令不能为空.");
		Session session = null;
		Channel channel = null;
		try
		{
			session = newSession(target);
			channel = session.openChannel("shell");
			// for send cmd
			PipedInputStream pipeIn = new PipedInputStream();
			PipedOutputStream pipeOut = new PipedOutputStream(pipeIn);
			// for recevie result
			String uid = UUID.randomUUID().toString();
			File file = new File(FileHelper.getTmpPath() + "/shellRs-" + uid + ".txt");
			FileOutputStream fos = new FileOutputStream(file);

			channel.setInputStream(pipeIn);
			channel.setOutputStream(fos);
			channel.connect();

			String command = cmd + "\n";
			pipeOut.write(command.getBytes());
			pipeOut.flush();
			// 判断是否正常退出
			command = "exit\n";
			pipeOut.write(command.getBytes());
			pipeOut.flush();
			exitChannel(channel, null, null);
			pipeIn.close();
			pipeOut.close();
			fos.close();
			if (handler != null) handler.handle(file);
		}
		catch (JSchException e)
		{
			throw new IOException(e.getMessage());
		}
		catch (InterruptedException e)
		{
			logger.error(e.getMessage(), e);
		}
		finally
		{
			if (channel != null) channel.disconnect();
			if (session != null) session.disconnect();
		}
	}

	public static class MyUserInfo implements UserInfo
	{

		public String getPassphrase()
		{
			return null;
		}

		public String getPassword()
		{
			return null;
		}

		public boolean promptPassphrase(String message)
		{
			// System.out.println("promptPassphrase = " + message);
			return false;
		}

		public boolean promptPassword(String message)
		{
			// System.out.println("promptPassword = " + message);
			return false;
		}

		public boolean promptYesNo(String message)
		{
			// System.out.println("promptYesNo = " + message);
			return true;
		}

		public void showMessage(String message)
		{
			// System.out.println("promptPassword = " + message);
		}
	}
}
