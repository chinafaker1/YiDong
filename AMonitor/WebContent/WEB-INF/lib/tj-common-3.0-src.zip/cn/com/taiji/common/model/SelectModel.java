package cn.com.taiji.common.model;


public class SelectModel extends BaseModel implements Comparable<SelectModel>
{
	private String selectName;
	private String selectValue;

	public SelectModel()
	{

	}

	public SelectModel(String selectName, String selectValue)
	{
		this.selectName = selectName;
		this.selectValue = selectValue;
	}

	public String getSelectName()
	{
		return selectName;
	}

	public void setSelectName(String selectName)
	{
		this.selectName = selectName;
	}

	public String getSelectValue()
	{
		return selectValue;
	}

	public void setSelectValue(String selectValue)
	{
		this.selectValue = selectValue;
	}

	@Override
	public boolean equals(Object obj)
	{
		return super.equals(obj);
	}

	@Override
	public int hashCode()
	{
		return super.hashCode();
	}

	public int compareTo(SelectModel o)
	{
		if (o == null || o.getSelectName() == null) return -1;
		if (selectName == null) return 1;
		return selectName.compareTo(o.getSelectName());
	}
}
