/*
 * Date: 2011-12-20
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.format;

import java.text.ParseException;
import java.util.Locale;

import org.springframework.format.Formatter;

import cn.com.taiji.common.manager.AbstractManager;


/**
 * 
 * @author Peream <br>
 *         Create Time：2011-12-20 下午3:03:44<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class TrimStringFormatter extends AbstractManager implements Formatter<String>
{
	@Override
	public String print(String object, Locale locale)
	{
		return object == null ? null : object.trim();
	}

	@Override
	public String parse(String text, Locale locale) throws ParseException
	{
		return text == null ? null : text.trim();
	}

}
