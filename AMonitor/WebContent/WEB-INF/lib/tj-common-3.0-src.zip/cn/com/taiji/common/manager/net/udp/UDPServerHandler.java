package cn.com.taiji.common.manager.net.udp;

import org.xsocket.datagram.IDatagramHandler;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-13 下午05:30:07
 * @since 1.0
 * @version 1.0
 */
public interface UDPServerHandler extends IDatagramHandler
{
	
}
