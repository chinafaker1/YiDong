/*
 * Date: 2012-7-2
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.json;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-7-2 上午9:58:27<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 * @see {@link AbstractProtocol}
 */
public final class JsonProtocol extends BaseModel
{
	private String type;// 具体项目中用枚举的name值
	private String jsonStr;

	public JsonProtocol()
	{

	}

	public JsonProtocol(String type, String jsonStr)
	{
		this.type = type;
		this.jsonStr = jsonStr;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getJsonStr()
	{
		return jsonStr;
	}

	public void setJsonStr(String jsonStr)
	{
		this.jsonStr = jsonStr;
	}
}
