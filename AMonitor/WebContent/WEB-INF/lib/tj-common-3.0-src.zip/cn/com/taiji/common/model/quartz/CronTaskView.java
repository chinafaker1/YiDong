/*
 * Date: 2013-5-6
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.model.quartz;

import org.springframework.scheduling.support.CronTrigger;

import cn.com.taiji.common.model.BaseModel;
import cn.com.taiji.common.validation.MyViolationException;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-6 下午4:49:06<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class CronTaskView extends BaseModel implements Comparable<CronTaskView>
{
	private String taskName;
	private String cron;
	private boolean running;
	private boolean taskRunning;
	private boolean stopImmediate;
	private boolean autoStart;
	private String type;// 定时器的分类，用于查询一组类型时比较方便
	private String info;

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public boolean isAutoStart()
	{
		return autoStart;
	}

	public void setAutoStart(boolean autoStart)
	{
		this.autoStart = autoStart;
	}

	public String getInfo()
	{
		return info;
	}

	public void setInfo(String info)
	{
		this.info = info;
	}

	public boolean isStopImmediate()
	{
		return stopImmediate;
	}

	public void setStopImmediate(boolean stopImmediate)
	{
		this.stopImmediate = stopImmediate;
	}

	public String getTaskName()
	{
		return taskName;
	}

	public String getCron()
	{
		return cron;
	}

	public boolean isRunning()
	{
		return running;
	}

	public boolean isTaskRunning()
	{
		return taskRunning;
	}

	public void setTaskName(String taskName)
	{
		this.taskName = taskName;
	}

	public void setCron(String cron)
	{
		this.cron = cron;
	}

	public void setRunning(boolean running)
	{
		this.running = running;
	}

	public void setTaskRunning(boolean taskRunning)
	{
		this.taskRunning = taskRunning;
	}

	public void valid()
	{
		try
		{
			new CronTrigger(cron);
		}
		catch (Exception e)
		{
			throw new MyViolationException("cron", "cron表达式错误");
		}
	}

	@Override
	public int compareTo(CronTaskView o)
	{
		if (o == null || o.getTaskName() == null) return 1;
		if (o == this) return 0;
		if (taskName == null) return -1;
		return taskName.compareTo(o.getTaskName());
	}

}
