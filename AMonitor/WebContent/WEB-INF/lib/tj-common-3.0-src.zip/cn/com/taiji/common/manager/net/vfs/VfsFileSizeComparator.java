package cn.com.taiji.common.manager.net.vfs;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileType;

import cn.com.taiji.common.pub.CommonAbstract;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2015年8月15日 下午2:12:47<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class VfsFileSizeComparator extends CommonAbstract implements Comparator<FileObject>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4590291875119826733L;
	private boolean desc;

	public VfsFileSizeComparator()
	{
		this.desc = false;
	}

	public VfsFileSizeComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(FileObject o1, FileObject o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null) return desc ? 1 : -1;
		if (o2 == null) return desc ? -1 : 1;
		try
		{
			if (o1.getType() != FileType.FILE) return desc ? 1 : -1;
			if (o2.getType() != FileType.FILE) return desc ? -1 : 1;
			long difference = o1.getContent().getSize() - o2.getContent().getSize();
			if (desc) return (difference > 0 ? -1 : 1);
			return difference > 0 ? 1 : -1;
		}
		catch (FileSystemException e)
		{
			logger.error("", e);
			return 1;
		}
	}

}
