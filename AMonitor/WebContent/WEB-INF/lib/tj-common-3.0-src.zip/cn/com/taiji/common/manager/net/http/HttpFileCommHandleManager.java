/*
 * Date: 2015年4月9日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.taiji.common.model.file.FileProtocolRequest;
import cn.com.taiji.common.model.file.FileProtocolResponse;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年4月9日 下午2:28:44<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public interface HttpFileCommHandleManager
{
	/**
	 * 处理二进制文件请求
	 * 
	 * @param protocol
	 * @param request
	 * @param response
	 * @return
	 */
	public FileProtocolResponse handleComm(FileProtocolRequest protocol, HttpServletRequest request,
			HttpServletResponse response);

	public void addListener(FileCommHandleListener listener);
}
