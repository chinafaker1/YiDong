package cn.com.taiji.common.model.net.snmp;

import org.snmp4j.PDU;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-6 下午04:48:30
 * @since 1.0
 * @version 1.0
 */
public interface V2Trap
{
	public PDU getV2cTrap();
}
