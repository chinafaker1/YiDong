package cn.com.taiji.common.pub.audit;

import org.jfree.chart.plot.PlotOrientation;

import cn.com.taiji.common.model.BaseModel;


/**
 * @author Peream mail:peream@gmail.com
 * 
 *         2007-6-27 上午09:47:24
 * @since 1.0
 * @Version 1.0
 */
public class ChartInfo extends BaseModel
{
	// 图的名字
	private String chartName;

	// 目录轴名字
	private String nameLable;

	// 值轴名字
	private String valueLable;

	// 图的方向,水平还是垂直,只对柱状图有效
	private PlotOrientation orientation = PlotOrientation.HORIZONTAL;

	// 倾斜目录轴的字体
	private boolean slantNameLabel = true;

	public ChartInfo(String chartName)
	{
		this.chartName = chartName;
	}

	public ChartInfo(String chartName, String nameLabel, String valueLabel)
	{
		this(chartName, nameLabel, valueLabel, PlotOrientation.HORIZONTAL);
	}

	public ChartInfo(String chartName, String nameLabel, String valueLabel,
			PlotOrientation orientation)
	{
		this.chartName = chartName;
		this.nameLable = nameLabel;
		this.valueLable = valueLabel;
		this.orientation = orientation;
	}

	public String getChartName()
	{
		return chartName;
	}

	public void setChartName(String chartName)
	{
		this.chartName = chartName;
	}

	public String getNameLable()
	{
		return nameLable;
	}

	public void setNameLable(String nameLabel)
	{
		this.nameLable = nameLabel;
	}

	public PlotOrientation getOrientation()
	{
		return orientation;
	}

	public void setOrientation(PlotOrientation orientation)
	{
		this.orientation = orientation;
	}

	public boolean isSlantNameLabel()
	{
		return slantNameLabel;
	}

	public void setSlantNameLabel(boolean slantLabel)
	{
		this.slantNameLabel = slantLabel;
	}

	public String getValueLable()
	{
		return valueLable;
	}

	public void setValueLable(String valueLabel)
	{
		this.valueLable = valueLabel;
	}
}
