package cn.com.taiji.common.manager.net.vfs;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;

import cn.com.taiji.common.pub.CommonAbstract;

/**
 * 
 * 
 * @author Peream <br>
 *         Create Time：2015年8月15日 下午1:56:18<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class VfsFileTimeComparator extends CommonAbstract implements Comparator<FileObject>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5033543327558818407L;
	private boolean desc;

	public VfsFileTimeComparator()
	{
		this.desc = false;
	}

	public VfsFileTimeComparator(boolean desc)
	{
		super();
		this.desc = desc;
	}

	public int compare(FileObject o1, FileObject o2)
	{
		if (o1 == o2) return 0;
		if (o1 == null) return desc ? 1 : -1;
		if (o2 == null) return desc ? -1 : 1;
		try
		{
			long difference = o1.getContent().getLastModifiedTime() - o2.getContent().getLastModifiedTime();
			if (desc) return (difference > 0 ? -1 : 1);
			return difference > 0 ? 1 : -1;
		}
		catch (FileSystemException e)
		{
			logger.error("", e);
			return 1;
		}
	}

}
