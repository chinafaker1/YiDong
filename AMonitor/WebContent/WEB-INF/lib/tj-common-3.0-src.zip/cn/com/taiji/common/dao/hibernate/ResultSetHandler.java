package cn.com.taiji.common.dao.hibernate;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 
 * @author Peream <br>
 *         Create Time：2009-8-4 下午01:49:42<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.5
 * @version 1.0
 */
public interface ResultSetHandler<T>
{
	/**
	 * 处理结果集
	 * 
	 * @param row
	 * @return
	 */
	public T handle(ResultSet row) throws SQLException;
}
