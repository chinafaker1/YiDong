/*
 * Date: 2013-5-1
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.http;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.message.BasicNameValuePair;

import cn.com.taiji.common.manager.pub.AbstractHelper;
import cn.com.taiji.common.model.json.AbstractProtocol;
import cn.com.taiji.common.model.json.JsonProtocol;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.json.JsonTools;

/**
 * 
 * @author Peream <br>
 *         Create Time：2013-5-1 下午2:31:23<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0 {@link JsonProtocol}
 */
public abstract class JsonCommHelper extends AbstractHelper
{

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param request
	 *            请求协议的内容
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request) throws IOException
	{
		return httpPost(clazz, url, connTimeout, request.toJsonProtocol());
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数 负数忽略
	 * @param jsonRequest
	 *            请求协议的内容
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol jsonRequest) throws IOException
	{
		return httpPost(clazz, url, connTimeout, jsonRequest, -1);
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param request
	 *            请求协议的内容
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request, int soTimeout) throws IOException
	{
		return httpPost(clazz, url, connTimeout, request.toJsonProtocol(), soTimeout);
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param jsonRequest
	 *            请求协议的内容
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol jsonRequest, int soTimeout) throws IOException
	{
		return httpPost(clazz, url, connTimeout, jsonRequest, soTimeout, null, (BasicNameValuePair[]) null);
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param request
	 *            请求协议的内容
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param handler
	 *            返回信息的前置处理，比如记录日志，校验返回等等
	 * @param additionalParams
	 *            附加的请求参数
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request, int soTimeout, JsonProtocolPreHandler handler,
			BasicNameValuePair... additionalParams) throws IOException
	{
		return httpPost(clazz, url, connTimeout, request.toJsonProtocol(), soTimeout, handler, additionalParams);
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param request
	 *            请求协议的内容
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param handler
	 *            返回信息的前置处理，比如记录日志，校验返回等等
	 * @param additionalParams
	 *            附加的请求参数
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol jsonRequest, int soTimeout, JsonProtocolPreHandler handler,
			BasicNameValuePair... additionalParams) throws IOException
	{
		return httpPost(clazz, url, connTimeout, jsonRequest, "UTF-8", soTimeout, "UTF-8", handler, additionalParams);
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param request
	 *            请求协议的内容
	 * @param requestEncoding
	 *            请求编码方式
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param defaultResEncoding
	 *            默认返回信息的处理编码
	 * @param handler
	 *            返回信息的前置处理，比如记录日志，校验返回等等
	 * @param additionalParams
	 *            附加的请求参数
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			JsonProtocol jsonRequest, String requestEncoding, int soTimeout, String defaultResEncoding,
			JsonProtocolPreHandler handler, BasicNameValuePair... additionalParams) throws IOException
	{
		AssertUtil.notNull(jsonRequest);
		List<BasicNameValuePair> params = new ArrayList<BasicNameValuePair>();
		params.add(new BasicNameValuePair("type", jsonRequest.getType()));
		params.add(new BasicNameValuePair("jsonStr", jsonRequest.getJsonStr()));
		if (additionalParams != null)
		{
			for (BasicNameValuePair param : additionalParams)
				params.add(param);
		}
		String res = HttpClientHelper.httpPost(url, true, connTimeout, requestEncoding, params,
				new Response2StringHandler(defaultResEncoding), soTimeout);
		JsonProtocol protocol = JsonTools.json2Object(res, JsonProtocol.class);
		if (handler != null) handler.preHandle(protocol);
		return protocol == null ? null : AbstractProtocol.newInstance(clazz, protocol.getJsonStr());
	}

	/**
	 * http post方式请求指定的URL，完成使用<code>{@link JsonProtocol}</code>作为通信协议的http请求
	 * 
	 * @param clazz
	 *            返回协议对应的类
	 * @param url
	 *            指定的URL
	 * @param connTimeout
	 *            连接超时毫秒数
	 * @param request
	 *            请求协议的内容
	 * @param requestEncoding
	 *            请求编码方式
	 * @param soTimeout
	 *            响应超时毫秒数 负数忽略
	 * @param defaultResEncoding
	 *            默认返回信息的处理编码
	 * @param handler
	 *            返回信息的前置处理，比如记录日志，校验返回等等
	 * @param additionalParams
	 *            附加的请求参数
	 * @return 响应协议的内容
	 * @throws IOException
	 */
	public static <T extends AbstractProtocol> T httpPost(Class<T> clazz, String url, int connTimeout,
			AbstractProtocol request, String requestEncoding, int soTimeout, String defaultResEncoding,
			JsonProtocolPreHandler handler, BasicNameValuePair... additionalParams) throws IOException
	{
		return httpPost(clazz, url, connTimeout, request.toJsonProtocol(), requestEncoding, soTimeout,
				defaultResEncoding, handler, additionalParams);
	}
}
