package cn.com.taiji.common.pub.file;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.taiji.common.manager.pub.FileHelper;
import cn.com.taiji.common.pub.AssertUtil;
import cn.com.taiji.common.pub.StringTools;

/**
 * @author Peream<br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-3-7 下午03:14:17
 * @since 1.0
 * @version 1.0
 */
public class ImageTools extends FileTools
{
	protected static Logger logger = LoggerFactory.getLogger(ImageTools.class);

	public final static String PNG = "png";
	public final static String JPG = "jpg";
	public final static String GIF = "gif";

	/**
	 * 將blob轉換為圖片
	 * 
	 * @param path
	 *            存儲的路徑
	 * @param blob
	 *            被轉換的blob
	 * @param name
	 *            轉換后的名字
	 * @param convert
	 *            是否转换图片，即是否还进行另存操作
	 * @return 轉換后的圖片文件,不重新生成新的
	 * @throws IOException
	 * @throws SQLException
	 */
	public static File blob2Png(String path, Blob blob, String name) throws IOException, SQLException
	{
		return blob2Png(path, blob, name, false);
	}

	/**
	 * 将Blob转换为文件
	 * 
	 * @param path
	 *            转换后文件存储的路径
	 * @param blob
	 *            被转换的blob，不能能空
	 * @param name
	 *            转换后的文件名
	 * @param alwaysNew
	 *            如果指定目录下已经存在指定文件是否重新转换
	 * @return 转换后的文件
	 * @throws IOException
	 * @throws SQLException
	 */
	public static File blob2Png(String path, Blob blob, String name, boolean alwaysNew) throws IOException,
			SQLException
	{
		return blob2File(path, blob, name, alwaysNew);
	}

	/**
	 * 將blob轉換為圖片
	 * 
	 * @param blob
	 *            被轉換的blob
	 * @param name
	 *            轉換后的名字
	 * @return 轉換后的圖片文件,默認存放在tmp目錄下,不重新生成新的
	 * @throws IOException
	 * @throws SQLException
	 */
	public static File blob2Png(Blob blob, String name) throws IOException, SQLException
	{
		String path = FileHelper.getTmpPath();
		return blob2Png(path, blob, name, false);
	}

	/**
	 * 將blob轉換為圖片
	 * 
	 * @param blob
	 *            被轉換的blob
	 * @param name
	 *            轉換后的名字
	 * @param alwaysNew
	 *            是否重新生成新的
	 * @return 轉換后的圖片文件,默認存放在tmp目錄下
	 * @throws IOException
	 * @throws SQLException
	 */
	public static File blob2Png(Blob blob, String name, boolean alwaysNew) throws IOException, SQLException
	{
		String path = FileHelper.getTmpPath();
		return blob2Png(path, blob, name, alwaysNew);
	}

	/**
	 * 图片另存
	 * 
	 * @param srcPath
	 *            源图片路径 为空时，用tmp目录
	 * @param srcName
	 *            源图片名字
	 * @param type
	 *            转换后的类型
	 * @return 转换后的文件，存放于源路径下
	 * @throws IOException
	 */
	public static File saveAs(String srcPath, String srcName, String type) throws IOException
	{
		if ((!StringTools.hasText(srcName)) || (!StringTools.hasText(type)))
			throw new IllegalArgumentException("srcName and type must have text.");
		String myPath = (StringTools.hasText(srcPath)) ? srcPath : FileHelper.getTmpPath();
		String srcFile = myPath + "/" + srcName;
		File inputFile = new File(srcFile);
		String fullName = inputFile.getName();

		StringBuilder destFile = new StringBuilder(myPath);
		destFile.append("/").append(fullName).append(".").append(type);

		File outputFile = new File(destFile.toString());
		//  2012年3月19日 在weather工程发现重名时会造成已形成的文件不再生成  造成另存与显示的不一致。
//		if (outputFile.exists()) return outputFile;
		BufferedImage input = ImageIO.read(inputFile);
		ImageIO.write(input, type, outputFile);
		return outputFile;
	}

	public static File saveAs(String srcName, String type) throws IOException
	{
		return saveAs(null, srcName, type);
	}

	/**
	 * 图片黑白反色
	 * 
	 * @param srcPath
	 *            源图片路径 为空时，用tmp目录
	 * @param srcName
	 *            源图片名字
	 * @return 反色后的图片，存放于源路径下
	 * @throws IOException
	 */
	public static File reverse(String srcPath, String srcName) throws IOException
	{
		if (!StringTools.hasText(srcName)) throw new IllegalArgumentException("srcName must has text");
		String myPath = (StringTools.hasText(srcPath)) ? srcPath : FileHelper.getTmpPath();
		String srcFile = myPath + "/" + srcName;
		File inputFile = new File(srcFile);
		String name = inputFile.getName();

		String destFile = myPath + "/reverse" + name + ".png";
		File outputFile = new File(destFile);
		//  2012年3月19日 在weather工程发现重名时会造成已形成的文件不再生成  造成另存与显示的不一致。
//		if (outputFile.exists()) return outputFile;
		BufferedImage srcImage = ImageIO.read(inputFile);

		int h = srcImage.getHeight();
		int w = srcImage.getWidth();
		for (int i = 0; i < h; i++)
		{
			for (int j = 0; j < w; j++)
			{
				srcImage.setRGB(j, i, getRGB2H(srcImage, j, i));
			}
		}
		ImageIO.write(srcImage, PNG, outputFile);
		return outputFile;
	}

	public static File reverse(String srcName) throws IOException
	{
		return reverse(null, srcName);
	}

	/**
	 * 取得图像上指定位置像素的 rgb 颜色分量。
	 * 
	 * @param image
	 *            源图像。
	 * @param x
	 *            图像上指定像素位置的 x 坐标。
	 * @param y
	 *            图像上指定像素位置的 y 坐标。
	 * @return 返回包含 rgb 颜色分量值的数组。元素 index 由小到大分别对应 r，g，b。
	 */
	public static int getRGB2H(BufferedImage image, int x, int y)
	{
		int[] rgb = new int[3];
		int pixel = image.getRGB(x, y);
		rgb[0] = (pixel & 0xff0000) >> 16;
		rgb[1] = (pixel & 0xff00) >> 8;
		rgb[2] = (pixel & 0xff);

		int R = 255 - rgb[0];
		int G = 255 - rgb[1];
		int B = 255 - rgb[2];
		String RGB2H = getRGB2S(R) + getRGB2S(G) + getRGB2S(B);
		return Integer.parseInt(RGB2H, 16);
	}

	/**
	 * 图像缩放,保持缩略比,会根据定义的缩放后的宽、高自动选择合适的值
	 * 
	 * @param original
	 *            原图像
	 * @param targetW
	 *            缩放后的宽
	 * @param targetH
	 *            缩放后的高
	 * @return 缩略后的图像
	 * @see {@link} {@link ImageTools#reduce(BufferedImage, int, int, boolean)}
	 */
	public static BufferedImage reduce(final BufferedImage original, int targetW, int targetH)
	{
		return reduce(original, targetW, targetH, true);
	}

	/**
	 * 图像缩放,保持缩略比,会根据定义的缩放后的宽、高自动选择合适的值
	 * 
	 * @param input
	 * @param targetW
	 * @param targetH
	 * @return
	 * @throws IOException
	 */
	public static BufferedImage reduce(File input, int targetW, int targetH) throws IOException
	{
		BufferedImage original = ImageIO.read(input);
		return reduce(original, targetW, targetH, true);
	}

	public static BufferedImage reduce(final File input, final double percent) throws IOException
	{
		BufferedImage original = ImageIO.read(input);
		return reduce(original, percent);
	}

	/**
	 * 按百分比缩放图像
	 * 
	 * @param srcImg
	 * @param percent
	 * @return
	 */
	public static BufferedImage reduce(final BufferedImage srcImg, final double percent)
	{
		if (srcImg == null || percent <= 0) return srcImg;
		int width = (int) (srcImg.getWidth() * percent);
		int height = (int) (srcImg.getHeight() * percent);
		return reduce(srcImg, width, height, false);
	}

	/**
	 * 图像缩放，如果选择保持缩略比，会根据定义的缩放后的宽、高自动选择合适的值
	 * 
	 * @param srcImg
	 *            原图像
	 * @param targetW
	 *            缩放后的宽
	 * @param targetH
	 *            缩放后的高
	 * @param sameRate
	 *            是否与原图像保持一样的比例
	 * @return 缩略后的图像
	 */
	public static BufferedImage reduce(final BufferedImage srcImg, final int targetW, final int targetH,
			boolean sameRate)
	{
		return reduce(false, srcImg, targetW, targetH, sameRate);
	}

	public static BufferedImage reduce(boolean withAlpha, final BufferedImage srcImg, final int targetW,
			final int targetH, boolean sameRate)
	{
		if (srcImg == null) return null;
		double sx = (double) targetW / srcImg.getWidth();
		double sy = (double) targetH / srcImg.getHeight();
		int myTargetW = targetW;
		int myTargetH = targetH;
		// 这里想实现在targetW，targetH范围内实现等比缩放。如果不需要等比缩放
		// 则将下面的if else语句注释即可
		if (sameRate)
		{
			if (sx > sy)
			{
				sx = sy;
				myTargetW = (int) (sx * srcImg.getWidth());
			}
			else
			{
				sy = sx;
				myTargetH = (int) (sy * srcImg.getHeight());
			}
		}
		final Image rescaled = srcImg.getScaledInstance(myTargetW, myTargetH, Image.SCALE_AREA_AVERAGING);
		// ------------------TOM 20121018
		// 修正此BUG：上传透明度为1的图片变为不透明图片
		int imageType = withAlpha ? BufferedImage.TYPE_4BYTE_ABGR_PRE : BufferedImage.TYPE_INT_RGB;
		final BufferedImage result = new BufferedImage(myTargetW, myTargetH, imageType);
		// -------------------
		final Graphics2D g = result.createGraphics();
		g.drawImage(rescaled, 0, 0, null);
		g.dispose();
		return result;
	}

	/**
	 * 取得图像上指定位置像素的 rgb 颜色分量字符串。
	 * 
	 * @param RGB
	 *            图像上指定像素位置的颜色值。
	 * @return 返回包含 rgb 颜色字符串。
	 */
	public static String getRGB2S(int RGB)
	{
		String HRGB = java.lang.Integer.toHexString(RGB);
		if (RGB > 15) return HRGB;
		return "0" + HRGB;
	}

	public static boolean isDestoryed(String srcPath, String srcName)
	{
		AssertUtil.notNull(srcName, "srcName can not be null.");
		String myPath = (StringTools.hasText(srcPath)) ? srcPath : FileHelper.getTmpPath();
		File file = new File(myPath + "/" + srcName);
		if (!file.exists()) return true;
		try
		{
			BufferedImage image = ImageIO.read(file);
			if (image == null) return true;
			return false;
		}
		catch (Exception e)
		{
			logger.error("", e);
			return true;
		}
	}

	public static boolean isDestoryed(String srcName)
	{
		return isDestoryed(null, srcName);
	}
}
