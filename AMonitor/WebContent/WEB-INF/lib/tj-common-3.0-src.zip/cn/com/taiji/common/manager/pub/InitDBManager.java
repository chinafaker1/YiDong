package cn.com.taiji.common.manager.pub;

import cn.com.taiji.common.manager.ManagerException;


/**
 * @author Peream mail:peream@gmail.com
 * 
 * 2007-7-24 下午03:53:51
 * @since 1.0
 * @Version 1.0
 */
public interface InitDBManager
{
	/**
	 * 根据文件导入数据到数据库
	 * @param fileName
	 * @throws Exception
	 */
	public void initByFile(String fileName) throws ManagerException;
	
	/**
	 * 将指定目录下的所有文件的数据导入到数据库
	 * @param path
	 * @throws Exception
	 */
	public void initByPath(String path) throws ManagerException;
}
