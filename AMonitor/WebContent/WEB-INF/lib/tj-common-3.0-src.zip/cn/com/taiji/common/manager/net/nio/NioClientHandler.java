package cn.com.taiji.common.manager.net.nio;

import org.xsocket.connection.IConnectHandler;
import org.xsocket.connection.IDataHandler;
import org.xsocket.connection.IDisconnectHandler;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2008-8-22 下午04:45:10
 * @since 1.0
 * @version 1.0
 */
public interface NioClientHandler extends IDataHandler, IConnectHandler, IDisconnectHandler
{
	public void setClient(NioClient client);

	public NioClient getClient();
}
