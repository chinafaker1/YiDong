package cn.com.taiji.common.model.net;

import cn.com.taiji.common.model.BaseModel;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-12-29 下午04:53:57<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class FtpStorePara extends BaseModel
{
	private String remote;// 远程路径 /xxx/xxx/xxx.txt
	private String local;// 本地绝对路径
	private boolean mkdirs = true;// 是否自动创建缺失文件
	private boolean binaryTransfer = true;// 是否使用二进制
	private boolean useSuffix;// 是否使用后缀，
	private String suffix;//
	private boolean deleteBeforeStore = true;// 使用后缀时必须启用本选项

	public String getRemote()
	{
		return remote;
	}

	public void setRemote(String remote)
	{
		this.remote = remote;
	}

	public String getLocal()
	{
		return local;
	}

	public void setLocal(String local)
	{
		this.local = local;
	}

	public boolean isMkdirs()
	{
		return mkdirs;
	}

	public void setMkdirs(boolean mkdirs)
	{
		this.mkdirs = mkdirs;
	}

	public boolean isBinaryTransfer()
	{
		return binaryTransfer;
	}

	public void setBinaryTransfer(boolean binaryTransfer)
	{
		this.binaryTransfer = binaryTransfer;
	}

	public boolean isUseSuffix()
	{
		return useSuffix;
	}

	public void setUseSuffix(boolean useSuffix)
	{
		this.useSuffix = useSuffix;
	}

	public String getSuffix()
	{
		return suffix;
	}

	public void setSuffix(String suffix)
	{
		this.suffix = suffix;
	}

	public boolean isDeleteBeforeStore()
	{
		return deleteBeforeStore;
	}

	public void setDeleteBeforeStore(boolean deleteBeforeStore)
	{
		this.deleteBeforeStore = deleteBeforeStore;
	}

}
