/*
 * Date: 2015年8月13日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.manager.net.vfs;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;

import cn.com.taiji.common.manager.net.AbstractClientService;
import cn.com.taiji.common.pub.AssertUtil;

/**
 * 
 * @author Peream <br>
 *         Create Time：2015年8月13日 下午7:13:06<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class SftpClientServiceImpl extends AbstractClientService implements SftpClientService
{
	private StandardFileSystemManager manager;
	private boolean userDirIsRoot;

	/**
	 * 
	 * @param server
	 *            服务器地址（IP）
	 * @param username
	 *            登录ftp的用户名
	 * @param password
	 *            登录ftp的密码
	 */
	public SftpClientServiceImpl(String server, String username, String password)
	{
		this(server, 22, username, password);
	}

	/**
	 * 
	 * @param server
	 *            服务器地址（IP）
	 * @param port
	 *            服务器端口
	 * @param username
	 *            登录ftp的用户名
	 * @param password
	 *            登录ftp的密码
	 */
	public SftpClientServiceImpl(String server, int port, String username, String password)
	{
		this(server, port, username, password, DEFAULT_CONNECT_TIMEOUT);
	}

	/**
	 * 
	 * @param server
	 *            服务器地址（IP）
	 * @param port
	 *            服务器端口
	 * @param username
	 *            登录ftp的用户名
	 * @param password
	 *            登录ftp的密码
	 * @param connTimeout
	 *            服务器连接的超时时间（毫秒），大于0时生效
	 */
	public SftpClientServiceImpl(String server, int port, String username, String password, int connTimeout)
	{
		this(server, port, username, password, connTimeout, false, "UTF-8");
	}

	/**
	 * 
	 * @param server
	 *            服务器地址（IP）
	 * @param port
	 *            服务器端口
	 * @param username
	 *            登录ftp的用户名
	 * @param password
	 *            登录ftp的密码
	 * @param connTimeout
	 *            服务器连接的超时时间（毫秒），大于0时生效
	 * @param userDirIsRoot
	 *            是否将用户主目录视为"/"
	 * @param encoding
	 *            服务器编码方式
	 */
	public SftpClientServiceImpl(String server, int port, String username, String password, int connTimeout,
			boolean userDirIsRoot, String encoding)
	{
		AssertUtil.notNull(server, "server can not be null");
		this.server = server;
		this.port = port;
		this.username = username == null ? "" : username;
		this.password = password == null ? "" : password;
		this.encoding = encoding;
		this.connTimeout = connTimeout;
		this.userDirIsRoot = userDirIsRoot;
		this.manager = new StandardFileSystemManager();
	}

	@Override
	public boolean isConnected()
	{
		try
		{
			manager.resolveFile(getUri("/"), getOptions(true));
			return true;
		}
		catch (FileSystemException e)
		{
			logger.error("", e);
			return false;
		}
	}

	@Override
	public boolean hasFile(String pathname) throws FileSystemException
	{
		FileObject fo = resolveRemote(pathname);
		return fo.exists();
	}

	@Override
	public void mkdir(String path) throws FileSystemException
	{
		FileObject fo = resolveRemote(path);
		fo.createFolder();
	}

	@Override
	public boolean rename(String from, String to) throws FileSystemException
	{
		FileObject fromFile = resolveRemote(from);
		FileObject toFile = resolveRemote(to);
		if (!fromFile.canRenameTo(toFile)) return false;
		fromFile.moveTo(toFile);
		return true;
	}

	@Override
	public List<FileObject> listFiles(String path) throws FileSystemException
	{
		return listFiles(path, null, null);
	}

	@Override
	public void storeFile(String remote, String local) throws FileSystemException
	{
		storeFile(remote, local, false);
	}

	@Override
	public void storeFile(String remote, String local, boolean useSuffix) throws FileSystemException
	{
		storeFile(remote, local, useSuffix, getPartSuffix());
	}

	@Override
	public void storeFile(String remote, String local, boolean useSuffix, String suffix) throws FileSystemException
	{
		String myRemote = useSuffix ? remote + suffix : remote;
		FileObject remoteFile = resolveRemote(myRemote);
		FileObject localFile = resolveLocal(local);
		remoteFile.copyFrom(localFile, Selectors.SELECT_FILES);
		if (useSuffix)
		{
			FileObject destFile = resolveRemote(remote);
			remoteFile.moveTo(destFile);
		}
	}

	@Override
	public void downFile(String remote, String local) throws FileSystemException
	{
		downFile(remote, local, getPartSuffix());
	}

	@Override
	public void downFile(String remote, String local, String suffix) throws FileSystemException
	{
		FileObject remoteFile = resolveRemote(remote);
		FileObject localFile = resolveLocal(local + suffix);
		localFile.copyFrom(remoteFile, Selectors.SELECT_FILES);
		FileObject localDest = resolveLocal(local);
		localFile.moveTo(localDest);
	}

	@Override
	public boolean deleteFile(String pathname) throws FileSystemException
	{
		FileObject fo = resolveRemote(pathname);
		return fo.delete();
	}

	@Override
	public StandardFileSystemManager getManager()
	{
		return manager;
	}

	@Override
	public List<FileObject> listFiles(String path, Pattern namePattern, Comparator<FileObject> comparator)
			throws FileSystemException
	{
		FileObject fo = resolveRemote(path);
		List<FileObject> rs = new ArrayList<FileObject>();
		fo.findFiles(new NamePatternSelector(namePattern), true, rs);
		if (comparator != null) Collections.sort(rs, comparator);
		return rs;
	}

	/**
	 * 如果manager不是线程安全的，对resolve方法加锁
	 * 
	 * @param pathname
	 * @return
	 * @throws FileSystemException
	 */
	private FileObject resolveRemote(String pathname) throws FileSystemException
	{
		return manager.resolveFile(getUri(pathname), getOptions());
	}

	private FileObject resolveLocal(String pathname) throws FileSystemException
	{
		File file = new File(pathname);
		return manager.resolveFile(file.getAbsolutePath());
	}

	@Override
	public synchronized void start() throws Exception
	{
		if (running.get())
		{
			logger.info("sftp client service already start.");
			return;
		}
		manager.init();
		running.set(true);
	}

	@Override
	public synchronized void stop()
	{
		if (!running.get())
		{
			logger.info("sftp client service is not running.");
			return;
		}
		try
		{
			if (manager != null) manager.close();
		}
		finally
		{
			running.set(false);
		}
	}

	private String getUri(String remotePath)
	{
		return toLogString("sftp://{}:{}@{}:{}{}", username, password, server, port, remotePath);
	}

	private FileSystemOptions getOptions() throws FileSystemException
	{
		return getOptions(userDirIsRoot);
	}

	private FileSystemOptions getOptions(boolean userDirIsRoot) throws FileSystemException
	{
		FileSystemOptions opts = new FileSystemOptions();
		SftpFileSystemConfigBuilder builder = SftpFileSystemConfigBuilder.getInstance();
		builder.setStrictHostKeyChecking(opts, "no");
		builder.setUserDirIsRoot(opts, userDirIsRoot);
		builder.setTimeout(opts, connTimeout);
		return opts;
	}
}
