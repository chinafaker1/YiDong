package cn.com.taiji.common.model;

import java.util.Calendar;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-13 下午05:49:15
 * @since 1.0
 * @version 1.0
 */
public class TimeModel extends BaseModel
{
	private Calendar startTime;
	private Calendar endTime;

	public Calendar getStartTime()
	{
		if (startTime == null) return null;
		int hour = startTime.get(Calendar.HOUR_OF_DAY);
		int minute = startTime.get(Calendar.MINUTE);
		int second = startTime.get(Calendar.SECOND);
		if (hour != 0 || minute != 0 || second != 0) return startTime;
		startTime.set(Calendar.HOUR_OF_DAY, 0);
		startTime.set(Calendar.MINUTE, 0);
		startTime.set(Calendar.SECOND, 0);
		startTime.set(Calendar.MILLISECOND, 0);
		return startTime;
	}

	public void setStartTime(Calendar startTime)
	{
		this.startTime = startTime;
	}

	public Calendar getEndTime()
	{
		if (endTime == null) return null;
		int hour = endTime.get(Calendar.HOUR_OF_DAY);
		int minute = endTime.get(Calendar.MINUTE);
		int second = endTime.get(Calendar.SECOND);
		if (hour != 0 || minute != 0 || second != 0) return endTime;
		endTime.set(Calendar.HOUR_OF_DAY, 23);
		endTime.set(Calendar.MINUTE, 59);
		endTime.set(Calendar.SECOND, 59);
		endTime.set(Calendar.MILLISECOND, 999);
		return endTime;
	}

	public void setEndTime(Calendar endTime)
	{
		this.endTime = endTime;
	}

	public Calendar[] toTimes()
	{
		return new Calendar[] { getStartTime(), getEndTime() };
	}

}
