/*
 * Date: 2012-9-19
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.common.web;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;

import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;

import cn.com.taiji.common.manager.JsonManagerException;
import cn.com.taiji.common.manager.ManagerException;
import cn.com.taiji.common.model.NoteModel;
import cn.com.taiji.common.pub.EncodeTool;
import cn.com.taiji.common.validation.MyViolationException;

/**
 * json格式的基类验证controller
 * 
 * @author Peream <br>
 *         Create Time：2012-9-19 下午4:03:20<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class JsonValidController extends BaseController
{
	public static final String HEADER_JME = "taiji_jme";// JsonManagerException
	public static final String HEADER_CVE = "taiji_cve";// ConstraintViolationException
	public static final String HEADER_ME = "taiji_me";// ManagerException
	public static final String HEADER_NOTE = "taiji_note";// addSuccess
	public static final String CONTENT_EJSON = "taiji_ejson";// exception return json msg

	/**
	 * 总是返回null用于简化controller调用，因为response已经被使用过<BR>
	 * 
	 * @deprecated 已经处理 {@linkplain #handleBindException(BindException, HttpServletResponse)}
	 *             controller的方法的参数中不用再声明 {@linkplain BindingResult}
	 * @param result
	 * @param response
	 * @return
	 */
	@Deprecated
	protected final String responseFiledErrors(BindingResult result, HttpServletResponse response)
	{
		try
		{
			jsonResponse(HEADER_CVE, "taiji_cve", response, fieldErrors2Json(result));
			return null;
		}
		catch (IOException e)
		{
			throw new RuntimeException(e.getMessage());
		}
	}

	/**
	 * JSR303 validate的校验结果包装成taiji_cve
	 * 
	 * @param be
	 * @param response
	 * @throws IOException
	 */
	@ExceptionHandler(BindException.class)
	public void handleBindException(BindException be, HttpServletResponse response) throws IOException
	{
		logger.debug("handle BindException:{}", be.getMessage());
		jsonResponse(HEADER_CVE, "taiji_cve", response, fieldErrors2Json(be.getBindingResult()));
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public void handleConstraintViolationException(ConstraintViolationException cve, HttpServletResponse response)
			throws IOException
	{
		logger.debug("handle ConstraintViolationException:{}", cve.getMessage());
		jsonResponse(HEADER_CVE, "taiji_cve", response, violation2Json(cve));
	}

	/**
	 * 自定义的校验异常包装成taiji_cve
	 * 
	 * @param mve
	 * @param response
	 * @throws IOException
	 */
	@ExceptionHandler(MyViolationException.class)
	public void handleMyViolationException(MyViolationException mve, HttpServletResponse response) throws IOException
	{
		String json = mve.toJson();
		logger.debug("handle MyViolationException:{}", json);
		jsonResponse(HEADER_CVE, "taiji_cve", response, json);
	}

	@ExceptionHandler(ManagerException.class)
	public void handleManagerException(ManagerException e, HttpServletResponse response) throws IOException
	{
		logger.debug("handle ManagerException:{}", e.getMessage());
		jsonResponse(HEADER_ME, "操作失败:" + e.getMessage(), response, "{}");
	}

	/**
	 * 异常信息以json格式返回，前台可以用jquery进行处理
	 * 
	 * @param e
	 * @param response
	 * @throws IOException
	 */
	@ExceptionHandler(JsonManagerException.class)
	public void handleJsonManagerException(JsonManagerException e, HttpServletResponse response) throws IOException
	{
		logger.debug("handle JsonManagerException:{}", e.getMessage());
		jsonResponse(HEADER_JME, "操作失败:" + e.getMessage(), response, e.getJsonStr());
	}

	// /**
	// * 表单里面含有上传文件时，使用此方法返回提示信息
	// *
	// * @param model
	// * @param message
	// * @param args
	// */
	// protected final void addSuccessViaContent(Model model, HttpServletResponse response, String
	// message, Object... args)
	// {
	// String str = addSuccess(response, message, args);
	// // content
	// model.addAttribute(HEADER_NOTE, new NoteModel(true, str).toJson());
	// }

	protected final String addSuccess(HttpServletResponse response, String message, Object... args)
	{
		String str = toLogString(message, args);
		String headerMsg = hasText(str) ? EncodeTool.encodeBase64UTF8(str) : "";
		response.setHeader(HEADER_NOTE, headerMsg);
		return headerMsg;
	}

	@Override
	protected final void addSuccess(Model model, String message, Object... args)
	{
		throw new RuntimeException("使用addSuccess(HttpServletResponse response,String message, Object... args)替代.");
	}

	@Override
	protected final void addError(Model model, String error, Object... args)
	{
		throw new RuntimeException("由JsonValidController统一处理，不用调用此方法.");
	}

	@Override
	protected final void addViolation(Model model, ConstraintViolationException cve)
	{
		throw new RuntimeException("由JsonValidController统一处理，不用调用此方法.");
	}

	private void jsonResponse(String header, String msg, HttpServletResponse response, String jsonStr)
			throws IOException
	{
		String headerMsg = hasText(msg) ? EncodeTool.encodeBase64UTF8(msg) : "";
		response.setHeader(header, headerMsg);
		NoteModel model = new NoteModel(false, headerMsg);
		String rs = "<div><div id=\"" + HEADER_NOTE + "\">" + model.toJson() + "</div>";
		if (hasText(jsonStr))
		{
			rs += "<div id=\"" + CONTENT_EJSON + "\">" + jsonStr + "</div>";
		}
		rs += "</div>";
		response.setContentType("text/html;charset=UTF-8");
		response.getWriter().print(rs);
	}
}
